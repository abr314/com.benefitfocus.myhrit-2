package com.google.gson.internal;

import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Set;

public final class StringMap<V> extends AbstractMap<String, V>
{
  private static final Map.Entry[] EMPTY_TABLE = new LinkedEntry[2];
  private static final int MAXIMUM_CAPACITY = 1073741824;
  private static final int MINIMUM_CAPACITY = 4;
  private static final int seed = new Random().nextInt();
  private Set<Map.Entry<String, V>> entrySet;
  private LinkedEntry<V> header = new LinkedEntry();
  private Set<String> keySet;
  private int size;
  private LinkedEntry<V>[] table = (LinkedEntry[])(LinkedEntry[])EMPTY_TABLE;
  private int threshold = -1;
  private Collection<V> values;

  private void addNewEntry(String paramString, V paramV, int paramInt1, int paramInt2)
  {
    LinkedEntry localLinkedEntry1 = this.header;
    LinkedEntry localLinkedEntry2 = localLinkedEntry1.prv;
    LinkedEntry localLinkedEntry3 = new LinkedEntry(paramString, paramV, paramInt1, this.table[paramInt2], localLinkedEntry1, localLinkedEntry2);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    localLinkedEntry1.prv = localLinkedEntry3;
    localLinkedEntry2.nxt = localLinkedEntry3;
    arrayOfLinkedEntry[paramInt2] = localLinkedEntry3;
  }

  private LinkedEntry<V>[] doubleCapacity()
  {
    LinkedEntry[] arrayOfLinkedEntry1 = this.table;
    int i = arrayOfLinkedEntry1.length;
    LinkedEntry[] arrayOfLinkedEntry2;
    if (i == 1073741824)
      arrayOfLinkedEntry2 = arrayOfLinkedEntry1;
    do
    {
      return arrayOfLinkedEntry2;
      arrayOfLinkedEntry2 = makeTable(i * 2);
    }
    while (this.size == 0);
    int j = 0;
    label36: Object localObject1;
    if (j < i)
    {
      localObject1 = arrayOfLinkedEntry1[j];
      if (localObject1 != null)
        break label59;
    }
    while (true)
    {
      j++;
      break label36;
      break;
      label59: int k = i & ((LinkedEntry)localObject1).hash;
      Object localObject2 = null;
      arrayOfLinkedEntry2[(j | k)] = localObject1;
      LinkedEntry localLinkedEntry = ((LinkedEntry)localObject1).next;
      if (localLinkedEntry != null)
      {
        int m = i & localLinkedEntry.hash;
        if (m != k)
        {
          if (localObject2 != null)
            break label144;
          arrayOfLinkedEntry2[(j | m)] = localLinkedEntry;
        }
        while (true)
        {
          localObject2 = localObject1;
          k = m;
          localObject1 = localLinkedEntry;
          localLinkedEntry = localLinkedEntry.next;
          break;
          label144: localObject2.next = localLinkedEntry;
        }
      }
      if (localObject2 == null)
        continue;
      localObject2.next = null;
    }
  }

  private LinkedEntry<V> getEntry(String paramString)
  {
    if (paramString == null)
    {
      localLinkedEntry = null;
      return localLinkedEntry;
    }
    int i = hash(paramString);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    for (LinkedEntry localLinkedEntry = arrayOfLinkedEntry[(i & -1 + arrayOfLinkedEntry.length)]; ; localLinkedEntry = localLinkedEntry.next)
    {
      if (localLinkedEntry == null)
        break label76;
      String str = localLinkedEntry.key;
      if ((str == paramString) || ((localLinkedEntry.hash == i) && (paramString.equals(str))))
        break;
    }
    label76: return null;
  }

  private static int hash(String paramString)
  {
    int i = seed;
    for (int j = 0; j < paramString.length(); j++)
    {
      int m = i + paramString.charAt(j);
      int n = m + m << 10;
      i = n ^ n >>> 6;
    }
    int k = i ^ (i >>> 20 ^ i >>> 12);
    return k ^ k >>> 7 ^ k >>> 4;
  }

  private LinkedEntry<V>[] makeTable(int paramInt)
  {
    LinkedEntry[] arrayOfLinkedEntry = (LinkedEntry[])new LinkedEntry[paramInt];
    this.table = arrayOfLinkedEntry;
    this.threshold = ((paramInt >> 1) + (paramInt >> 2));
    return arrayOfLinkedEntry;
  }

  private boolean removeMapping(Object paramObject1, Object paramObject2)
  {
    if ((paramObject1 == null) || (!(paramObject1 instanceof String)))
      return false;
    int i = hash((String)paramObject1);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    int j = i & -1 + arrayOfLinkedEntry.length;
    LinkedEntry localLinkedEntry1 = arrayOfLinkedEntry[j];
    LinkedEntry localLinkedEntry2 = null;
    while (localLinkedEntry1 != null)
    {
      if ((localLinkedEntry1.hash == i) && (paramObject1.equals(localLinkedEntry1.key)))
      {
        if (paramObject2 == null)
        {
          if (localLinkedEntry1.value == null);
        }
        else
          do
            return false;
          while (!paramObject2.equals(localLinkedEntry1.value));
        if (localLinkedEntry2 == null)
          arrayOfLinkedEntry[j] = localLinkedEntry1.next;
        while (true)
        {
          this.size = (-1 + this.size);
          unlink(localLinkedEntry1);
          return true;
          localLinkedEntry2.next = localLinkedEntry1.next;
        }
      }
      localLinkedEntry2 = localLinkedEntry1;
      localLinkedEntry1 = localLinkedEntry1.next;
    }
    return false;
  }

  private void unlink(LinkedEntry<V> paramLinkedEntry)
  {
    paramLinkedEntry.prv.nxt = paramLinkedEntry.nxt;
    paramLinkedEntry.nxt.prv = paramLinkedEntry.prv;
    paramLinkedEntry.prv = null;
    paramLinkedEntry.nxt = null;
  }

  public void clear()
  {
    if (this.size != 0)
    {
      Arrays.fill(this.table, null);
      this.size = 0;
    }
    LinkedEntry localLinkedEntry1 = this.header;
    LinkedEntry localLinkedEntry2;
    for (Object localObject = localLinkedEntry1.nxt; localObject != localLinkedEntry1; localObject = localLinkedEntry2)
    {
      localLinkedEntry2 = ((LinkedEntry)localObject).nxt;
      ((LinkedEntry)localObject).prv = null;
      ((LinkedEntry)localObject).nxt = null;
    }
    localLinkedEntry1.prv = localLinkedEntry1;
    localLinkedEntry1.nxt = localLinkedEntry1;
  }

  public boolean containsKey(Object paramObject)
  {
    return ((paramObject instanceof String)) && (getEntry((String)paramObject) != null);
  }

  public Set<Map.Entry<String, V>> entrySet()
  {
    Set localSet = this.entrySet;
    if (localSet != null)
      return localSet;
    EntrySet localEntrySet = new EntrySet(null);
    this.entrySet = localEntrySet;
    return localEntrySet;
  }

  public V get(Object paramObject)
  {
    boolean bool = paramObject instanceof String;
    Object localObject = null;
    if (bool)
    {
      LinkedEntry localLinkedEntry = getEntry((String)paramObject);
      localObject = null;
      if (localLinkedEntry != null)
        localObject = localLinkedEntry.value;
    }
    return localObject;
  }

  public Set<String> keySet()
  {
    Set localSet = this.keySet;
    if (localSet != null)
      return localSet;
    KeySet localKeySet = new KeySet(null);
    this.keySet = localKeySet;
    return localKeySet;
  }

  public V put(String paramString, V paramV)
  {
    if (paramString == null)
      throw new NullPointerException("key == null");
    int i = hash(paramString);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    int j = i & -1 + arrayOfLinkedEntry.length;
    for (LinkedEntry localLinkedEntry = arrayOfLinkedEntry[j]; localLinkedEntry != null; localLinkedEntry = localLinkedEntry.next)
    {
      if ((localLinkedEntry.hash != i) || (!paramString.equals(localLinkedEntry.key)))
        continue;
      Object localObject = localLinkedEntry.value;
      localLinkedEntry.value = paramV;
      return localObject;
    }
    int k = this.size;
    this.size = (k + 1);
    if (k > this.threshold)
      j = i & -1 + doubleCapacity().length;
    addNewEntry(paramString, paramV, i, j);
    return null;
  }

  public V remove(Object paramObject)
  {
    if ((paramObject == null) || (!(paramObject instanceof String)))
      return null;
    int i = hash((String)paramObject);
    LinkedEntry[] arrayOfLinkedEntry = this.table;
    int j = i & -1 + arrayOfLinkedEntry.length;
    LinkedEntry localLinkedEntry1 = arrayOfLinkedEntry[j];
    LinkedEntry localLinkedEntry2 = null;
    while (localLinkedEntry1 != null)
    {
      if ((localLinkedEntry1.hash == i) && (paramObject.equals(localLinkedEntry1.key)))
      {
        if (localLinkedEntry2 == null)
          arrayOfLinkedEntry[j] = localLinkedEntry1.next;
        while (true)
        {
          this.size = (-1 + this.size);
          unlink(localLinkedEntry1);
          return localLinkedEntry1.value;
          localLinkedEntry2.next = localLinkedEntry1.next;
        }
      }
      localLinkedEntry2 = localLinkedEntry1;
      localLinkedEntry1 = localLinkedEntry1.next;
    }
    return null;
  }

  public int size()
  {
    return this.size;
  }

  public Collection<V> values()
  {
    Collection localCollection = this.values;
    if (localCollection != null)
      return localCollection;
    Values localValues = new Values(null);
    this.values = localValues;
    return localValues;
  }

  private final class EntrySet extends AbstractSet<Map.Entry<String, V>>
  {
    private EntrySet()
    {
    }

    public void clear()
    {
      StringMap.this.clear();
    }

    public boolean contains(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry));
      Map.Entry localEntry;
      Object localObject;
      do
      {
        return false;
        localEntry = (Map.Entry)paramObject;
        localObject = StringMap.this.get(localEntry.getKey());
      }
      while ((localObject == null) || (!localObject.equals(localEntry.getValue())));
      return true;
    }

    public Iterator<Map.Entry<String, V>> iterator()
    {
      return new StringMap.LinkedHashIterator()
      {
        public final Map.Entry<String, V> next()
        {
          return nextEntry();
        }
      };
    }

    public boolean remove(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry))
        return false;
      Map.Entry localEntry = (Map.Entry)paramObject;
      return StringMap.this.removeMapping(localEntry.getKey(), localEntry.getValue());
    }

    public int size()
    {
      return StringMap.this.size;
    }
  }

  private final class KeySet extends AbstractSet<String>
  {
    private KeySet()
    {
    }

    public void clear()
    {
      StringMap.this.clear();
    }

    public boolean contains(Object paramObject)
    {
      return StringMap.this.containsKey(paramObject);
    }

    public Iterator<String> iterator()
    {
      return new StringMap.LinkedHashIterator()
      {
        public final String next()
        {
          return nextEntry().key;
        }
      };
    }

    public boolean remove(Object paramObject)
    {
      int i = StringMap.this.size;
      StringMap.this.remove(paramObject);
      return StringMap.this.size != i;
    }

    public int size()
    {
      return StringMap.this.size;
    }
  }

  static class LinkedEntry<V>
    implements Map.Entry<String, V>
  {
    final int hash;
    final String key;
    LinkedEntry<V> next;
    LinkedEntry<V> nxt;
    LinkedEntry<V> prv;
    V value;

    LinkedEntry()
    {
      this(null, null, 0, null, null, null);
      this.prv = this;
      this.nxt = this;
    }

    LinkedEntry(String paramString, V paramV, int paramInt, LinkedEntry<V> paramLinkedEntry1, LinkedEntry<V> paramLinkedEntry2, LinkedEntry<V> paramLinkedEntry3)
    {
      this.key = paramString;
      this.value = paramV;
      this.hash = paramInt;
      this.next = paramLinkedEntry1;
      this.nxt = paramLinkedEntry2;
      this.prv = paramLinkedEntry3;
    }

    public final boolean equals(Object paramObject)
    {
      if (!(paramObject instanceof Map.Entry));
      Object localObject;
      do
      {
        Map.Entry localEntry;
        do
        {
          return false;
          localEntry = (Map.Entry)paramObject;
          localObject = localEntry.getValue();
        }
        while (!this.key.equals(localEntry.getKey()));
        if (this.value != null)
          break;
      }
      while (localObject != null);
      while (true)
      {
        return true;
        if (!this.value.equals(localObject))
          break;
      }
    }

    public final String getKey()
    {
      return this.key;
    }

    public final V getValue()
    {
      return this.value;
    }

    public final int hashCode()
    {
      int i;
      int j;
      if (this.key == null)
      {
        i = 0;
        Object localObject = this.value;
        j = 0;
        if (localObject != null)
          break label35;
      }
      while (true)
      {
        return i ^ j;
        i = this.key.hashCode();
        break;
        label35: j = this.value.hashCode();
      }
    }

    public final V setValue(V paramV)
    {
      Object localObject = this.value;
      this.value = paramV;
      return localObject;
    }

    public final String toString()
    {
      return this.key + "=" + this.value;
    }
  }

  private abstract class LinkedHashIterator<T>
    implements Iterator<T>
  {
    StringMap.LinkedEntry<V> lastReturned = null;
    StringMap.LinkedEntry<V> next = StringMap.this.header.nxt;

    private LinkedHashIterator()
    {
    }

    public final boolean hasNext()
    {
      return this.next != StringMap.this.header;
    }

    final StringMap.LinkedEntry<V> nextEntry()
    {
      StringMap.LinkedEntry localLinkedEntry = this.next;
      if (localLinkedEntry == StringMap.this.header)
        throw new NoSuchElementException();
      this.next = localLinkedEntry.nxt;
      this.lastReturned = localLinkedEntry;
      return localLinkedEntry;
    }

    public final void remove()
    {
      if (this.lastReturned == null)
        throw new IllegalStateException();
      StringMap.this.remove(this.lastReturned.key);
      this.lastReturned = null;
    }
  }

  private final class Values extends AbstractCollection<V>
  {
    private Values()
    {
    }

    public void clear()
    {
      StringMap.this.clear();
    }

    public boolean contains(Object paramObject)
    {
      return StringMap.this.containsValue(paramObject);
    }

    public Iterator<V> iterator()
    {
      return new StringMap.LinkedHashIterator()
      {
        public final V next()
        {
          return nextEntry().value;
        }
      };
    }

    public int size()
    {
      return StringMap.this.size;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.google.gson.internal.StringMap
 * JD-Core Version:    0.6.0
 */