package com.google.gson.internal;

public abstract interface ObjectConstructor<T>
{
  public abstract T construct();
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.google.gson.internal.ObjectConstructor
 * JD-Core Version:    0.6.0
 */