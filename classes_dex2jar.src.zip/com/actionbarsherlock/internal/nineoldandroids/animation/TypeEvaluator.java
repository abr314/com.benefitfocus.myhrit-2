package com.actionbarsherlock.internal.nineoldandroids.animation;

public abstract interface TypeEvaluator<T>
{
  public abstract T evaluate(float paramFloat, T paramT1, T paramT2);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.internal.nineoldandroids.animation.TypeEvaluator
 * JD-Core Version:    0.6.0
 */