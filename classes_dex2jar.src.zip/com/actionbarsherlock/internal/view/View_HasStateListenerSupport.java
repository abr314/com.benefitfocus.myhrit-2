package com.actionbarsherlock.internal.view;

public abstract interface View_HasStateListenerSupport
{
  public abstract void addOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);

  public abstract void removeOnAttachStateChangeListener(View_OnAttachStateChangeListener paramView_OnAttachStateChangeListener);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.actionbarsherlock.internal.view.View_HasStateListenerSupport
 * JD-Core Version:    0.6.0
 */