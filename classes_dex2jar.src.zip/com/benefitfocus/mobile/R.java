package com.benefitfocus.mobile;

public final class R
{
  public static final class color
  {
    public static final int black = 2131099672;
    public static final int gray = 2131099673;
    public static final int opaque_black = 2131099677;
    public static final int opaque_gray = 2131099674;
    public static final int opaque_light_gray = 2131099676;
    public static final int red = 2131099675;
    public static final int transparent = 2131099678;
    public static final int white = 2131099671;
  }

  public static final class drawable
  {
    public static final int default_button = 2130837624;
    public static final int ic_launcher = 2130837646;
    public static final int transparent_base = 2130837706;
  }

  public static final class string
  {
    public static final int app_name = 2131427341;
    public static final int logo = 2131427342;
  }

  public static final class style
  {
    public static final int AppBaseTheme = 2131361885;
    public static final int AppTheme = 2131361886;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.mobile.R
 * JD-Core Version:    0.6.0
 */