package com.benefitfocus.api.constant.privateLabel;

public enum ApplicationContextEnum
{
  static
  {
    GO = new ApplicationContextEnum("GO", 1);
    BROKER = new ApplicationContextEnum("BROKER", 2);
    HRADMIN = new ApplicationContextEnum("HRADMIN", 3);
    CARRIER = new ApplicationContextEnum("CARRIER", 4);
    VISTA = new ApplicationContextEnum("VISTA", 5);
    ApplicationContextEnum[] arrayOfApplicationContextEnum = new ApplicationContextEnum[6];
    arrayOfApplicationContextEnum[0] = MEMBER;
    arrayOfApplicationContextEnum[1] = GO;
    arrayOfApplicationContextEnum[2] = BROKER;
    arrayOfApplicationContextEnum[3] = HRADMIN;
    arrayOfApplicationContextEnum[4] = CARRIER;
    arrayOfApplicationContextEnum[5] = VISTA;
    $VALUES = arrayOfApplicationContextEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.privateLabel.ApplicationContextEnum
 * JD-Core Version:    0.6.0
 */