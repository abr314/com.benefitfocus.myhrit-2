package com.benefitfocus.api.constant.payment;

public enum PaymentFrequencyBean
{
  static
  {
    QUARTERLY = new PaymentFrequencyBean("QUARTERLY", 2);
    BIMONTHLY = new PaymentFrequencyBean("BIMONTHLY", 3);
    NINE_PER_YEAR = new PaymentFrequencyBean("NINE_PER_YEAR", 4);
    TEN_PER_YEAR = new PaymentFrequencyBean("TEN_PER_YEAR", 5);
    ELEVEN_PER_YEAR = new PaymentFrequencyBean("ELEVEN_PER_YEAR", 6);
    MONTHLY = new PaymentFrequencyBean("MONTHLY", 7);
    SIXTEEN_PER_YEAR = new PaymentFrequencyBean("SIXTEEN_PER_YEAR", 8);
    EIGHTEEN_PER_YEAR = new PaymentFrequencyBean("EIGHTEEN_PER_YEAR", 9);
    TWENTY_PER_YEAR = new PaymentFrequencyBean("TWENTY_PER_YEAR", 10);
    TWENTYONE_PER_YEAR = new PaymentFrequencyBean("TWENTYONE_PER_YEAR", 11);
    TWENTYTWO_PER_YEAR = new PaymentFrequencyBean("TWENTYTWO_PER_YEAR", 12);
    SEMIMONTHLY = new PaymentFrequencyBean("SEMIMONTHLY", 13);
    BIWEEKLY = new PaymentFrequencyBean("BIWEEKLY", 14);
    FOUR_PER_MONTH = new PaymentFrequencyBean("FOUR_PER_MONTH", 15);
    WEEKLY = new PaymentFrequencyBean("WEEKLY", 16);
    PaymentFrequencyBean[] arrayOfPaymentFrequencyBean = new PaymentFrequencyBean[17];
    arrayOfPaymentFrequencyBean[0] = ANNUALLY;
    arrayOfPaymentFrequencyBean[1] = SEMIANNUALLY;
    arrayOfPaymentFrequencyBean[2] = QUARTERLY;
    arrayOfPaymentFrequencyBean[3] = BIMONTHLY;
    arrayOfPaymentFrequencyBean[4] = NINE_PER_YEAR;
    arrayOfPaymentFrequencyBean[5] = TEN_PER_YEAR;
    arrayOfPaymentFrequencyBean[6] = ELEVEN_PER_YEAR;
    arrayOfPaymentFrequencyBean[7] = MONTHLY;
    arrayOfPaymentFrequencyBean[8] = SIXTEEN_PER_YEAR;
    arrayOfPaymentFrequencyBean[9] = EIGHTEEN_PER_YEAR;
    arrayOfPaymentFrequencyBean[10] = TWENTY_PER_YEAR;
    arrayOfPaymentFrequencyBean[11] = TWENTYONE_PER_YEAR;
    arrayOfPaymentFrequencyBean[12] = TWENTYTWO_PER_YEAR;
    arrayOfPaymentFrequencyBean[13] = SEMIMONTHLY;
    arrayOfPaymentFrequencyBean[14] = BIWEEKLY;
    arrayOfPaymentFrequencyBean[15] = FOUR_PER_MONTH;
    arrayOfPaymentFrequencyBean[16] = WEEKLY;
    $VALUES = arrayOfPaymentFrequencyBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.payment.PaymentFrequencyBean
 * JD-Core Version:    0.6.0
 */