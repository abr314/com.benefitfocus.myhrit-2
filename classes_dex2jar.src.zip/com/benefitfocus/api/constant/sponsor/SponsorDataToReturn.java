package com.benefitfocus.api.constant.sponsor;

public enum SponsorDataToReturn
{
  static
  {
    CARRIER_DEFINED_FIELDS = new SponsorDataToReturn("CARRIER_DEFINED_FIELDS", 1);
    CATEGORIES = new SponsorDataToReturn("CATEGORIES", 2);
    CURRENT_BENEFITS = new SponsorDataToReturn("CURRENT_BENEFITS", 3);
    FUTURE_BENEFITS = new SponsorDataToReturn("FUTURE_BENEFITS", 4);
    PRIVATE_LABEL_ELEMENTS = new SponsorDataToReturn("PRIVATE_LABEL_ELEMENTS", 5);
    PERSONAL_EDITABLE_FIELDS = new SponsorDataToReturn("PERSONAL_EDITABLE_FIELDS", 6);
    SponsorDataToReturn[] arrayOfSponsorDataToReturn = new SponsorDataToReturn[7];
    arrayOfSponsorDataToReturn[0] = COUNTS;
    arrayOfSponsorDataToReturn[1] = CARRIER_DEFINED_FIELDS;
    arrayOfSponsorDataToReturn[2] = CATEGORIES;
    arrayOfSponsorDataToReturn[3] = CURRENT_BENEFITS;
    arrayOfSponsorDataToReturn[4] = FUTURE_BENEFITS;
    arrayOfSponsorDataToReturn[5] = PRIVATE_LABEL_ELEMENTS;
    arrayOfSponsorDataToReturn[6] = PERSONAL_EDITABLE_FIELDS;
    $VALUES = arrayOfSponsorDataToReturn;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.sponsor.SponsorDataToReturn
 * JD-Core Version:    0.6.0
 */