package com.benefitfocus.api.constant.benefit;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum ProductPlanTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, ProductPlanTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    HMO = new ProductPlanTypeEnum("HMO", 1, "HMO");
    HDHP = new ProductPlanTypeEnum("HDHP", 2, "HDHP");
    CMM = new ProductPlanTypeEnum("CMM", 3, "CMM");
    POS = new ProductPlanTypeEnum("POS", 4, "POS");
    TRADITIONAL = new ProductPlanTypeEnum("TRADITIONAL", 5, "TRADITIONAL");
    HNO = new ProductPlanTypeEnum("HNO", 6, "HNO");
    EPO = new ProductPlanTypeEnum("EPO", 7, "EPO");
    DHMO = new ProductPlanTypeEnum("DHMO", 8, "DHMO");
    DPPO = new ProductPlanTypeEnum("DPPO", 9, "DPPO");
    DEPO = new ProductPlanTypeEnum("DEPO", 10, "DEPO");
    DUCR = new ProductPlanTypeEnum("DUCR", 11, "DUCR");
    DTL = new ProductPlanTypeEnum("DTL", 12, "DTL");
    INDIVIDUAL = new ProductPlanTypeEnum("INDIVIDUAL", 13, "INDIVIDUAL");
    FAMILY = new ProductPlanTypeEnum("FAMILY", 14, "FAMILY");
    RIDER = new ProductPlanTypeEnum("RIDER", 15, "RIDER");
    Senior = new ProductPlanTypeEnum("Senior", 16, "SENIOR");
    AffordaBlue = new ProductPlanTypeEnum("AffordaBlue", 17, "AFFORDABLUE");
    QHDEPO = new ProductPlanTypeEnum("QHDEPO", 18, "QHDEPO");
    QHDPPO = new ProductPlanTypeEnum("QHDPPO", 19, "QHDPPO");
    ProductPlanTypeEnum[] arrayOfProductPlanTypeEnum1 = new ProductPlanTypeEnum[20];
    arrayOfProductPlanTypeEnum1[0] = PPO;
    arrayOfProductPlanTypeEnum1[1] = HMO;
    arrayOfProductPlanTypeEnum1[2] = HDHP;
    arrayOfProductPlanTypeEnum1[3] = CMM;
    arrayOfProductPlanTypeEnum1[4] = POS;
    arrayOfProductPlanTypeEnum1[5] = TRADITIONAL;
    arrayOfProductPlanTypeEnum1[6] = HNO;
    arrayOfProductPlanTypeEnum1[7] = EPO;
    arrayOfProductPlanTypeEnum1[8] = DHMO;
    arrayOfProductPlanTypeEnum1[9] = DPPO;
    arrayOfProductPlanTypeEnum1[10] = DEPO;
    arrayOfProductPlanTypeEnum1[11] = DUCR;
    arrayOfProductPlanTypeEnum1[12] = DTL;
    arrayOfProductPlanTypeEnum1[13] = INDIVIDUAL;
    arrayOfProductPlanTypeEnum1[14] = FAMILY;
    arrayOfProductPlanTypeEnum1[15] = RIDER;
    arrayOfProductPlanTypeEnum1[16] = Senior;
    arrayOfProductPlanTypeEnum1[17] = AffordaBlue;
    arrayOfProductPlanTypeEnum1[18] = QHDEPO;
    arrayOfProductPlanTypeEnum1[19] = QHDPPO;
    $VALUES = arrayOfProductPlanTypeEnum1;
    valueMap = new HashMap();
    for (ProductPlanTypeEnum localProductPlanTypeEnum : values())
      valueMap.put(localProductPlanTypeEnum.getAtomicConstantValue(), localProductPlanTypeEnum);
  }

  private ProductPlanTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static ProductPlanTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (ProductPlanTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.ProductPlanTypeEnum
 * JD-Core Version:    0.6.0
 */