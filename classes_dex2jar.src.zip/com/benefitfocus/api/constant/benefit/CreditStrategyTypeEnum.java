package com.benefitfocus.api.constant.benefit;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum CreditStrategyTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, CreditStrategyTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    CALCULATED = new CreditStrategyTypeEnum("CALCULATED", 1, "CALCULATED");
    BY_PLAN = new CreditStrategyTypeEnum("BY_PLAN", 2, "BY_PLAN");
    FLAT_AMOUNT = new CreditStrategyTypeEnum("FLAT_AMOUNT", 3, "FLAT_AMOUNT");
    PERCENTAGE_OF_EMPLOYEE_SALARY = new CreditStrategyTypeEnum("PERCENTAGE_OF_EMPLOYEE_SALARY", 4, "PERCENT_EMPLOYEE_SALARY");
    CreditStrategyTypeEnum[] arrayOfCreditStrategyTypeEnum1 = new CreditStrategyTypeEnum[5];
    arrayOfCreditStrategyTypeEnum1[0] = STORED;
    arrayOfCreditStrategyTypeEnum1[1] = CALCULATED;
    arrayOfCreditStrategyTypeEnum1[2] = BY_PLAN;
    arrayOfCreditStrategyTypeEnum1[3] = FLAT_AMOUNT;
    arrayOfCreditStrategyTypeEnum1[4] = PERCENTAGE_OF_EMPLOYEE_SALARY;
    $VALUES = arrayOfCreditStrategyTypeEnum1;
    valueMap = new HashMap();
    for (CreditStrategyTypeEnum localCreditStrategyTypeEnum : values())
      valueMap.put(localCreditStrategyTypeEnum.getAtomicConstantValue(), localCreditStrategyTypeEnum);
  }

  private CreditStrategyTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static CreditStrategyTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (CreditStrategyTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.CreditStrategyTypeEnum
 * JD-Core Version:    0.6.0
 */