package com.benefitfocus.api.constant.benefit;

import com.benefitfocus.api.constant.AtomicConstantEnum;

public enum BenefitProgramTypeEnum
  implements AtomicConstantEnum
{
  static
  {
    BenefitProgramTypeEnum[] arrayOfBenefitProgramTypeEnum = new BenefitProgramTypeEnum[2];
    arrayOfBenefitProgramTypeEnum[0] = DEFINED_CONTRIBUTIONS;
    arrayOfBenefitProgramTypeEnum[1] = PHA;
    $VALUES = arrayOfBenefitProgramTypeEnum;
  }

  public static BenefitProgramTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return valueOf(paramString);
  }

  public String getAtomicConstantValue()
  {
    return name();
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.BenefitProgramTypeEnum
 * JD-Core Version:    0.6.0
 */