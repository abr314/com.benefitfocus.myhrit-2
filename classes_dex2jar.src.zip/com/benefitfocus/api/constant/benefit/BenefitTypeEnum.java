package com.benefitfocus.api.constant.benefit;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum BenefitTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, BenefitTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    HRA = new BenefitTypeEnum("HRA", 2, "HRA");
    HSA = new BenefitTypeEnum("HSA", 3, "HSA");
    SUPPLEMENTAL_MEDICAL = new BenefitTypeEnum("SUPPLEMENTAL_MEDICAL", 4, "SUPMED");
    MEDICARE_SUPPLEMENT = new BenefitTypeEnum("MEDICARE_SUPPLEMENT", 5, "MEDICARESUP");
    MEDICARESUPB = new BenefitTypeEnum("MEDICARESUPB", 6, "MEDICARESUPB");
    MEDICARESUPC = new BenefitTypeEnum("MEDICARESUPC", 7, "MEDICARESUPC");
    BSMEDICAL = new BenefitTypeEnum("BSMEDICAL", 8, "BSMEDICAL");
    MJRMED = new BenefitTypeEnum("MJRMED", 9, "MJRMED");
    COMPMJRMED = new BenefitTypeEnum("COMPMJRMED", 10, "COMPMJRMED");
    CHIROPRACTIC = new BenefitTypeEnum("CHIROPRACTIC", 11, "CHIROPRACTIC");
    HOSPCASH = new BenefitTypeEnum("HOSPCASH", 12, "HOSPCASH");
    IND_HOSPITAL_INDEMNITY = new BenefitTypeEnum("IND_HOSPITAL_INDEMNITY", 13, "INDHOSIND");
    TEMP_DISABILITY_INCOME = new BenefitTypeEnum("TEMP_DISABILITY_INCOME", 14, "TEMPDISINC");
    WELLNESS = new BenefitTypeEnum("WELLNESS", 15, "WELLNESS");
    DENTAL = new BenefitTypeEnum("DENTAL", 16, "DENTAL");
    DENTALOPTCDT = new BenefitTypeEnum("DENTALOPTCDT", 17, "DENTALOPTCDT");
    VOLDENTAL = new BenefitTypeEnum("VOLDENTAL", 18, "VOLDENTAL");
    VISION = new BenefitTypeEnum("VISION", 19, "VISION");
    VOLVISION = new BenefitTypeEnum("VOLVISION", 20, "VOLVISION");
    HEARING = new BenefitTypeEnum("HEARING", 21, "HEARING");
    CANCER = new BenefitTypeEnum("CANCER", 22, "CANCER");
    CARDIAC_CARE = new BenefitTypeEnum("CARDIAC_CARE", 23, "CARCARE");
    CARDIAC_CARE_PLUS = new BenefitTypeEnum("CARDIAC_CARE_PLUS", 24, "CARCARPLS");
    CRITICAL_CARE = new BenefitTypeEnum("CRITICAL_CARE", 25, "CRITCAR");
    CRITICAL_CARE_ELITE = new BenefitTypeEnum("CRITICAL_CARE_ELITE", 26, "CRITCAREL");
    BLUECHOICE_CRITICAL_ILLNESS = new BenefitTypeEnum("BLUECHOICE_CRITICAL_ILLNESS", 27, "BCCRITIL");
    GRP_CRITICAL_ELITE = new BenefitTypeEnum("GRP_CRITICAL_ELITE", 28, "GRCRITELTE");
    DREADED_DISEASE = new BenefitTypeEnum("DREADED_DISEASE", 29, "DREADDISEASE");
    PHARMACY = new BenefitTypeEnum("PHARMACY", 30, "PHARM");
    SUPPLEMENTAL_PHARMACY = new BenefitTypeEnum("SUPPLEMENTAL_PHARMACY", 31, "SUPPHARM");
    SAPHARM = new BenefitTypeEnum("SAPHARM", 32, "SAPHARM");
    SAVISION = new BenefitTypeEnum("SAVISION", 33, "SAVISION");
    SADENTAL = new BenefitTypeEnum("SADENTAL", 34, "SADENTAL");
    FLEX = new BenefitTypeEnum("FLEX", 35, "FLEX");
    HFSA = new BenefitTypeEnum("HFSA", 36, "HFSA");
    DCFSA = new BenefitTypeEnum("DCFSA", 37, "DCFSA");
    TFSA = new BenefitTypeEnum("TFSA", 38, "TFSA");
    MSA = new BenefitTypeEnum("MSA", 39, "MSA");
    LIFE = new BenefitTypeEnum("LIFE", 40, "LIFE");
    ADD = new BenefitTypeEnum("ADD", 41, "ADD");
    SPOUSELIFE = new BenefitTypeEnum("SPOUSELIFE", 42, "SPOUSELIFE");
    DEPLIFE = new BenefitTypeEnum("DEPLIFE", 43, "DEPLIFE");
    CHILDLIFE = new BenefitTypeEnum("CHILDLIFE", 44, "CHILDLIFE");
    SUPLIFE = new BenefitTypeEnum("SUPLIFE", 45, "SUPLIFE");
    SUPADD = new BenefitTypeEnum("SUPADD", 46, "SUPADD");
    SUPSPOUSELIFE = new BenefitTypeEnum("SUPSPOUSELIFE", 47, "SUPSPOUSELIFE");
    SUPSPOUSEADD = new BenefitTypeEnum("SUPSPOUSEADD", 48, "SUPSPOUSEADD");
    SUPDEPLIFE = new BenefitTypeEnum("SUPDEPLIFE", 49, "SUPDEPLIFE");
    SUPCHILDLIFE = new BenefitTypeEnum("SUPCHILDLIFE", 50, "SUPCHILDLIFE");
    SUPCHILDADD = new BenefitTypeEnum("SUPCHILDADD", 51, "SUPCHILDADD");
    VOLLIFE = new BenefitTypeEnum("VOLLIFE", 52, "VOLLIFE");
    VOL_INCOME_PROTECTION = new BenefitTypeEnum("VOL_INCOME_PROTECTION", 53, "VIP");
    VOLADD = new BenefitTypeEnum("VOLADD", 54, "VOLADD");
    VOL_ACCIDENT = new BenefitTypeEnum("VOL_ACCIDENT", 55, "VOLACC");
    VOL_ACCIDENT_EMPLOYEE = new BenefitTypeEnum("VOL_ACCIDENT_EMPLOYEE", 56, "VOLACCEE");
    ACCIDENT_ELITE = new BenefitTypeEnum("ACCIDENT_ELITE", 57, "ACCELT");
    ACCIDENT_GUARD = new BenefitTypeEnum("ACCIDENT_GUARD", 58, "ACCGRD");
    ACCIDENT_PLUS = new BenefitTypeEnum("ACCIDENT_PLUS", 59, "ACCPLS");
    CANCER_CARE_CHOICE = new BenefitTypeEnum("CANCER_CARE_CHOICE", 60, "CCCHOICE");
    VOL_ACCIDENT_FAMILY = new BenefitTypeEnum("VOL_ACCIDENT_FAMILY", 61, "VOLACCFY");
    VOLSPOUSELIFE = new BenefitTypeEnum("VOLSPOUSELIFE", 62, "VOLSPOUSELIFE");
    VOLSPOUSEADD = new BenefitTypeEnum("VOLSPOUSEADD", 63, "VOLSPOUSEADD");
    VOLDEPLIFE = new BenefitTypeEnum("VOLDEPLIFE", 64, "VOLDEPLIFE");
    VOLCHILDLIFE = new BenefitTypeEnum("VOLCHILDLIFE", 65, "VOLCHILDLIFE");
    VOLCHILDADD = new BenefitTypeEnum("VOLCHILDADD", 66, "VOLCHILDADD");
    UNIVERSAL_LIFE = new BenefitTypeEnum("UNIVERSAL_LIFE", 67, "ULIFE");
    WHOLE_LIFE = new BenefitTypeEnum("WHOLE_LIFE", 68, "WHLIF");
    UNIVERSAL_SPOUSE_LIFE = new BenefitTypeEnum("UNIVERSAL_SPOUSE_LIFE", 69, "ULIFESPOUSE");
    UNIVERSAL_CHILD_LIFE = new BenefitTypeEnum("UNIVERSAL_CHILD_LIFE", 70, "ULIFECHILD");
    CRITI = new BenefitTypeEnum("CRITI", 71, "CRITI");
    HOSPITAL_CONFINEMENT_INDEMNITY = new BenefitTypeEnum("HOSPITAL_CONFINEMENT_INDEMNITY", 72, "HOSCNFIND");
    TERM_LIFE = new BenefitTypeEnum("TERM_LIFE", 73, "TRMLF");
    GAP_CARE = new BenefitTypeEnum("GAP_CARE", 74, "GAP");
    SPOUSE_CRITICAL_ILLNESS = new BenefitTypeEnum("SPOUSE_CRITICAL_ILLNESS", 75, "CRITISPOUSE");
    CHILD_CRITICAL_ILLNESS = new BenefitTypeEnum("CHILD_CRITICAL_ILLNESS", 76, "CRITICHILD");
    LTD = new BenefitTypeEnum("LTD", 77, "LTD");
    STD = new BenefitTypeEnum("STD", 78, "STD");
    VOLLTD = new BenefitTypeEnum("VOLLTD", 79, "VOLLTD");
    VOLSTD = new BenefitTypeEnum("VOLSTD", 80, "VOLSTD");
    TERM_10YEAR = new BenefitTypeEnum("TERM_10YEAR", 81, "10YRTRM");
    EAP = new BenefitTypeEnum("EAP", 82, "EAP");
    TRAVEL = new BenefitTypeEnum("TRAVEL", 83, "TRAVEL");
    PARKING = new BenefitTypeEnum("PARKING", 84, "PARKING");
    PTO = new BenefitTypeEnum("PTO", 85, "PTO");
    RETIREMENT = new BenefitTypeEnum("RETIREMENT", 86, "RETIREMENT");
    PENSION = new BenefitTypeEnum("PENSION", 87, "PENSION");
    LTC = new BenefitTypeEnum("LTC", 88, "LTC");
    LTCD = new BenefitTypeEnum("LTCD", 89, "LTCD");
    GLTC = new BenefitTypeEnum("GLTC", 90, "GRLTCRE");
    WHOLE_SPOUSE_LIFE = new BenefitTypeEnum("WHOLE_SPOUSE_LIFE", 91, "WHOLELIFESP");
    WHOLE_CHILD_LIFE = new BenefitTypeEnum("WHOLE_CHILD_LIFE", 92, "WHOLELIFECH");
    LEGAL = new BenefitTypeEnum("LEGAL", 93, "LEGAL");
    BASIC = new BenefitTypeEnum("BASIC", 94, "BASICBENEFIT");
    TRADITIONAL_401K = new BenefitTypeEnum("TRADITIONAL_401K", 95, "TRADITIONAL401K");
    TRADITIONAL_403B = new BenefitTypeEnum("TRADITIONAL_403B", 96, "TRADITIONAL403B");
    ROTH_401K = new BenefitTypeEnum("ROTH_401K", 97, "ROTH401K");
    ROTH_403B = new BenefitTypeEnum("ROTH_403B", 98, "ROTH403B");
    GENERIC_CONTRIBUTORY = new BenefitTypeEnum("GENERIC_CONTRIBUTORY", 99, "GENERICCONTRIBUTORYBENEFIT");
    BenefitTypeEnum[] arrayOfBenefitTypeEnum1 = new BenefitTypeEnum[100];
    arrayOfBenefitTypeEnum1[0] = MEDICAL;
    arrayOfBenefitTypeEnum1[1] = MEDOPTCDT;
    arrayOfBenefitTypeEnum1[2] = HRA;
    arrayOfBenefitTypeEnum1[3] = HSA;
    arrayOfBenefitTypeEnum1[4] = SUPPLEMENTAL_MEDICAL;
    arrayOfBenefitTypeEnum1[5] = MEDICARE_SUPPLEMENT;
    arrayOfBenefitTypeEnum1[6] = MEDICARESUPB;
    arrayOfBenefitTypeEnum1[7] = MEDICARESUPC;
    arrayOfBenefitTypeEnum1[8] = BSMEDICAL;
    arrayOfBenefitTypeEnum1[9] = MJRMED;
    arrayOfBenefitTypeEnum1[10] = COMPMJRMED;
    arrayOfBenefitTypeEnum1[11] = CHIROPRACTIC;
    arrayOfBenefitTypeEnum1[12] = HOSPCASH;
    arrayOfBenefitTypeEnum1[13] = IND_HOSPITAL_INDEMNITY;
    arrayOfBenefitTypeEnum1[14] = TEMP_DISABILITY_INCOME;
    arrayOfBenefitTypeEnum1[15] = WELLNESS;
    arrayOfBenefitTypeEnum1[16] = DENTAL;
    arrayOfBenefitTypeEnum1[17] = DENTALOPTCDT;
    arrayOfBenefitTypeEnum1[18] = VOLDENTAL;
    arrayOfBenefitTypeEnum1[19] = VISION;
    arrayOfBenefitTypeEnum1[20] = VOLVISION;
    arrayOfBenefitTypeEnum1[21] = HEARING;
    arrayOfBenefitTypeEnum1[22] = CANCER;
    arrayOfBenefitTypeEnum1[23] = CARDIAC_CARE;
    arrayOfBenefitTypeEnum1[24] = CARDIAC_CARE_PLUS;
    arrayOfBenefitTypeEnum1[25] = CRITICAL_CARE;
    arrayOfBenefitTypeEnum1[26] = CRITICAL_CARE_ELITE;
    arrayOfBenefitTypeEnum1[27] = BLUECHOICE_CRITICAL_ILLNESS;
    arrayOfBenefitTypeEnum1[28] = GRP_CRITICAL_ELITE;
    arrayOfBenefitTypeEnum1[29] = DREADED_DISEASE;
    arrayOfBenefitTypeEnum1[30] = PHARMACY;
    arrayOfBenefitTypeEnum1[31] = SUPPLEMENTAL_PHARMACY;
    arrayOfBenefitTypeEnum1[32] = SAPHARM;
    arrayOfBenefitTypeEnum1[33] = SAVISION;
    arrayOfBenefitTypeEnum1[34] = SADENTAL;
    arrayOfBenefitTypeEnum1[35] = FLEX;
    arrayOfBenefitTypeEnum1[36] = HFSA;
    arrayOfBenefitTypeEnum1[37] = DCFSA;
    arrayOfBenefitTypeEnum1[38] = TFSA;
    arrayOfBenefitTypeEnum1[39] = MSA;
    arrayOfBenefitTypeEnum1[40] = LIFE;
    arrayOfBenefitTypeEnum1[41] = ADD;
    arrayOfBenefitTypeEnum1[42] = SPOUSELIFE;
    arrayOfBenefitTypeEnum1[43] = DEPLIFE;
    arrayOfBenefitTypeEnum1[44] = CHILDLIFE;
    arrayOfBenefitTypeEnum1[45] = SUPLIFE;
    arrayOfBenefitTypeEnum1[46] = SUPADD;
    arrayOfBenefitTypeEnum1[47] = SUPSPOUSELIFE;
    arrayOfBenefitTypeEnum1[48] = SUPSPOUSEADD;
    arrayOfBenefitTypeEnum1[49] = SUPDEPLIFE;
    arrayOfBenefitTypeEnum1[50] = SUPCHILDLIFE;
    arrayOfBenefitTypeEnum1[51] = SUPCHILDADD;
    arrayOfBenefitTypeEnum1[52] = VOLLIFE;
    arrayOfBenefitTypeEnum1[53] = VOL_INCOME_PROTECTION;
    arrayOfBenefitTypeEnum1[54] = VOLADD;
    arrayOfBenefitTypeEnum1[55] = VOL_ACCIDENT;
    arrayOfBenefitTypeEnum1[56] = VOL_ACCIDENT_EMPLOYEE;
    arrayOfBenefitTypeEnum1[57] = ACCIDENT_ELITE;
    arrayOfBenefitTypeEnum1[58] = ACCIDENT_GUARD;
    arrayOfBenefitTypeEnum1[59] = ACCIDENT_PLUS;
    arrayOfBenefitTypeEnum1[60] = CANCER_CARE_CHOICE;
    arrayOfBenefitTypeEnum1[61] = VOL_ACCIDENT_FAMILY;
    arrayOfBenefitTypeEnum1[62] = VOLSPOUSELIFE;
    arrayOfBenefitTypeEnum1[63] = VOLSPOUSEADD;
    arrayOfBenefitTypeEnum1[64] = VOLDEPLIFE;
    arrayOfBenefitTypeEnum1[65] = VOLCHILDLIFE;
    arrayOfBenefitTypeEnum1[66] = VOLCHILDADD;
    arrayOfBenefitTypeEnum1[67] = UNIVERSAL_LIFE;
    arrayOfBenefitTypeEnum1[68] = WHOLE_LIFE;
    arrayOfBenefitTypeEnum1[69] = UNIVERSAL_SPOUSE_LIFE;
    arrayOfBenefitTypeEnum1[70] = UNIVERSAL_CHILD_LIFE;
    arrayOfBenefitTypeEnum1[71] = CRITI;
    arrayOfBenefitTypeEnum1[72] = HOSPITAL_CONFINEMENT_INDEMNITY;
    arrayOfBenefitTypeEnum1[73] = TERM_LIFE;
    arrayOfBenefitTypeEnum1[74] = GAP_CARE;
    arrayOfBenefitTypeEnum1[75] = SPOUSE_CRITICAL_ILLNESS;
    arrayOfBenefitTypeEnum1[76] = CHILD_CRITICAL_ILLNESS;
    arrayOfBenefitTypeEnum1[77] = LTD;
    arrayOfBenefitTypeEnum1[78] = STD;
    arrayOfBenefitTypeEnum1[79] = VOLLTD;
    arrayOfBenefitTypeEnum1[80] = VOLSTD;
    arrayOfBenefitTypeEnum1[81] = TERM_10YEAR;
    arrayOfBenefitTypeEnum1[82] = EAP;
    arrayOfBenefitTypeEnum1[83] = TRAVEL;
    arrayOfBenefitTypeEnum1[84] = PARKING;
    arrayOfBenefitTypeEnum1[85] = PTO;
    arrayOfBenefitTypeEnum1[86] = RETIREMENT;
    arrayOfBenefitTypeEnum1[87] = PENSION;
    arrayOfBenefitTypeEnum1[88] = LTC;
    arrayOfBenefitTypeEnum1[89] = LTCD;
    arrayOfBenefitTypeEnum1[90] = GLTC;
    arrayOfBenefitTypeEnum1[91] = WHOLE_SPOUSE_LIFE;
    arrayOfBenefitTypeEnum1[92] = WHOLE_CHILD_LIFE;
    arrayOfBenefitTypeEnum1[93] = LEGAL;
    arrayOfBenefitTypeEnum1[94] = BASIC;
    arrayOfBenefitTypeEnum1[95] = TRADITIONAL_401K;
    arrayOfBenefitTypeEnum1[96] = TRADITIONAL_403B;
    arrayOfBenefitTypeEnum1[97] = ROTH_401K;
    arrayOfBenefitTypeEnum1[98] = ROTH_403B;
    arrayOfBenefitTypeEnum1[99] = GENERIC_CONTRIBUTORY;
    $VALUES = arrayOfBenefitTypeEnum1;
    valueMap = new HashMap();
    for (BenefitTypeEnum localBenefitTypeEnum : values())
      valueMap.put(localBenefitTypeEnum.getAtomicConstantValue(), localBenefitTypeEnum);
  }

  private BenefitTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static BenefitTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (BenefitTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.BenefitTypeEnum
 * JD-Core Version:    0.6.0
 */