package com.benefitfocus.api.constant.benefit;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum RemainingCreditSelectionEnum
  implements AtomicConstantEnum
{
  private static final Map<String, RemainingCreditSelectionEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    BENEFIT_TYPE = new RemainingCreditSelectionEnum("BENEFIT_TYPE", 1, "BENEFIT_TYPE");
    RemainingCreditSelectionEnum[] arrayOfRemainingCreditSelectionEnum1 = new RemainingCreditSelectionEnum[2];
    arrayOfRemainingCreditSelectionEnum1[0] = CASH;
    arrayOfRemainingCreditSelectionEnum1[1] = BENEFIT_TYPE;
    $VALUES = arrayOfRemainingCreditSelectionEnum1;
    valueMap = new HashMap();
    for (RemainingCreditSelectionEnum localRemainingCreditSelectionEnum : values())
      valueMap.put(localRemainingCreditSelectionEnum.getAtomicConstantValue(), localRemainingCreditSelectionEnum);
  }

  private RemainingCreditSelectionEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static RemainingCreditSelectionEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (RemainingCreditSelectionEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.RemainingCreditSelectionEnum
 * JD-Core Version:    0.6.0
 */