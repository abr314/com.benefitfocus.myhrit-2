package com.benefitfocus.api.constant.benefit;

public enum ProductSetTypeEnum
{
  static
  {
    SUBSET_OTHER = new ProductSetTypeEnum("SUBSET_OTHER", 2);
    UNIQUE_ID = new ProductSetTypeEnum("UNIQUE_ID", 3);
    ProductSetTypeEnum[] arrayOfProductSetTypeEnum = new ProductSetTypeEnum[4];
    arrayOfProductSetTypeEnum[0] = ALL;
    arrayOfProductSetTypeEnum[1] = SUBSET_QUOTABLE;
    arrayOfProductSetTypeEnum[2] = SUBSET_OTHER;
    arrayOfProductSetTypeEnum[3] = UNIQUE_ID;
    $VALUES = arrayOfProductSetTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.benefit.ProductSetTypeEnum
 * JD-Core Version:    0.6.0
 */