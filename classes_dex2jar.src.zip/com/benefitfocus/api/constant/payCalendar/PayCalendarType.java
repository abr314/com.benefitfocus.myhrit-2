package com.benefitfocus.api.constant.payCalendar;

public enum PayCalendarType
{
  static
  {
    PayCalendarType[] arrayOfPayCalendarType = new PayCalendarType[3];
    arrayOfPayCalendarType[0] = FLEX_DEDUCTION_CALENDAR;
    arrayOfPayCalendarType[1] = HSA_CALENDAR;
    arrayOfPayCalendarType[2] = PAY_CALENDAR;
    $VALUES = arrayOfPayCalendarType;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.payCalendar.PayCalendarType
 * JD-Core Version:    0.6.0
 */