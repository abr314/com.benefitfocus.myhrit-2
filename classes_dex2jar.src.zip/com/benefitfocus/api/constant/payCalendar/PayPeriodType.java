package com.benefitfocus.api.constant.payCalendar;

import com.benefitfocus.api.constant.AtomicConstantEnum;

public enum PayPeriodType
  implements AtomicConstantEnum
{
  private String atomicConstantValue;

  static
  {
    BIWEEKLY = new PayPeriodType("BIWEEKLY", 1, "26");
    SEMIMONTHLY = new PayPeriodType("SEMIMONTHLY", 2, "24");
    MONTHLY = new PayPeriodType("MONTHLY", 3, "12");
    PayPeriodType[] arrayOfPayPeriodType = new PayPeriodType[4];
    arrayOfPayPeriodType[0] = WEEKLY;
    arrayOfPayPeriodType[1] = BIWEEKLY;
    arrayOfPayPeriodType[2] = SEMIMONTHLY;
    arrayOfPayPeriodType[3] = MONTHLY;
    $VALUES = arrayOfPayPeriodType;
  }

  private PayPeriodType(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static PayPeriodType fromAtomicConstantValue(String paramString)
  {
    for (PayPeriodType localPayPeriodType : values())
      if (localPayPeriodType.atomicConstantValue.equals(paramString))
        return localPayPeriodType;
    return null;
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.payCalendar.PayPeriodType
 * JD-Core Version:    0.6.0
 */