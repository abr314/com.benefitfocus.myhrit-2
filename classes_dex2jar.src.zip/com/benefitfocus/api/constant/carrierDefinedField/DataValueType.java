package com.benefitfocus.api.constant.carrierDefinedField;

public enum DataValueType
{
  static
  {
    CURRENCY = new DataValueType("CURRENCY", 1);
    BOOLEAN = new DataValueType("BOOLEAN", 2);
    DATE = new DataValueType("DATE", 3);
    INTEGER = new DataValueType("INTEGER", 4);
    FLOAT = new DataValueType("FLOAT", 5);
    DOUBLE = new DataValueType("DOUBLE", 6);
    DataValueType[] arrayOfDataValueType = new DataValueType[7];
    arrayOfDataValueType[0] = STRING;
    arrayOfDataValueType[1] = CURRENCY;
    arrayOfDataValueType[2] = BOOLEAN;
    arrayOfDataValueType[3] = DATE;
    arrayOfDataValueType[4] = INTEGER;
    arrayOfDataValueType[5] = FLOAT;
    arrayOfDataValueType[6] = DOUBLE;
    $VALUES = arrayOfDataValueType;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.carrierDefinedField.DataValueType
 * JD-Core Version:    0.6.0
 */