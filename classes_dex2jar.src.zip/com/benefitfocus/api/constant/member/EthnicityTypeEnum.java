package com.benefitfocus.api.constant.member;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum EthnicityTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, EthnicityTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    PACIFIC_ISLANDER = new EthnicityTypeEnum("PACIFIC_ISLANDER", 9, "PACIFIC_ISLANDER");
    EthnicityTypeEnum[] arrayOfEthnicityTypeEnum1 = new EthnicityTypeEnum[10];
    arrayOfEthnicityTypeEnum1[0] = ASIAN;
    arrayOfEthnicityTypeEnum1[1] = BLACK;
    arrayOfEthnicityTypeEnum1[2] = CARIBBEAN_ISLANDER;
    arrayOfEthnicityTypeEnum1[3] = HISPANIC;
    arrayOfEthnicityTypeEnum1[4] = HISPANIC_NON_WHITE;
    arrayOfEthnicityTypeEnum1[5] = NATIVE_AMERICAN;
    arrayOfEthnicityTypeEnum1[6] = OTHER;
    arrayOfEthnicityTypeEnum1[7] = UNSPECIFIED;
    arrayOfEthnicityTypeEnum1[8] = WHITE;
    arrayOfEthnicityTypeEnum1[9] = PACIFIC_ISLANDER;
    $VALUES = arrayOfEthnicityTypeEnum1;
    valueMap = new HashMap();
    for (EthnicityTypeEnum localEthnicityTypeEnum : values())
      valueMap.put(localEthnicityTypeEnum.getAtomicConstantValue(), localEthnicityTypeEnum);
  }

  private EthnicityTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static EthnicityTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (EthnicityTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.member.EthnicityTypeEnum
 * JD-Core Version:    0.6.0
 */