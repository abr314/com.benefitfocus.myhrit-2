package com.benefitfocus.api.constant.member;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum MaritalStatusTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, MaritalStatusTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    SEPARATED = new MaritalStatusTypeEnum("SEPARATED", 3, "SEPARATED");
    WIDOWED = new MaritalStatusTypeEnum("WIDOWED", 4, "WIDOWED");
    MaritalStatusTypeEnum[] arrayOfMaritalStatusTypeEnum1 = new MaritalStatusTypeEnum[5];
    arrayOfMaritalStatusTypeEnum1[0] = DIVORCED;
    arrayOfMaritalStatusTypeEnum1[1] = MARRIED;
    arrayOfMaritalStatusTypeEnum1[2] = SINGLE;
    arrayOfMaritalStatusTypeEnum1[3] = SEPARATED;
    arrayOfMaritalStatusTypeEnum1[4] = WIDOWED;
    $VALUES = arrayOfMaritalStatusTypeEnum1;
    valueMap = new HashMap();
    for (MaritalStatusTypeEnum localMaritalStatusTypeEnum : values())
      valueMap.put(localMaritalStatusTypeEnum.getAtomicConstantValue(), localMaritalStatusTypeEnum);
  }

  private MaritalStatusTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static MaritalStatusTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (MaritalStatusTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.member.MaritalStatusTypeEnum
 * JD-Core Version:    0.6.0
 */