package com.benefitfocus.api.constant.member;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum GenderTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, GenderTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    GenderTypeEnum[] arrayOfGenderTypeEnum1 = new GenderTypeEnum[2];
    arrayOfGenderTypeEnum1[0] = FEMALE;
    arrayOfGenderTypeEnum1[1] = MALE;
    $VALUES = arrayOfGenderTypeEnum1;
    valueMap = new HashMap();
    for (GenderTypeEnum localGenderTypeEnum : values())
      valueMap.put(localGenderTypeEnum.getAtomicConstantValue(), localGenderTypeEnum);
  }

  private GenderTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static GenderTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (GenderTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.member.GenderTypeEnum
 * JD-Core Version:    0.6.0
 */