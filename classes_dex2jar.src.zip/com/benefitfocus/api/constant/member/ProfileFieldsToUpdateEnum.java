package com.benefitfocus.api.constant.member;

public enum ProfileFieldsToUpdateEnum
{
  static
  {
    HOME_PHONE = new ProfileFieldsToUpdateEnum("HOME_PHONE", 1);
    MOBILE_PHONE = new ProfileFieldsToUpdateEnum("MOBILE_PHONE", 2);
    ALTERNATE_PHONE = new ProfileFieldsToUpdateEnum("ALTERNATE_PHONE", 3);
    PERSONAL_EMAIL_ADDRESS = new ProfileFieldsToUpdateEnum("PERSONAL_EMAIL_ADDRESS", 4);
    ADDRESS = new ProfileFieldsToUpdateEnum("ADDRESS", 5);
    EMERGENCY_CONTACT = new ProfileFieldsToUpdateEnum("EMERGENCY_CONTACT", 6);
    ProfileFieldsToUpdateEnum[] arrayOfProfileFieldsToUpdateEnum = new ProfileFieldsToUpdateEnum[7];
    arrayOfProfileFieldsToUpdateEnum[0] = NAME;
    arrayOfProfileFieldsToUpdateEnum[1] = HOME_PHONE;
    arrayOfProfileFieldsToUpdateEnum[2] = MOBILE_PHONE;
    arrayOfProfileFieldsToUpdateEnum[3] = ALTERNATE_PHONE;
    arrayOfProfileFieldsToUpdateEnum[4] = PERSONAL_EMAIL_ADDRESS;
    arrayOfProfileFieldsToUpdateEnum[5] = ADDRESS;
    arrayOfProfileFieldsToUpdateEnum[6] = EMERGENCY_CONTACT;
    $VALUES = arrayOfProfileFieldsToUpdateEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.member.ProfileFieldsToUpdateEnum
 * JD-Core Version:    0.6.0
 */