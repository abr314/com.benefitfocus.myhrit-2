package com.benefitfocus.api.constant.tenant;

public enum TenantTypeEnum
{
  private String value;

  static
  {
    EMPLOYER_GROUP = new TenantTypeEnum("EMPLOYER_GROUP", 2, "EmployerGroup");
    MARKETPLACE_SB = new TenantTypeEnum("MARKETPLACE_SB", 3, "MarketplaceSB");
    TenantTypeEnum[] arrayOfTenantTypeEnum = new TenantTypeEnum[4];
    arrayOfTenantTypeEnum[0] = CARRIER_INDIVIDUAL_MARKET;
    arrayOfTenantTypeEnum[1] = STATE_EXCHANGE;
    arrayOfTenantTypeEnum[2] = EMPLOYER_GROUP;
    arrayOfTenantTypeEnum[3] = MARKETPLACE_SB;
    $VALUES = arrayOfTenantTypeEnum;
  }

  private TenantTypeEnum(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.tenant.TenantTypeEnum
 * JD-Core Version:    0.6.0
 */