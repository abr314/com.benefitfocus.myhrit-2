package com.benefitfocus.api.constant.service;

public enum WorkflowTaskAction
{
  static
  {
    WorkflowTaskAction[] arrayOfWorkflowTaskAction = new WorkflowTaskAction[1];
    arrayOfWorkflowTaskAction[0] = COMPLETE_TASK;
    $VALUES = arrayOfWorkflowTaskAction;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.service.WorkflowTaskAction
 * JD-Core Version:    0.6.0
 */