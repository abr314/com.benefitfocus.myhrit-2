package com.benefitfocus.api.constant.service;

public enum DataToReturnTypeEnum
{
  static
  {
    FAMILY = new DataToReturnTypeEnum("FAMILY", 1);
    BENEFITS = new DataToReturnTypeEnum("BENEFITS", 2);
    BILL_PACKAGE = new DataToReturnTypeEnum("BILL_PACKAGE", 3);
    PLAN_RATES = new DataToReturnTypeEnum("PLAN_RATES", 4);
    PLAN_ATTRIBUTES = new DataToReturnTypeEnum("PLAN_ATTRIBUTES", 5);
    INDIVIDUAL_RATES = new DataToReturnTypeEnum("INDIVIDUAL_RATES", 6);
    DataToReturnTypeEnum[] arrayOfDataToReturnTypeEnum = new DataToReturnTypeEnum[7];
    arrayOfDataToReturnTypeEnum[0] = PERSONAL_IDENTIFICATION;
    arrayOfDataToReturnTypeEnum[1] = FAMILY;
    arrayOfDataToReturnTypeEnum[2] = BENEFITS;
    arrayOfDataToReturnTypeEnum[3] = BILL_PACKAGE;
    arrayOfDataToReturnTypeEnum[4] = PLAN_RATES;
    arrayOfDataToReturnTypeEnum[5] = PLAN_ATTRIBUTES;
    arrayOfDataToReturnTypeEnum[6] = INDIVIDUAL_RATES;
    $VALUES = arrayOfDataToReturnTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.service.DataToReturnTypeEnum
 * JD-Core Version:    0.6.0
 */