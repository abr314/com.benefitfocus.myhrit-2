package com.benefitfocus.api.constant;

public abstract interface AtomicConstantEnum
{
  public abstract String getAtomicConstantValue();
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.AtomicConstantEnum
 * JD-Core Version:    0.6.0
 */