package com.benefitfocus.api.constant.security;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum UserGroupEnum
  implements AtomicConstantEnum
{
  private static final Map<String, UserGroupEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    AGENT = new UserGroupEnum("AGENT", 1, "AGENT");
    SPONSORADMIN = new UserGroupEnum("SPONSORADMIN", 2, "SPONSORADMIN");
    VISTA = new UserGroupEnum("VISTA", 3, "VISTA");
    MEMBER = new UserGroupEnum("MEMBER", 4, "MEMBER");
    CARRIERREP = new UserGroupEnum("CARRIERREP", 5, "CARRIERREP");
    SUPERUSER = new UserGroupEnum("SUPERUSER", 6, "SUPERUSER");
    CLIENTIMPLEMENTATION = new UserGroupEnum("CLIENTIMPLEMENTATION", 7, "CLIENTIMPL");
    CLIENTSERVICES = new UserGroupEnum("CLIENTSERVICES", 8, "CLIENTSVCS");
    DATASERVICES = new UserGroupEnum("DATASERVICES", 9, "DATASVCS");
    IMPORTSERVICES = new UserGroupEnum("IMPORTSERVICES", 10, "IMPORTSVCS");
    UNDERWRITER = new UserGroupEnum("UNDERWRITER", 11, "UNDERWRITER");
    PROSPECT = new UserGroupEnum("PROSPECT", 12, "PROSPECT");
    UserGroupEnum[] arrayOfUserGroupEnum1 = new UserGroupEnum[13];
    arrayOfUserGroupEnum1[0] = _4X;
    arrayOfUserGroupEnum1[1] = AGENT;
    arrayOfUserGroupEnum1[2] = SPONSORADMIN;
    arrayOfUserGroupEnum1[3] = VISTA;
    arrayOfUserGroupEnum1[4] = MEMBER;
    arrayOfUserGroupEnum1[5] = CARRIERREP;
    arrayOfUserGroupEnum1[6] = SUPERUSER;
    arrayOfUserGroupEnum1[7] = CLIENTIMPLEMENTATION;
    arrayOfUserGroupEnum1[8] = CLIENTSERVICES;
    arrayOfUserGroupEnum1[9] = DATASERVICES;
    arrayOfUserGroupEnum1[10] = IMPORTSERVICES;
    arrayOfUserGroupEnum1[11] = UNDERWRITER;
    arrayOfUserGroupEnum1[12] = PROSPECT;
    $VALUES = arrayOfUserGroupEnum1;
    valueMap = new HashMap();
    for (UserGroupEnum localUserGroupEnum : values())
      valueMap.put(localUserGroupEnum.getAtomicConstantValue(), localUserGroupEnum);
  }

  private UserGroupEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static UserGroupEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (UserGroupEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.security.UserGroupEnum
 * JD-Core Version:    0.6.0
 */