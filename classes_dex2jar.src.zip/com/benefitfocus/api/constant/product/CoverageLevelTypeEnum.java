package com.benefitfocus.api.constant.product;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum CoverageLevelTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, CoverageLevelTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    EE_FAMILY_REQ2_REQSPOUSE = new CoverageLevelTypeEnum("EE_FAMILY_REQ2_REQSPOUSE", 3, "20211-REQ(2)-MAX(999)");
    EE_FAMILY_REQ2_REQ_DP = new CoverageLevelTypeEnum("EE_FAMILY_REQ2_REQ_DP", 4, "21201-REQ(2)-MAX(999)");
    EE_PLUS_ONE_ADULT = new CoverageLevelTypeEnum("EE_PLUS_ONE_ADULT", 5, "22021-REQ(2)-MAX(2)");
    EE_FAMILY_REQ2_REQDP = new CoverageLevelTypeEnum("EE_FAMILY_REQ2_REQDP", 6, "01201-REQ(2)-MAX(999)");
    EMPLOYEE_PLUS_CHILD = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_CHILD", 7, "00201-REQ(2)-MAX(2)");
    EMPLOYEE_AND_DP_OPT_NO_OTHER = new CoverageLevelTypeEnum("EMPLOYEE_AND_DP_OPT_NO_OTHER", 8, "02001-REQ(2)-MAX(2)");
    EE_AND_REQSPOUSE = new CoverageLevelTypeEnum("EE_AND_REQSPOUSE", 9, "00011-REQ(2)-MAX(2)");
    EE_AND_SPOUSE = new CoverageLevelTypeEnum("EE_AND_SPOUSE", 10, "00021-REQ(2)-MAX(2)");
    EE_AND_SPOUSE_OR_DP = new CoverageLevelTypeEnum("EE_AND_SPOUSE_OR_DP", 11, "02021-REQ(2)-MAX(2)");
    EE_AND_REQDP = new CoverageLevelTypeEnum("EE_AND_REQDP", 12, "01001-REQ(2)-MAX(2)");
    EE_AND_DP_OR_OTHER = new CoverageLevelTypeEnum("EE_AND_DP_OR_OTHER", 13, "22001-REQ(2)-MAX(2)");
    EE_AND_CHILD_OR_OTHER = new CoverageLevelTypeEnum("EE_AND_CHILD_OR_OTHER", 14, "20201-REQ(2)-MAX(2)");
    EE_PLUS_1 = new CoverageLevelTypeEnum("EE_PLUS_1", 15, "22221-REQ(2)-MAX(2)");
    EE_PLUS_1_SPOUSE = new CoverageLevelTypeEnum("EE_PLUS_1_SPOUSE", 16, "00221-REQ(2)-MAX(2)");
    EE_PLUS_1_SPOUSE_DP = new CoverageLevelTypeEnum("EE_PLUS_1_SPOUSE_DP", 17, "02221-REQ(2)-MAX(2)");
    EE_PLUS_1_SPOUSE_OTHER = new CoverageLevelTypeEnum("EE_PLUS_1_SPOUSE_OTHER", 18, "20221-REQ(2)-MAX(2)");
    EE_PLUS_1_DP = new CoverageLevelTypeEnum("EE_PLUS_1_DP", 19, "02201-REQ(2)-MAX(2)");
    EE_PLUS_1_DP_OTHER = new CoverageLevelTypeEnum("EE_PLUS_1_DP_OTHER", 20, "22201-REQ(2)-MAX(2)");
    EE_CHILDREN_REQ2 = new CoverageLevelTypeEnum("EE_CHILDREN_REQ2", 21, "00201-REQ(2)-MAX(999)");
    EE_CHILDREN_OTHER_REQ2 = new CoverageLevelTypeEnum("EE_CHILDREN_OTHER_REQ2", 22, "20201-REQ(2)-MAX(999)");
    EE_FAMILY_2TIER_DP_SPOUSE_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_DP_SPOUSE_OTHER", 23, "22221-REQ(2)-MAX(999)");
    EE_CHILDREN_REQ3 = new CoverageLevelTypeEnum("EE_CHILDREN_REQ3", 24, "00201-REQ(3)-MAX(999)");
    EE_CHILDREN_REQ4 = new CoverageLevelTypeEnum("EE_CHILDREN_REQ4", 25, "00201-REQ(4)-MAX(999)");
    EE_CHILDREN_OTHER_REQ3 = new CoverageLevelTypeEnum("EE_CHILDREN_OTHER_REQ3", 26, "20201-REQ(3)-MAX(999)");
    EE_FAMILY_2TIER_DP = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_DP", 27, "02201-REQ(2)-MAX(999)");
    EE_FAMILY_2TIER_DP_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_DP_OTHER", 28, "22201-REQ(2)-MAX(999)");
    EE_FAMILY_2TIER_SPOUSE_DP = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_SPOUSE_DP", 29, "02221-REQ(2)-MAX(999)");
    EE_FAMILY_2TIER_SPOUSE_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_SPOUSE_OTHER", 30, "20221-REQ(2)-MAX(999)");
    EE_FAMILY_2TIER_SPOUSE = new CoverageLevelTypeEnum("EE_FAMILY_2TIER_SPOUSE", 31, "00221-REQ(2)-MAX(999)");
    EE_FAMILY_REQ3_REQSPOUSE = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_REQSPOUSE", 32, "00211-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_REQSPOUSE_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_REQSPOUSE_OTHER", 33, "20211-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_REQDP_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_REQDP_OTHER", 34, "21201-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_SPOUSE = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_SPOUSE", 35, "00221-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_SPOUSE_DP = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_SPOUSE_DP", 36, "02221-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_SPOUSE_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_SPOUSE_OTHER", 37, "20221-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_DP = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_DP", 38, "02201-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_REQDP = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_REQDP", 39, "01201-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_DP_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_DP_OTHER", 40, "22201-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_SPOUSE_DP_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_SPOUSE_DP_OTHER", 41, "22221-REQ(3)-MAX(999)");
    EE_FAMILY_REQ3_MAX3_SPOUSE_DP_OTHER = new CoverageLevelTypeEnum("EE_FAMILY_REQ3_MAX3_SPOUSE_DP_OTHER", 42, "22221-REQ(3)-MAX(3)");
    EE_FAMILY_REQ5_SPOUSE_DP = new CoverageLevelTypeEnum("EE_FAMILY_REQ5_SPOUSE_DP", 43, "02221-REQ(5)-MAX(999)");
    EMPLOYEE_AND_FAMILY_OPT_REQ3_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_AND_FAMILY_OPT_REQ3_MAX999", 44, "22211-REQ(3)-MAX(999)");
    EMPLOYEE_AND_SPOUSE_OPTIONAL_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_AND_SPOUSE_OPTIONAL_MAX999", 45, "00021-REQ(2)-MAX(999)");
    EMPLOYEE_AND_SPOUSE_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_AND_SPOUSE_MAX999", 46, "00011-REQ(2)-MAX(999)");
    EMPLOYEE_AND_FAMILY_REQ4_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_AND_FAMILY_REQ4_MAX999", 47, "20221-REQ(4)-MAX(999)");
    EMPLOYEE_AND_FAMILY_REQ3_MAX3 = new CoverageLevelTypeEnum("EMPLOYEE_AND_FAMILY_REQ3_MAX3", 48, "20221-REQ(3)-MAX(3)");
    EMPLOYEE_AND_SPOUSE_PLUS_1 = new CoverageLevelTypeEnum("EMPLOYEE_AND_SPOUSE_PLUS_1", 49, "00211-REQ(3)-MAX(3)");
    EMPLOYEE_AND_DP_PLUS_1 = new CoverageLevelTypeEnum("EMPLOYEE_AND_DP_PLUS_1", 50, "01201-REQ(3)-MAX(3)");
    EMPLOYEE_AND_DP_MAX_20 = new CoverageLevelTypeEnum("EMPLOYEE_AND_DP_MAX_20", 51, "01201-REQ(3)-MAX(20)");
    EMPLOYEE_AND_SPOUSE_PLUS_CHILDREN = new CoverageLevelTypeEnum("EMPLOYEE_AND_SPOUSE_PLUS_CHILDREN", 52, "00211-REQ(4)-MAX(999)");
    EMPLOYEE_AND_DP_PLUS_CHILDREN = new CoverageLevelTypeEnum("EMPLOYEE_AND_DP_PLUS_CHILDREN", 53, "01201-REQ(4)-MAX(999)");
    EMPLOYEE_PLUS_2 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_2", 54, "00221-REQ(3)-MAX(3)");
    EMPLOYEE_PLUS_2_MAX4 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_2_MAX4", 55, "00211-REQ(3)-MAX(4)");
    EMPLOYEE_PLUS_2_OTHER = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_2_OTHER", 56, "20221-REQ(3)-MAX(3)");
    EMPLOYEE_PLUS_3 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_3", 57, "00221-REQ(4)-MAX(4)");
    EMPLOYEE_PLUS_3_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_3_MAX999", 58, "00221-REQ(4)-MAX(999)");
    EMPLOYEE_PLUS_3_MAX999_OTHER = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_3_MAX999_OTHER", 59, "20221-REQ(4)-MAX(999)");
    SPOUSE_ONLY = new CoverageLevelTypeEnum("SPOUSE_ONLY", 60, "00010-REQ(1)-MAX(1)");
    CHILD_ONLY = new CoverageLevelTypeEnum("CHILD_ONLY", 61, "00200-REQ(1)-MAX(1)");
    CHILD_ONLY_MAX999 = new CoverageLevelTypeEnum("CHILD_ONLY_MAX999", 62, "00200-REQ(1)-MAX(999)");
    SPOUSE_AND_CHILDREN = new CoverageLevelTypeEnum("SPOUSE_AND_CHILDREN", 63, "00210-REQ(2)-MAX(999)");
    SPOUSE_CHILDREN_OTHER_REQ2 = new CoverageLevelTypeEnum("SPOUSE_CHILDREN_OTHER_REQ2", 64, "20210-REQ(2)-MAX(999)");
    SPOUSE_CHILDREN_OTHER_REQ2_DP = new CoverageLevelTypeEnum("SPOUSE_CHILDREN_OTHER_REQ2_DP", 65, "22220-REQ(2)-MAX(999)");
    SPOUSE_AND_CHILDREN_REQ3 = new CoverageLevelTypeEnum("SPOUSE_AND_CHILDREN_REQ3", 66, "00210-REQ(3)-MAX(999)");
    CHILDREN = new CoverageLevelTypeEnum("CHILDREN", 67, "00200-REQ(2)-MAX(999)");
    MISC1 = new CoverageLevelTypeEnum("MISC1", 68, "00221-REQ(3)-MAX(20)");
    MISC2 = new CoverageLevelTypeEnum("MISC2", 69, "00201-REQ(2)-MAX(20)");
    MISC3 = new CoverageLevelTypeEnum("MISC3", 70, "00211-REQ(2)-MAX(999)");
    SINGLE_DEPENDENT_COVERAGE = new CoverageLevelTypeEnum("SINGLE_DEPENDENT_COVERAGE", 71, "20000-REQ(1)-MAX(1)");
    OPTIONAL_SPOUSE_CHILDREN = new CoverageLevelTypeEnum("OPTIONAL_SPOUSE_CHILDREN", 72, "00220-REQ(1)-MAX(999)");
    SPOUSE_REQ3_DEPENDENT = new CoverageLevelTypeEnum("SPOUSE_REQ3_DEPENDENT", 73, "02221-REQ(3)-MAX(3)");
    SPOUSE_REQ3_MAX4_DEPENDENT = new CoverageLevelTypeEnum("SPOUSE_REQ3_MAX4_DEPENDENT", 74, "02221-REQ(3)-MAX(4)");
    SPOUSE_REQ4_DEPENDENT = new CoverageLevelTypeEnum("SPOUSE_REQ4_DEPENDENT", 75, "02221-REQ(4)-MAX(999)");
    SPOUSE_REQ2_DEPENDENT = new CoverageLevelTypeEnum("SPOUSE_REQ2_DEPENDENT", 76, "02220-REQ(2)-MAX(999)");
    SPOUSE_DP_ONLY = new CoverageLevelTypeEnum("SPOUSE_DP_ONLY", 77, "02020-REQ(1)-MAX(1)");
    SPOUSE_DEPENDENT_REQ2 = new CoverageLevelTypeEnum("SPOUSE_DEPENDENT_REQ2", 78, "00220-REQ(2)-MAX(999)");
    EMPLOYEE_PLUS_REQ2_MAX3 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_REQ2_MAX3", 79, "00221-REQ(2)-MAX(3)");
    EMPLOYEE_PLUS_REQ5_MAX999 = new CoverageLevelTypeEnum("EMPLOYEE_PLUS_REQ5_MAX999", 80, "00211-REQ(5)-MAX(999)");
    SINGLE_COVERAGE = new CoverageLevelTypeEnum("SINGLE_COVERAGE", 81, "22222-REQ(1)-MAX(1)");
    ADULT_PLUS_ONE = new CoverageLevelTypeEnum("ADULT_PLUS_ONE", 82, "22222-REQ(2)-MAX(2)");
    ADULT_PLUS_CHILD = new CoverageLevelTypeEnum("ADULT_PLUS_CHILD", 83, "02222-REQ(2)-MAX(2)");
    SPOUSE_AND_CHILD = new CoverageLevelTypeEnum("SPOUSE_AND_CHILD", 84, "00210-REQ(2)-MAX(2)");
    BASICLIFE = new CoverageLevelTypeEnum("BASICLIFE", 85, "BASICLIFE");
    SALARYBASEDLIFE = new CoverageLevelTypeEnum("SALARYBASEDLIFE", 86, "SALARYBASEDLIFE");
    UNIT = new CoverageLevelTypeEnum("UNIT", 87, "UNIT");
    CHILD_CHILDREN_ONLY = new CoverageLevelTypeEnum("CHILD_CHILDREN_ONLY", 88, "20200-REQ(1)-MAX(999)");
    DEPENDENT_ONLY = new CoverageLevelTypeEnum("DEPENDENT_ONLY", 89, "00220-REQ(1)-MAX(1)");
    TWO_DEPENDENTS = new CoverageLevelTypeEnum("TWO_DEPENDENTS", 90, "00220-REQ(2)-MAX(2)");
    THREE_DEPENDENTS = new CoverageLevelTypeEnum("THREE_DEPENDENTS", 91, "00220-REQ(3)-MAX(3)");
    THREE_OR_MORE_DEPENDENTS = new CoverageLevelTypeEnum("THREE_OR_MORE_DEPENDENTS", 92, "00220-REQ(3)-MAX(999)");
    FOUR_OR_MORE_DEPENDENTS = new CoverageLevelTypeEnum("FOUR_OR_MORE_DEPENDENTS", 93, "00220-REQ(4)-MAX(999)");
    DEPENDENT_ONLY_DP = new CoverageLevelTypeEnum("DEPENDENT_ONLY_DP", 94, "02220-REQ(1)-MAX(1)");
    TWO_DEPENDENTS_DP = new CoverageLevelTypeEnum("TWO_DEPENDENTS_DP", 95, "02220-REQ(2)-MAX(2)");
    THREE_DEPENDENTS_DP = new CoverageLevelTypeEnum("THREE_DEPENDENTS_DP", 96, "02220-REQ(3)-MAX(3)");
    THREE_OR_MORE_DEPENDENTS_DP = new CoverageLevelTypeEnum("THREE_OR_MORE_DEPENDENTS_DP", 97, "02220-REQ(3)-MAX(999)");
    FOUR_OR_MORE_DEPENDENTS_DP = new CoverageLevelTypeEnum("FOUR_OR_MORE_DEPENDENTS_DP", 98, "02220-REQ(4)-MAX(999)");
    EE_CHILDREN_PLUS_CHILD_OF_DP = new CoverageLevelTypeEnum("EE_CHILDREN_PLUS_CHILD_OF_DP", 99, "00101-REQ(2)-MAX(999)");
    EE_FAMILY_PLUS_CHILD_OF_DP = new CoverageLevelTypeEnum("EE_FAMILY_PLUS_CHILD_OF_DP", 100, "02121-REQ(3)-MAX(999)");
    EE_CHILDREN_PLUS_REQ3_CHILD_OF_DP = new CoverageLevelTypeEnum("EE_CHILDREN_PLUS_REQ3_CHILD_OF_DP", 101, "00101-REQ(4)-MAX(999)");
    EE_FAMILY_PLUS_REQ3_CHILD_OF_DP = new CoverageLevelTypeEnum("EE_FAMILY_PLUS_REQ3_CHILD_OF_DP", 102, "02121-REQ(4)-MAX(999)");
    CoverageLevelTypeEnum[] arrayOfCoverageLevelTypeEnum1 = new CoverageLevelTypeEnum[103];
    arrayOfCoverageLevelTypeEnum1[0] = DOMESTIC_PARTNER_ONLY;
    arrayOfCoverageLevelTypeEnum1[1] = EMPLOYEE_AND_CHILDREN_REQ2_MAX3;
    arrayOfCoverageLevelTypeEnum1[2] = EMPLOYEE_ONLY;
    arrayOfCoverageLevelTypeEnum1[3] = EE_FAMILY_REQ2_REQSPOUSE;
    arrayOfCoverageLevelTypeEnum1[4] = EE_FAMILY_REQ2_REQ_DP;
    arrayOfCoverageLevelTypeEnum1[5] = EE_PLUS_ONE_ADULT;
    arrayOfCoverageLevelTypeEnum1[6] = EE_FAMILY_REQ2_REQDP;
    arrayOfCoverageLevelTypeEnum1[7] = EMPLOYEE_PLUS_CHILD;
    arrayOfCoverageLevelTypeEnum1[8] = EMPLOYEE_AND_DP_OPT_NO_OTHER;
    arrayOfCoverageLevelTypeEnum1[9] = EE_AND_REQSPOUSE;
    arrayOfCoverageLevelTypeEnum1[10] = EE_AND_SPOUSE;
    arrayOfCoverageLevelTypeEnum1[11] = EE_AND_SPOUSE_OR_DP;
    arrayOfCoverageLevelTypeEnum1[12] = EE_AND_REQDP;
    arrayOfCoverageLevelTypeEnum1[13] = EE_AND_DP_OR_OTHER;
    arrayOfCoverageLevelTypeEnum1[14] = EE_AND_CHILD_OR_OTHER;
    arrayOfCoverageLevelTypeEnum1[15] = EE_PLUS_1;
    arrayOfCoverageLevelTypeEnum1[16] = EE_PLUS_1_SPOUSE;
    arrayOfCoverageLevelTypeEnum1[17] = EE_PLUS_1_SPOUSE_DP;
    arrayOfCoverageLevelTypeEnum1[18] = EE_PLUS_1_SPOUSE_OTHER;
    arrayOfCoverageLevelTypeEnum1[19] = EE_PLUS_1_DP;
    arrayOfCoverageLevelTypeEnum1[20] = EE_PLUS_1_DP_OTHER;
    arrayOfCoverageLevelTypeEnum1[21] = EE_CHILDREN_REQ2;
    arrayOfCoverageLevelTypeEnum1[22] = EE_CHILDREN_OTHER_REQ2;
    arrayOfCoverageLevelTypeEnum1[23] = EE_FAMILY_2TIER_DP_SPOUSE_OTHER;
    arrayOfCoverageLevelTypeEnum1[24] = EE_CHILDREN_REQ3;
    arrayOfCoverageLevelTypeEnum1[25] = EE_CHILDREN_REQ4;
    arrayOfCoverageLevelTypeEnum1[26] = EE_CHILDREN_OTHER_REQ3;
    arrayOfCoverageLevelTypeEnum1[27] = EE_FAMILY_2TIER_DP;
    arrayOfCoverageLevelTypeEnum1[28] = EE_FAMILY_2TIER_DP_OTHER;
    arrayOfCoverageLevelTypeEnum1[29] = EE_FAMILY_2TIER_SPOUSE_DP;
    arrayOfCoverageLevelTypeEnum1[30] = EE_FAMILY_2TIER_SPOUSE_OTHER;
    arrayOfCoverageLevelTypeEnum1[31] = EE_FAMILY_2TIER_SPOUSE;
    arrayOfCoverageLevelTypeEnum1[32] = EE_FAMILY_REQ3_REQSPOUSE;
    arrayOfCoverageLevelTypeEnum1[33] = EE_FAMILY_REQ3_REQSPOUSE_OTHER;
    arrayOfCoverageLevelTypeEnum1[34] = EE_FAMILY_REQ3_REQDP_OTHER;
    arrayOfCoverageLevelTypeEnum1[35] = EE_FAMILY_REQ3_SPOUSE;
    arrayOfCoverageLevelTypeEnum1[36] = EE_FAMILY_REQ3_SPOUSE_DP;
    arrayOfCoverageLevelTypeEnum1[37] = EE_FAMILY_REQ3_SPOUSE_OTHER;
    arrayOfCoverageLevelTypeEnum1[38] = EE_FAMILY_REQ3_DP;
    arrayOfCoverageLevelTypeEnum1[39] = EE_FAMILY_REQ3_REQDP;
    arrayOfCoverageLevelTypeEnum1[40] = EE_FAMILY_REQ3_DP_OTHER;
    arrayOfCoverageLevelTypeEnum1[41] = EE_FAMILY_REQ3_SPOUSE_DP_OTHER;
    arrayOfCoverageLevelTypeEnum1[42] = EE_FAMILY_REQ3_MAX3_SPOUSE_DP_OTHER;
    arrayOfCoverageLevelTypeEnum1[43] = EE_FAMILY_REQ5_SPOUSE_DP;
    arrayOfCoverageLevelTypeEnum1[44] = EMPLOYEE_AND_FAMILY_OPT_REQ3_MAX999;
    arrayOfCoverageLevelTypeEnum1[45] = EMPLOYEE_AND_SPOUSE_OPTIONAL_MAX999;
    arrayOfCoverageLevelTypeEnum1[46] = EMPLOYEE_AND_SPOUSE_MAX999;
    arrayOfCoverageLevelTypeEnum1[47] = EMPLOYEE_AND_FAMILY_REQ4_MAX999;
    arrayOfCoverageLevelTypeEnum1[48] = EMPLOYEE_AND_FAMILY_REQ3_MAX3;
    arrayOfCoverageLevelTypeEnum1[49] = EMPLOYEE_AND_SPOUSE_PLUS_1;
    arrayOfCoverageLevelTypeEnum1[50] = EMPLOYEE_AND_DP_PLUS_1;
    arrayOfCoverageLevelTypeEnum1[51] = EMPLOYEE_AND_DP_MAX_20;
    arrayOfCoverageLevelTypeEnum1[52] = EMPLOYEE_AND_SPOUSE_PLUS_CHILDREN;
    arrayOfCoverageLevelTypeEnum1[53] = EMPLOYEE_AND_DP_PLUS_CHILDREN;
    arrayOfCoverageLevelTypeEnum1[54] = EMPLOYEE_PLUS_2;
    arrayOfCoverageLevelTypeEnum1[55] = EMPLOYEE_PLUS_2_MAX4;
    arrayOfCoverageLevelTypeEnum1[56] = EMPLOYEE_PLUS_2_OTHER;
    arrayOfCoverageLevelTypeEnum1[57] = EMPLOYEE_PLUS_3;
    arrayOfCoverageLevelTypeEnum1[58] = EMPLOYEE_PLUS_3_MAX999;
    arrayOfCoverageLevelTypeEnum1[59] = EMPLOYEE_PLUS_3_MAX999_OTHER;
    arrayOfCoverageLevelTypeEnum1[60] = SPOUSE_ONLY;
    arrayOfCoverageLevelTypeEnum1[61] = CHILD_ONLY;
    arrayOfCoverageLevelTypeEnum1[62] = CHILD_ONLY_MAX999;
    arrayOfCoverageLevelTypeEnum1[63] = SPOUSE_AND_CHILDREN;
    arrayOfCoverageLevelTypeEnum1[64] = SPOUSE_CHILDREN_OTHER_REQ2;
    arrayOfCoverageLevelTypeEnum1[65] = SPOUSE_CHILDREN_OTHER_REQ2_DP;
    arrayOfCoverageLevelTypeEnum1[66] = SPOUSE_AND_CHILDREN_REQ3;
    arrayOfCoverageLevelTypeEnum1[67] = CHILDREN;
    arrayOfCoverageLevelTypeEnum1[68] = MISC1;
    arrayOfCoverageLevelTypeEnum1[69] = MISC2;
    arrayOfCoverageLevelTypeEnum1[70] = MISC3;
    arrayOfCoverageLevelTypeEnum1[71] = SINGLE_DEPENDENT_COVERAGE;
    arrayOfCoverageLevelTypeEnum1[72] = OPTIONAL_SPOUSE_CHILDREN;
    arrayOfCoverageLevelTypeEnum1[73] = SPOUSE_REQ3_DEPENDENT;
    arrayOfCoverageLevelTypeEnum1[74] = SPOUSE_REQ3_MAX4_DEPENDENT;
    arrayOfCoverageLevelTypeEnum1[75] = SPOUSE_REQ4_DEPENDENT;
    arrayOfCoverageLevelTypeEnum1[76] = SPOUSE_REQ2_DEPENDENT;
    arrayOfCoverageLevelTypeEnum1[77] = SPOUSE_DP_ONLY;
    arrayOfCoverageLevelTypeEnum1[78] = SPOUSE_DEPENDENT_REQ2;
    arrayOfCoverageLevelTypeEnum1[79] = EMPLOYEE_PLUS_REQ2_MAX3;
    arrayOfCoverageLevelTypeEnum1[80] = EMPLOYEE_PLUS_REQ5_MAX999;
    arrayOfCoverageLevelTypeEnum1[81] = SINGLE_COVERAGE;
    arrayOfCoverageLevelTypeEnum1[82] = ADULT_PLUS_ONE;
    arrayOfCoverageLevelTypeEnum1[83] = ADULT_PLUS_CHILD;
    arrayOfCoverageLevelTypeEnum1[84] = SPOUSE_AND_CHILD;
    arrayOfCoverageLevelTypeEnum1[85] = BASICLIFE;
    arrayOfCoverageLevelTypeEnum1[86] = SALARYBASEDLIFE;
    arrayOfCoverageLevelTypeEnum1[87] = UNIT;
    arrayOfCoverageLevelTypeEnum1[88] = CHILD_CHILDREN_ONLY;
    arrayOfCoverageLevelTypeEnum1[89] = DEPENDENT_ONLY;
    arrayOfCoverageLevelTypeEnum1[90] = TWO_DEPENDENTS;
    arrayOfCoverageLevelTypeEnum1[91] = THREE_DEPENDENTS;
    arrayOfCoverageLevelTypeEnum1[92] = THREE_OR_MORE_DEPENDENTS;
    arrayOfCoverageLevelTypeEnum1[93] = FOUR_OR_MORE_DEPENDENTS;
    arrayOfCoverageLevelTypeEnum1[94] = DEPENDENT_ONLY_DP;
    arrayOfCoverageLevelTypeEnum1[95] = TWO_DEPENDENTS_DP;
    arrayOfCoverageLevelTypeEnum1[96] = THREE_DEPENDENTS_DP;
    arrayOfCoverageLevelTypeEnum1[97] = THREE_OR_MORE_DEPENDENTS_DP;
    arrayOfCoverageLevelTypeEnum1[98] = FOUR_OR_MORE_DEPENDENTS_DP;
    arrayOfCoverageLevelTypeEnum1[99] = EE_CHILDREN_PLUS_CHILD_OF_DP;
    arrayOfCoverageLevelTypeEnum1[100] = EE_FAMILY_PLUS_CHILD_OF_DP;
    arrayOfCoverageLevelTypeEnum1[101] = EE_CHILDREN_PLUS_REQ3_CHILD_OF_DP;
    arrayOfCoverageLevelTypeEnum1[102] = EE_FAMILY_PLUS_REQ3_CHILD_OF_DP;
    $VALUES = arrayOfCoverageLevelTypeEnum1;
    valueMap = new HashMap();
    for (CoverageLevelTypeEnum localCoverageLevelTypeEnum : values())
      valueMap.put(localCoverageLevelTypeEnum.getAtomicConstantValue(), localCoverageLevelTypeEnum);
  }

  private CoverageLevelTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static CoverageLevelTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (CoverageLevelTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.product.CoverageLevelTypeEnum
 * JD-Core Version:    0.6.0
 */