package com.benefitfocus.api.constant.product;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum AttributeValueTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, AttributeValueTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    MULTI_SELECT = new AttributeValueTypeEnum("MULTI_SELECT", 1, "MULTI_SELECT");
    CURRENCY = new AttributeValueTypeEnum("CURRENCY", 2, "CURRENCY");
    NUMBER = new AttributeValueTypeEnum("NUMBER", 3, "NUMBER");
    BOOLEAN = new AttributeValueTypeEnum("BOOLEAN", 4, "BOOLEAN");
    DATE = new AttributeValueTypeEnum("DATE", 5, "DATE");
    DATE_STRING = new AttributeValueTypeEnum("DATE_STRING", 6, "DATE_STRING");
    CONSTANT = new AttributeValueTypeEnum("CONSTANT", 7, "CONSTANT");
    PERCENTAGE = new AttributeValueTypeEnum("PERCENTAGE", 8, "PERCENTAGE");
    FREE_FORM_TEXT = new AttributeValueTypeEnum("FREE_FORM_TEXT", 9, "FREE_FORM_TEXT");
    FREE_FORM_TEXT_SHORT = new AttributeValueTypeEnum("FREE_FORM_TEXT_SHORT", 10, "FREE_FORM_TEXT");
    AttributeValueTypeEnum[] arrayOfAttributeValueTypeEnum1 = new AttributeValueTypeEnum[11];
    arrayOfAttributeValueTypeEnum1[0] = STRING;
    arrayOfAttributeValueTypeEnum1[1] = MULTI_SELECT;
    arrayOfAttributeValueTypeEnum1[2] = CURRENCY;
    arrayOfAttributeValueTypeEnum1[3] = NUMBER;
    arrayOfAttributeValueTypeEnum1[4] = BOOLEAN;
    arrayOfAttributeValueTypeEnum1[5] = DATE;
    arrayOfAttributeValueTypeEnum1[6] = DATE_STRING;
    arrayOfAttributeValueTypeEnum1[7] = CONSTANT;
    arrayOfAttributeValueTypeEnum1[8] = PERCENTAGE;
    arrayOfAttributeValueTypeEnum1[9] = FREE_FORM_TEXT;
    arrayOfAttributeValueTypeEnum1[10] = FREE_FORM_TEXT_SHORT;
    $VALUES = arrayOfAttributeValueTypeEnum1;
    valueMap = new HashMap();
    for (AttributeValueTypeEnum localAttributeValueTypeEnum : values())
      valueMap.put(localAttributeValueTypeEnum.getAtomicConstantValue(), localAttributeValueTypeEnum);
  }

  private AttributeValueTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static AttributeValueTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (AttributeValueTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.product.AttributeValueTypeEnum
 * JD-Core Version:    0.6.0
 */