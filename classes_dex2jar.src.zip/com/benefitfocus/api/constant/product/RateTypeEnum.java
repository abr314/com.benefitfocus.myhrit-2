package com.benefitfocus.api.constant.product;

public enum RateTypeEnum
{
  static
  {
    RateTypeEnum[] arrayOfRateTypeEnum = new RateTypeEnum[3];
    arrayOfRateTypeEnum[0] = COMPOSITE;
    arrayOfRateTypeEnum[1] = INDIVIDUAL;
    arrayOfRateTypeEnum[2] = TABULAR;
    $VALUES = arrayOfRateTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.product.RateTypeEnum
 * JD-Core Version:    0.6.0
 */