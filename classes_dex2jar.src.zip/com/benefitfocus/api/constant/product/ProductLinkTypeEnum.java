package com.benefitfocus.api.constant.product;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum ProductLinkTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, ProductLinkTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    ADDITIONAL = new ProductLinkTypeEnum("ADDITIONAL", 1, "ADDITIONAL");
    ProductLinkTypeEnum[] arrayOfProductLinkTypeEnum1 = new ProductLinkTypeEnum[2];
    arrayOfProductLinkTypeEnum1[0] = PRIMARY;
    arrayOfProductLinkTypeEnum1[1] = ADDITIONAL;
    $VALUES = arrayOfProductLinkTypeEnum1;
    valueMap = new HashMap();
    for (ProductLinkTypeEnum localProductLinkTypeEnum : values())
      valueMap.put(localProductLinkTypeEnum.getAtomicConstantValue(), localProductLinkTypeEnum);
  }

  private ProductLinkTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static ProductLinkTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (ProductLinkTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.product.ProductLinkTypeEnum
 * JD-Core Version:    0.6.0
 */