package com.benefitfocus.api.constant.product;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum RelationshipTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, RelationshipTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    SPOUSE = new RelationshipTypeEnum("SPOUSE", 1, "SPOUSE");
    FORMER_SPOUSE = new RelationshipTypeEnum("FORMER_SPOUSE", 2, "FORMER SPOUSE");
    COMMON_LAW_SPOUSE = new RelationshipTypeEnum("COMMON_LAW_SPOUSE", 3, "COMMON LAW SPOUSE");
    DOMESTICPARTNER = new RelationshipTypeEnum("DOMESTICPARTNER", 4, "DOMESTIC PARTNER");
    DOMESTIC_PARTNER_AFFIDAVIT_REQUIRED = new RelationshipTypeEnum("DOMESTIC_PARTNER_AFFIDAVIT_REQUIRED", 5, "DOMESTIC PARTNER AFFIDAVIT REQUIRED");
    SPONSORED_DEPENDENT = new RelationshipTypeEnum("SPONSORED_DEPENDENT", 6, "SPONSORED DEPENDENT");
    LEGALLY_DOMICILED_ADULT_RELATED = new RelationshipTypeEnum("LEGALLY_DOMICILED_ADULT_RELATED", 7, "LEGALLY_DOMICILED_ADULT_RELATED");
    LEGALLY_DOMICILED_ADULT_UNRELATED_TAXABLE = new RelationshipTypeEnum("LEGALLY_DOMICILED_ADULT_UNRELATED_TAXABLE", 8, "LEGALLY_DOMICILED_ADULT_UNRELATED_TAXABLE");
    LEGALLY_DOMICILED_ADULT_UNRELATED_NONTAXABLE = new RelationshipTypeEnum("LEGALLY_DOMICILED_ADULT_UNRELATED_NONTAXABLE", 9, "LEGALLY_DOMICILED_ADULT_UNRELATED_NONTAXABLE");
    SPONSORED_ADULT_DEPENDENT = new RelationshipTypeEnum("SPONSORED_ADULT_DEPENDENT", 10, "SPONSORED ADULT DEPENDENT");
    EX_SPOUSE = new RelationshipTypeEnum("EX_SPOUSE", 11, "EX SPOUSE");
    CIVIL_UNION_PARTNER = new RelationshipTypeEnum("CIVIL_UNION_PARTNER", 12, "CIVIL UNION PARTNER");
    LEGAL_PARTNER = new RelationshipTypeEnum("LEGAL_PARTNER", 13, "LEGAL PARTNER");
    CHILD = new RelationshipTypeEnum("CHILD", 14, "CHILD");
    ADOPTED_CHILD = new RelationshipTypeEnum("ADOPTED_CHILD", 15, "ADOPTED CHILD");
    DISABLEDCHILD = new RelationshipTypeEnum("DISABLEDCHILD", 16, "DISABLED CHILD");
    STUDENT = new RelationshipTypeEnum("STUDENT", 17, "STUDENT");
    STEP_CHILD = new RelationshipTypeEnum("STEP_CHILD", 18, "STEP CHILD");
    CHILD_VIA_COURT_ORDER = new RelationshipTypeEnum("CHILD_VIA_COURT_ORDER", 19, "CHILD VIA COURT ORDER");
    OVER_AGE_DEPENDENT = new RelationshipTypeEnum("OVER_AGE_DEPENDENT", 20, "OVER AGE DEPENDENT");
    OVERAGE_DISABLED_DEPENDENT = new RelationshipTypeEnum("OVERAGE_DISABLED_DEPENDENT", 21, "OVERAGE DISABLED DEPENDENT");
    DEPENDENT_CHILD_VIA_LEGAL_CUSTODY = new RelationshipTypeEnum("DEPENDENT_CHILD_VIA_LEGAL_CUSTODY", 22, "DEPENDENT CHILD VIA LEGAL CUSTODY");
    DOMESTIC_PARTNER_STUDENT = new RelationshipTypeEnum("DOMESTIC_PARTNER_STUDENT", 23, "DOMESTIC PARTNER STUDENT");
    DOMESTIC_PARTNER_CHILD = new RelationshipTypeEnum("DOMESTIC_PARTNER_CHILD", 24, "DOMESTIC PARTNER CHILD");
    DOMESTIC_PARTNER_STEPCHILD = new RelationshipTypeEnum("DOMESTIC_PARTNER_STEPCHILD", 25, "DOMESTIC PARTNER STEPCHILD");
    DOMESTIC_PARTNER_ADOPTED_CHILD = new RelationshipTypeEnum("DOMESTIC_PARTNER_ADOPTED_CHILD", 26, "DOMESTIC PARTNER ADOPTED CHILD");
    DOMESTIC_PARTNER_DISABLED_CHILD = new RelationshipTypeEnum("DOMESTIC_PARTNER_DISABLED_CHILD", 27, "DOMESTIC PARTNER DISABLED CHILD");
    LEGALLY_DOMICILED_CHILD_TAXABLE = new RelationshipTypeEnum("LEGALLY_DOMICILED_CHILD_TAXABLE", 28, "LEGALLY_DOMICILED_CHILD_TAXABLE");
    LEGALLY_DOMICILED_CHILD_NONTAXABLE = new RelationshipTypeEnum("LEGALLY_DOMICILED_CHILD_NONTAXABLE", 29, "LEGALLY_DOMICILED_CHILD_NONTAXABLE");
    FOSTER_CHILD = new RelationshipTypeEnum("FOSTER_CHILD", 30, "FOSTER CHILD");
    ADULT_CHILD = new RelationshipTypeEnum("ADULT_CHILD", 31, "ADULT_CHILD");
    GRANDCHILD = new RelationshipTypeEnum("GRANDCHILD", 32, "GRANDCHILD");
    STEP_CHILD_OVERAGE_DEPENDENT = new RelationshipTypeEnum("STEP_CHILD_OVERAGE_DEPENDENT", 33, "STEP CHILD OVERAGE DEPENDENT");
    STEP_CHILD_STUDENT = new RelationshipTypeEnum("STEP_CHILD_STUDENT", 34, "STEP CHILD STUDENT");
    SPONSORED_CHILD_DEPENDENT = new RelationshipTypeEnum("SPONSORED_CHILD_DEPENDENT", 35, "SPONSORED CHILD DEPENDENT");
    SAME_SEX_SPOUSE_CHILD = new RelationshipTypeEnum("SAME_SEX_SPOUSE_CHILD", 36, "SAME SEX SPOUSE CHILD");
    SAME_SEX_SPOUSE_STUDENT = new RelationshipTypeEnum("SAME_SEX_SPOUSE_STUDENT", 37, "SAME SEX SPOUSE STUDENT");
    OTHER = new RelationshipTypeEnum("OTHER", 38, "OTHER");
    OVERAGE_CHILD = new RelationshipTypeEnum("OVERAGE_CHILD", 39, "OVERAGE CHILD");
    MOTHER_OF_EMPLOYEE = new RelationshipTypeEnum("MOTHER_OF_EMPLOYEE", 40, "MOTHER OF EMPLOYEE");
    FATHER_OF_EMPLOYEE = new RelationshipTypeEnum("FATHER_OF_EMPLOYEE", 41, "FATHER OF EMPLOYEE");
    MOTHER_OF_SPOUSE = new RelationshipTypeEnum("MOTHER_OF_SPOUSE", 42, "MOTHER OF SPOUSE");
    FATHER_OF_SPOUSE = new RelationshipTypeEnum("FATHER_OF_SPOUSE", 43, "FATHER OF SPOUSE");
    RelationshipTypeEnum[] arrayOfRelationshipTypeEnum1 = new RelationshipTypeEnum[44];
    arrayOfRelationshipTypeEnum1[0] = SUBSCRIBER;
    arrayOfRelationshipTypeEnum1[1] = SPOUSE;
    arrayOfRelationshipTypeEnum1[2] = FORMER_SPOUSE;
    arrayOfRelationshipTypeEnum1[3] = COMMON_LAW_SPOUSE;
    arrayOfRelationshipTypeEnum1[4] = DOMESTICPARTNER;
    arrayOfRelationshipTypeEnum1[5] = DOMESTIC_PARTNER_AFFIDAVIT_REQUIRED;
    arrayOfRelationshipTypeEnum1[6] = SPONSORED_DEPENDENT;
    arrayOfRelationshipTypeEnum1[7] = LEGALLY_DOMICILED_ADULT_RELATED;
    arrayOfRelationshipTypeEnum1[8] = LEGALLY_DOMICILED_ADULT_UNRELATED_TAXABLE;
    arrayOfRelationshipTypeEnum1[9] = LEGALLY_DOMICILED_ADULT_UNRELATED_NONTAXABLE;
    arrayOfRelationshipTypeEnum1[10] = SPONSORED_ADULT_DEPENDENT;
    arrayOfRelationshipTypeEnum1[11] = EX_SPOUSE;
    arrayOfRelationshipTypeEnum1[12] = CIVIL_UNION_PARTNER;
    arrayOfRelationshipTypeEnum1[13] = LEGAL_PARTNER;
    arrayOfRelationshipTypeEnum1[14] = CHILD;
    arrayOfRelationshipTypeEnum1[15] = ADOPTED_CHILD;
    arrayOfRelationshipTypeEnum1[16] = DISABLEDCHILD;
    arrayOfRelationshipTypeEnum1[17] = STUDENT;
    arrayOfRelationshipTypeEnum1[18] = STEP_CHILD;
    arrayOfRelationshipTypeEnum1[19] = CHILD_VIA_COURT_ORDER;
    arrayOfRelationshipTypeEnum1[20] = OVER_AGE_DEPENDENT;
    arrayOfRelationshipTypeEnum1[21] = OVERAGE_DISABLED_DEPENDENT;
    arrayOfRelationshipTypeEnum1[22] = DEPENDENT_CHILD_VIA_LEGAL_CUSTODY;
    arrayOfRelationshipTypeEnum1[23] = DOMESTIC_PARTNER_STUDENT;
    arrayOfRelationshipTypeEnum1[24] = DOMESTIC_PARTNER_CHILD;
    arrayOfRelationshipTypeEnum1[25] = DOMESTIC_PARTNER_STEPCHILD;
    arrayOfRelationshipTypeEnum1[26] = DOMESTIC_PARTNER_ADOPTED_CHILD;
    arrayOfRelationshipTypeEnum1[27] = DOMESTIC_PARTNER_DISABLED_CHILD;
    arrayOfRelationshipTypeEnum1[28] = LEGALLY_DOMICILED_CHILD_TAXABLE;
    arrayOfRelationshipTypeEnum1[29] = LEGALLY_DOMICILED_CHILD_NONTAXABLE;
    arrayOfRelationshipTypeEnum1[30] = FOSTER_CHILD;
    arrayOfRelationshipTypeEnum1[31] = ADULT_CHILD;
    arrayOfRelationshipTypeEnum1[32] = GRANDCHILD;
    arrayOfRelationshipTypeEnum1[33] = STEP_CHILD_OVERAGE_DEPENDENT;
    arrayOfRelationshipTypeEnum1[34] = STEP_CHILD_STUDENT;
    arrayOfRelationshipTypeEnum1[35] = SPONSORED_CHILD_DEPENDENT;
    arrayOfRelationshipTypeEnum1[36] = SAME_SEX_SPOUSE_CHILD;
    arrayOfRelationshipTypeEnum1[37] = SAME_SEX_SPOUSE_STUDENT;
    arrayOfRelationshipTypeEnum1[38] = OTHER;
    arrayOfRelationshipTypeEnum1[39] = OVERAGE_CHILD;
    arrayOfRelationshipTypeEnum1[40] = MOTHER_OF_EMPLOYEE;
    arrayOfRelationshipTypeEnum1[41] = FATHER_OF_EMPLOYEE;
    arrayOfRelationshipTypeEnum1[42] = MOTHER_OF_SPOUSE;
    arrayOfRelationshipTypeEnum1[43] = FATHER_OF_SPOUSE;
    $VALUES = arrayOfRelationshipTypeEnum1;
    valueMap = new HashMap();
    for (RelationshipTypeEnum localRelationshipTypeEnum : values())
      valueMap.put(localRelationshipTypeEnum.getAtomicConstantValue(), localRelationshipTypeEnum);
  }

  private RelationshipTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static RelationshipTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (RelationshipTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.product.RelationshipTypeEnum
 * JD-Core Version:    0.6.0
 */