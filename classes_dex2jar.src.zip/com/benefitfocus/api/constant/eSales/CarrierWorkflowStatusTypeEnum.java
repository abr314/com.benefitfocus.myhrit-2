package com.benefitfocus.api.constant.eSales;

import com.benefitfocus.api.constant.AtomicConstantEnum;

public enum CarrierWorkflowStatusTypeEnum
  implements AtomicConstantEnum
{
  static
  {
    CarrierWorkflowStatusTypeEnum[] arrayOfCarrierWorkflowStatusTypeEnum = new CarrierWorkflowStatusTypeEnum[27];
    arrayOfCarrierWorkflowStatusTypeEnum[0] = ACTIVATED;
    arrayOfCarrierWorkflowStatusTypeEnum[1] = BENEFIT_SETUP_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[2] = DATA_COLLECTION_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[3] = DEACTIVATED;
    arrayOfCarrierWorkflowStatusTypeEnum[4] = FINAL_DATA_COLLECTION;
    arrayOfCarrierWorkflowStatusTypeEnum[5] = FINAL_QUOTE_PENDING;
    arrayOfCarrierWorkflowStatusTypeEnum[6] = FINAL_QUOTE_REJECTED;
    arrayOfCarrierWorkflowStatusTypeEnum[7] = GROUP_SETUP_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[8] = LIVE;
    arrayOfCarrierWorkflowStatusTypeEnum[9] = NEW;
    arrayOfCarrierWorkflowStatusTypeEnum[10] = PENDING_ACTIVATION;
    arrayOfCarrierWorkflowStatusTypeEnum[11] = PRELIMINARY_QUOTE_PENDING;
    arrayOfCarrierWorkflowStatusTypeEnum[12] = PRELIMINARY_QUOTE_REJECTED;
    arrayOfCarrierWorkflowStatusTypeEnum[13] = PRELIMINARY_QUOTE_REVIEW_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[14] = PREPARE_REQUEST_FOR_FINAL_QUOTE;
    arrayOfCarrierWorkflowStatusTypeEnum[15] = READY_FOR_RENEWAL;
    arrayOfCarrierWorkflowStatusTypeEnum[16] = READY_FOR_RENEWAL_FINAL_QUOTE;
    arrayOfCarrierWorkflowStatusTypeEnum[17] = READY_FOR_RENEWAL_NO_QUOTE;
    arrayOfCarrierWorkflowStatusTypeEnum[18] = REJECTED_FOR_ACTIVATION;
    arrayOfCarrierWorkflowStatusTypeEnum[19] = RENEWAL_BENEFIT_SETUP_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[20] = RENEWAL_COMPLETE;
    arrayOfCarrierWorkflowStatusTypeEnum[21] = RENEWAL_DEACTIVATED;
    arrayOfCarrierWorkflowStatusTypeEnum[22] = REQUEST_FOR_FINAL_QUOTE_REJECTED;
    arrayOfCarrierWorkflowStatusTypeEnum[23] = REQUEST_FOR_PRELIMINARY_QUOTE_REJECTED;
    arrayOfCarrierWorkflowStatusTypeEnum[24] = SOLD;
    arrayOfCarrierWorkflowStatusTypeEnum[25] = UNDERWRITING_IN_PROGRESS;
    arrayOfCarrierWorkflowStatusTypeEnum[26] = UNDERWRITING_REVIEW_IN_PROGRESS;
    $VALUES = arrayOfCarrierWorkflowStatusTypeEnum;
  }

  public String getAtomicConstantValue()
  {
    return name();
  }

  public CarrierWorkflowStatusTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return valueOf(paramString);
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.eSales.CarrierWorkflowStatusTypeEnum
 * JD-Core Version:    0.6.0
 */