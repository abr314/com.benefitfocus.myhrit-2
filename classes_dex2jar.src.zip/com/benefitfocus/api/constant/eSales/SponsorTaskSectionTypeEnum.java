package com.benefitfocus.api.constant.eSales;

import com.benefitfocus.api.constant.AtomicConstantEnum;

public enum SponsorTaskSectionTypeEnum
  implements AtomicConstantEnum
{
  static
  {
    CARRIER_DETAILS = new SponsorTaskSectionTypeEnum("CARRIER_DETAILS", 2);
    MARKET_SEGMENT = new SponsorTaskSectionTypeEnum("MARKET_SEGMENT", 3);
    CARRIER_SURVEY = new SponsorTaskSectionTypeEnum("CARRIER_SURVEY", 4);
    FULL_EE_CENSUS = new SponsorTaskSectionTypeEnum("FULL_EE_CENSUS", 5);
    QUOTE_CENSUS = new SponsorTaskSectionTypeEnum("QUOTE_CENSUS", 6);
    GROUP_HEALTH_STMT = new SponsorTaskSectionTypeEnum("GROUP_HEALTH_STMT", 7);
    INDIVIDUAL_HEALTH_STMT = new SponsorTaskSectionTypeEnum("INDIVIDUAL_HEALTH_STMT", 8);
    OVERRIDE_MEMBER_TASKS = new SponsorTaskSectionTypeEnum("OVERRIDE_MEMBER_TASKS", 9);
    AGENT_CHECKLIST = new SponsorTaskSectionTypeEnum("AGENT_CHECKLIST", 10);
    FINAL_QUOTE_DETAILS = new SponsorTaskSectionTypeEnum("FINAL_QUOTE_DETAILS", 11);
    ASSIGN_RISK_FACTOR = new SponsorTaskSectionTypeEnum("ASSIGN_RISK_FACTOR", 12);
    PREPARE_FINAL_PROPOSAL = new SponsorTaskSectionTypeEnum("PREPARE_FINAL_PROPOSAL", 13);
    BENEFIT_SETUP = new SponsorTaskSectionTypeEnum("BENEFIT_SETUP", 14);
    PLAN_MAPPING = new SponsorTaskSectionTypeEnum("PLAN_MAPPING", 15);
    DATE_RULE_SETUP = new SponsorTaskSectionTypeEnum("DATE_RULE_SETUP", 16);
    EMP_DEFINED_CONTRIBUTION = new SponsorTaskSectionTypeEnum("EMP_DEFINED_CONTRIBUTION", 17);
    EE_ELECTIONS = new SponsorTaskSectionTypeEnum("EE_ELECTIONS", 18);
    CARRIER_CHECKLIST = new SponsorTaskSectionTypeEnum("CARRIER_CHECKLIST", 19);
    CONFIGURE_CARRIER_IDENTS = new SponsorTaskSectionTypeEnum("CONFIGURE_CARRIER_IDENTS", 20);
    MASS_GENERATE_CARRIER_IDENTS = new SponsorTaskSectionTypeEnum("MASS_GENERATE_CARRIER_IDENTS", 21);
    DECISION_MAKER_SELECTION = new SponsorTaskSectionTypeEnum("DECISION_MAKER_SELECTION", 22);
    GROUP_CONTACT = new SponsorTaskSectionTypeEnum("GROUP_CONTACT", 23);
    ACTIVATE = new SponsorTaskSectionTypeEnum("ACTIVATE", 24);
    APPROVE_GROUP_SETUP = new SponsorTaskSectionTypeEnum("APPROVE_GROUP_SETUP", 25);
    COLLECT_BINDER_PAYMENT = new SponsorTaskSectionTypeEnum("COLLECT_BINDER_PAYMENT", 26);
    PROCESS_BINDER_PAYMENT = new SponsorTaskSectionTypeEnum("PROCESS_BINDER_PAYMENT", 27);
    MIN_PARTICIPATION_PERCENTAGE = new SponsorTaskSectionTypeEnum("MIN_PARTICIPATION_PERCENTAGE", 28);
    CONFIRM_GROUP_NUMBER = new SponsorTaskSectionTypeEnum("CONFIRM_GROUP_NUMBER", 29);
    ASSIGN_CARRIER_PACKAGE = new SponsorTaskSectionTypeEnum("ASSIGN_CARRIER_PACKAGE", 30);
    DEFINE_OE_DATES = new SponsorTaskSectionTypeEnum("DEFINE_OE_DATES", 31);
    REVIEW_PROPOSAL = new SponsorTaskSectionTypeEnum("REVIEW_PROPOSAL", 32);
    REVIEW_PRELIMINARY_QUOTE = new SponsorTaskSectionTypeEnum("REVIEW_PRELIMINARY_QUOTE", 33);
    REVIEW_AND_UPLOAD_DOCUMENT = new SponsorTaskSectionTypeEnum("REVIEW_AND_UPLOAD_DOCUMENT", 34);
    VERIFY_BENEFIT_LIST_RATE_INFO = new SponsorTaskSectionTypeEnum("VERIFY_BENEFIT_LIST_RATE_INFO", 35);
    SponsorTaskSectionTypeEnum[] arrayOfSponsorTaskSectionTypeEnum = new SponsorTaskSectionTypeEnum[36];
    arrayOfSponsorTaskSectionTypeEnum[0] = BASICS;
    arrayOfSponsorTaskSectionTypeEnum[1] = GROUP_ADDRESS;
    arrayOfSponsorTaskSectionTypeEnum[2] = CARRIER_DETAILS;
    arrayOfSponsorTaskSectionTypeEnum[3] = MARKET_SEGMENT;
    arrayOfSponsorTaskSectionTypeEnum[4] = CARRIER_SURVEY;
    arrayOfSponsorTaskSectionTypeEnum[5] = FULL_EE_CENSUS;
    arrayOfSponsorTaskSectionTypeEnum[6] = QUOTE_CENSUS;
    arrayOfSponsorTaskSectionTypeEnum[7] = GROUP_HEALTH_STMT;
    arrayOfSponsorTaskSectionTypeEnum[8] = INDIVIDUAL_HEALTH_STMT;
    arrayOfSponsorTaskSectionTypeEnum[9] = OVERRIDE_MEMBER_TASKS;
    arrayOfSponsorTaskSectionTypeEnum[10] = AGENT_CHECKLIST;
    arrayOfSponsorTaskSectionTypeEnum[11] = FINAL_QUOTE_DETAILS;
    arrayOfSponsorTaskSectionTypeEnum[12] = ASSIGN_RISK_FACTOR;
    arrayOfSponsorTaskSectionTypeEnum[13] = PREPARE_FINAL_PROPOSAL;
    arrayOfSponsorTaskSectionTypeEnum[14] = BENEFIT_SETUP;
    arrayOfSponsorTaskSectionTypeEnum[15] = PLAN_MAPPING;
    arrayOfSponsorTaskSectionTypeEnum[16] = DATE_RULE_SETUP;
    arrayOfSponsorTaskSectionTypeEnum[17] = EMP_DEFINED_CONTRIBUTION;
    arrayOfSponsorTaskSectionTypeEnum[18] = EE_ELECTIONS;
    arrayOfSponsorTaskSectionTypeEnum[19] = CARRIER_CHECKLIST;
    arrayOfSponsorTaskSectionTypeEnum[20] = CONFIGURE_CARRIER_IDENTS;
    arrayOfSponsorTaskSectionTypeEnum[21] = MASS_GENERATE_CARRIER_IDENTS;
    arrayOfSponsorTaskSectionTypeEnum[22] = DECISION_MAKER_SELECTION;
    arrayOfSponsorTaskSectionTypeEnum[23] = GROUP_CONTACT;
    arrayOfSponsorTaskSectionTypeEnum[24] = ACTIVATE;
    arrayOfSponsorTaskSectionTypeEnum[25] = APPROVE_GROUP_SETUP;
    arrayOfSponsorTaskSectionTypeEnum[26] = COLLECT_BINDER_PAYMENT;
    arrayOfSponsorTaskSectionTypeEnum[27] = PROCESS_BINDER_PAYMENT;
    arrayOfSponsorTaskSectionTypeEnum[28] = MIN_PARTICIPATION_PERCENTAGE;
    arrayOfSponsorTaskSectionTypeEnum[29] = CONFIRM_GROUP_NUMBER;
    arrayOfSponsorTaskSectionTypeEnum[30] = ASSIGN_CARRIER_PACKAGE;
    arrayOfSponsorTaskSectionTypeEnum[31] = DEFINE_OE_DATES;
    arrayOfSponsorTaskSectionTypeEnum[32] = REVIEW_PROPOSAL;
    arrayOfSponsorTaskSectionTypeEnum[33] = REVIEW_PRELIMINARY_QUOTE;
    arrayOfSponsorTaskSectionTypeEnum[34] = REVIEW_AND_UPLOAD_DOCUMENT;
    arrayOfSponsorTaskSectionTypeEnum[35] = VERIFY_BENEFIT_LIST_RATE_INFO;
    $VALUES = arrayOfSponsorTaskSectionTypeEnum;
  }

  public static SponsorTaskSectionTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return valueOf(paramString);
  }

  public String getAtomicConstantValue()
  {
    return name();
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.eSales.SponsorTaskSectionTypeEnum
 * JD-Core Version:    0.6.0
 */