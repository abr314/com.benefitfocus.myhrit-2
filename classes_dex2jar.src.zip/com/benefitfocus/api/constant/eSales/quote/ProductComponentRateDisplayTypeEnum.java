package com.benefitfocus.api.constant.eSales.quote;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum ProductComponentRateDisplayTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, ProductComponentRateDisplayTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    DISPLAY_SUM_TOTAL = new ProductComponentRateDisplayTypeEnum("DISPLAY_SUM_TOTAL", 1, "SUM_TOTAL");
    DISPLAY_PER_COMPONENT = new ProductComponentRateDisplayTypeEnum("DISPLAY_PER_COMPONENT", 2, "PER_COMPONENT");
    DISPLAY_PER_COMPONENT_AND_TOTAL = new ProductComponentRateDisplayTypeEnum("DISPLAY_PER_COMPONENT_AND_TOTAL", 3, "PER_COMPONENT_AND_TOTAL");
    ProductComponentRateDisplayTypeEnum[] arrayOfProductComponentRateDisplayTypeEnum1 = new ProductComponentRateDisplayTypeEnum[4];
    arrayOfProductComponentRateDisplayTypeEnum1[0] = DO_NOT_DISPLAY;
    arrayOfProductComponentRateDisplayTypeEnum1[1] = DISPLAY_SUM_TOTAL;
    arrayOfProductComponentRateDisplayTypeEnum1[2] = DISPLAY_PER_COMPONENT;
    arrayOfProductComponentRateDisplayTypeEnum1[3] = DISPLAY_PER_COMPONENT_AND_TOTAL;
    $VALUES = arrayOfProductComponentRateDisplayTypeEnum1;
    valueMap = new HashMap();
    for (ProductComponentRateDisplayTypeEnum localProductComponentRateDisplayTypeEnum : values())
      valueMap.put(localProductComponentRateDisplayTypeEnum.getAtomicConstantValue(), localProductComponentRateDisplayTypeEnum);
  }

  private ProductComponentRateDisplayTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static ProductComponentRateDisplayTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (ProductComponentRateDisplayTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.eSales.quote.ProductComponentRateDisplayTypeEnum
 * JD-Core Version:    0.6.0
 */