package com.benefitfocus.api.constant.eSales;

import com.benefitfocus.api.constant.AtomicConstantEnum;
import java.util.HashMap;
import java.util.Map;

public enum WorkflowTypeEnum
  implements AtomicConstantEnum
{
  private static final Map<String, WorkflowTypeEnum> valueMap;
  private String atomicConstantValue;

  static
  {
    ALL = new WorkflowTypeEnum("ALL", 2, "ALL");
    NO_ACTIVE_WORKFLOW = new WorkflowTypeEnum("NO_ACTIVE_WORKFLOW", 3, null);
    WorkflowTypeEnum[] arrayOfWorkflowTypeEnum1 = new WorkflowTypeEnum[4];
    arrayOfWorkflowTypeEnum1[0] = NEW_PROSPECT;
    arrayOfWorkflowTypeEnum1[1] = RENEWAL;
    arrayOfWorkflowTypeEnum1[2] = ALL;
    arrayOfWorkflowTypeEnum1[3] = NO_ACTIVE_WORKFLOW;
    $VALUES = arrayOfWorkflowTypeEnum1;
    valueMap = new HashMap();
    for (WorkflowTypeEnum localWorkflowTypeEnum : values())
      valueMap.put(localWorkflowTypeEnum.getAtomicConstantValue(), localWorkflowTypeEnum);
  }

  private WorkflowTypeEnum(String paramString)
  {
    this.atomicConstantValue = paramString;
  }

  public static WorkflowTypeEnum getEnumForAtomicConstantValue(String paramString)
  {
    return (WorkflowTypeEnum)valueMap.get(paramString);
  }

  public String getAtomicConstantValue()
  {
    return this.atomicConstantValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.eSales.WorkflowTypeEnum
 * JD-Core Version:    0.6.0
 */