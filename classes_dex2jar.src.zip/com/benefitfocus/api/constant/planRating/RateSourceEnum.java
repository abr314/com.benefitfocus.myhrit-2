package com.benefitfocus.api.constant.planRating;

public enum RateSourceEnum
{
  static
  {
    EDIRECT = new RateSourceEnum("EDIRECT", 1);
    EXTERNAL_RATING_SERVICE = new RateSourceEnum("EXTERNAL_RATING_SERVICE", 2);
    RateSourceEnum[] arrayOfRateSourceEnum = new RateSourceEnum[3];
    arrayOfRateSourceEnum[0] = ENROLLMENT;
    arrayOfRateSourceEnum[1] = EDIRECT;
    arrayOfRateSourceEnum[2] = EXTERNAL_RATING_SERVICE;
    $VALUES = arrayOfRateSourceEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.constant.planRating.RateSourceEnum
 * JD-Core Version:    0.6.0
 */