package com.benefitfocus.api.service.common.service;

public enum MethodStatus
{
  static
  {
    ERROR = new MethodStatus("ERROR", 2);
    MethodStatus[] arrayOfMethodStatus = new MethodStatus[3];
    arrayOfMethodStatus[0] = SUCCESS;
    arrayOfMethodStatus[1] = WARN;
    arrayOfMethodStatus[2] = ERROR;
    $VALUES = arrayOfMethodStatus;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.service.MethodStatus
 * JD-Core Version:    0.6.0
 */