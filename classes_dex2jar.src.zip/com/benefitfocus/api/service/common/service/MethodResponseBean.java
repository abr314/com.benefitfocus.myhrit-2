package com.benefitfocus.api.service.common.service;

import com.benefitfocus.api.service.common.message.MessageBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class MethodResponseBean
  implements Serializable
{
  private List<MessageBean> messageList = new ArrayList();
  private MethodStatus status = MethodStatus.SUCCESS;

  public List<MessageBean> getMessageList()
  {
    return this.messageList;
  }

  public MethodStatus getStatus()
  {
    return this.status;
  }

  public void setMessageList(List<MessageBean> paramList)
  {
    this.messageList = paramList;
  }

  public void setStatus(MethodStatus paramMethodStatus)
  {
    this.status = paramMethodStatus;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.service.MethodResponseBean
 * JD-Core Version:    0.6.0
 */