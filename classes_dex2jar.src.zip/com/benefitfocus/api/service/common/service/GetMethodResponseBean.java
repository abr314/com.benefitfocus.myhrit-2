package com.benefitfocus.api.service.common.service;

public class GetMethodResponseBean extends MethodResponseBean
{
  Boolean isEditable;

  public Boolean getEditable()
  {
    return this.isEditable;
  }

  public void setEditable(Boolean paramBoolean)
  {
    this.isEditable = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.service.GetMethodResponseBean
 * JD-Core Version:    0.6.0
 */