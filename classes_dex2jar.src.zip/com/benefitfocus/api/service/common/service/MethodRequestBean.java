package com.benefitfocus.api.service.common.service;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

@XmlRootElement
public class MethodRequestBean
  implements Serializable
{
  private String callerId;
  private String role;
  private Long userSecurityOid;

  @XmlTransient
  @JsonIgnore
  public String getCallerId()
  {
    return this.callerId;
  }

  @XmlTransient
  @JsonIgnore
  public String getRole()
  {
    return this.role;
  }

  @XmlTransient
  @JsonIgnore
  public Long getUserSecurityOid()
  {
    return this.userSecurityOid;
  }

  public void setCallerId(String paramString)
  {
    this.callerId = paramString;
  }

  public void setRole(String paramString)
  {
    this.role = paramString;
  }

  public void setUserSecurityOid(Long paramLong)
  {
    this.userSecurityOid = paramLong;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.service.MethodRequestBean
 * JD-Core Version:    0.6.0
 */