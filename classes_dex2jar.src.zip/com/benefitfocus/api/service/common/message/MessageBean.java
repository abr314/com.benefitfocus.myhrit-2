package com.benefitfocus.api.service.common.message;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlTransient;
import org.codehaus.jackson.annotate.JsonIgnore;

public class MessageBean
  implements Serializable
{
  private List<MessageAdditionalInfoBean> additionalInfoList = new ArrayList();
  private String developerMessage;
  private String key;
  private MessageLevel level;
  private MessageType messageType;
  private List<MessageParameterBean> parameterList = new ArrayList();
  private String path;
  private String stackTrace;

  public List<MessageAdditionalInfoBean> getAdditionalInfoList()
  {
    return this.additionalInfoList;
  }

  public String getDeveloperMessage()
  {
    return this.developerMessage;
  }

  public String getKey()
  {
    return this.key;
  }

  public MessageLevel getLevel()
  {
    return this.level;
  }

  public MessageType getMessageType()
  {
    return this.messageType;
  }

  public List<MessageParameterBean> getParameterList()
  {
    return this.parameterList;
  }

  public String getPath()
  {
    return this.path;
  }

  @XmlTransient
  @JsonIgnore
  public String getStackTrace()
  {
    return this.stackTrace;
  }

  public void setAdditionalInfoList(List<MessageAdditionalInfoBean> paramList)
  {
    this.additionalInfoList = paramList;
  }

  public void setDeveloperMessage(String paramString)
  {
    this.developerMessage = paramString;
  }

  public void setKey(String paramString)
  {
    this.key = paramString;
  }

  public void setLevel(MessageLevel paramMessageLevel)
  {
    this.level = paramMessageLevel;
  }

  public void setMessageType(MessageType paramMessageType)
  {
    this.messageType = paramMessageType;
  }

  public void setParameterList(List<MessageParameterBean> paramList)
  {
    this.parameterList = paramList;
  }

  public void setPath(String paramString)
  {
    this.path = paramString;
  }

  public void setStackTrace(String paramString)
  {
    this.stackTrace = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.MessageBean
 * JD-Core Version:    0.6.0
 */