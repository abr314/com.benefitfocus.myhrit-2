package com.benefitfocus.api.service.common.message;

public enum MessageType
{
  static
  {
    AUTHENTICATION_ERROR = new MessageType("AUTHENTICATION_ERROR", 1);
    PERMISSION_ERROR = new MessageType("PERMISSION_ERROR", 2);
    NOT_FOUND_ERROR = new MessageType("NOT_FOUND_ERROR", 3);
    VALIDATION_ERROR = new MessageType("VALIDATION_ERROR", 4);
    CONFLICT_ERROR = new MessageType("CONFLICT_ERROR", 5);
    WARNING = new MessageType("WARNING", 6);
    MessageType[] arrayOfMessageType = new MessageType[7];
    arrayOfMessageType[0] = SERVER_ERROR;
    arrayOfMessageType[1] = AUTHENTICATION_ERROR;
    arrayOfMessageType[2] = PERMISSION_ERROR;
    arrayOfMessageType[3] = NOT_FOUND_ERROR;
    arrayOfMessageType[4] = VALIDATION_ERROR;
    arrayOfMessageType[5] = CONFLICT_ERROR;
    arrayOfMessageType[6] = WARNING;
    $VALUES = arrayOfMessageType;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.MessageType
 * JD-Core Version:    0.6.0
 */