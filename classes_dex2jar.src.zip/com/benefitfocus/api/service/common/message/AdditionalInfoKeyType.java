package com.benefitfocus.api.service.common.message;

public enum AdditionalInfoKeyType
{
  static
  {
    DISPLAYABLE_MESSAGE = new AdditionalInfoKeyType("DISPLAYABLE_MESSAGE", 1);
    ENABLEMENT_OVERLAP = new AdditionalInfoKeyType("ENABLEMENT_OVERLAP", 2);
    AdditionalInfoKeyType[] arrayOfAdditionalInfoKeyType = new AdditionalInfoKeyType[3];
    arrayOfAdditionalInfoKeyType[0] = TRACKING_ID;
    arrayOfAdditionalInfoKeyType[1] = DISPLAYABLE_MESSAGE;
    arrayOfAdditionalInfoKeyType[2] = ENABLEMENT_OVERLAP;
    $VALUES = arrayOfAdditionalInfoKeyType;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.AdditionalInfoKeyType
 * JD-Core Version:    0.6.0
 */