package com.benefitfocus.api.service.common.message;

public enum MessageLevel
{
  static
  {
    ERROR = new MessageLevel("ERROR", 3);
    FATAL = new MessageLevel("FATAL", 4);
    MessageLevel[] arrayOfMessageLevel = new MessageLevel[5];
    arrayOfMessageLevel[0] = DEBUG;
    arrayOfMessageLevel[1] = INFO;
    arrayOfMessageLevel[2] = WARN;
    arrayOfMessageLevel[3] = ERROR;
    arrayOfMessageLevel[4] = FATAL;
    $VALUES = arrayOfMessageLevel;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.MessageLevel
 * JD-Core Version:    0.6.0
 */