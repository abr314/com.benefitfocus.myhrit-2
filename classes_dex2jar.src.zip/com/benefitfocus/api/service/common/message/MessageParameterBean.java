package com.benefitfocus.api.service.common.message;

import java.io.Serializable;

public class MessageParameterBean
  implements Serializable
{
  private String parameter;
  private int sequenceNumber;

  public String getParameter()
  {
    return this.parameter;
  }

  public int getSequenceNumber()
  {
    return this.sequenceNumber;
  }

  public void setParameter(String paramString)
  {
    this.parameter = paramString;
  }

  public void setSequenceNumber(int paramInt)
  {
    this.sequenceNumber = paramInt;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.MessageParameterBean
 * JD-Core Version:    0.6.0
 */