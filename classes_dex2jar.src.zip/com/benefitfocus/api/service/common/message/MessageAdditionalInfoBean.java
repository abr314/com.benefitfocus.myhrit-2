package com.benefitfocus.api.service.common.message;

import java.io.Serializable;

public class MessageAdditionalInfoBean
  implements Serializable
{
  private String key;
  private String value;

  public String getKey()
  {
    return this.key;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setKey(String paramString)
  {
    this.key = paramString;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.message.MessageAdditionalInfoBean
 * JD-Core Version:    0.6.0
 */