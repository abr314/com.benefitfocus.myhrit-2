package com.benefitfocus.api.service.common;

public class PersonNameBean
{
  private String firstName;
  private String lastName;
  private String maidenName;
  private String middleName;
  private String suffix;

  public String getFirstName()
  {
    return this.firstName;
  }

  public String getLastName()
  {
    return this.lastName;
  }

  public String getMaidenName()
  {
    return this.maidenName;
  }

  public String getMiddleName()
  {
    return this.middleName;
  }

  public String getSuffix()
  {
    return this.suffix;
  }

  public void setFirstName(String paramString)
  {
    this.firstName = paramString;
  }

  public void setLastName(String paramString)
  {
    this.lastName = paramString;
  }

  public void setMaidenName(String paramString)
  {
    this.maidenName = paramString;
  }

  public void setMiddleName(String paramString)
  {
    this.middleName = paramString;
  }

  public void setSuffix(String paramString)
  {
    this.suffix = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.PersonNameBean
 * JD-Core Version:    0.6.0
 */