package com.benefitfocus.api.service.common.individual;

import com.benefitfocus.api.constant.product.RelationshipTypeEnum;
import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import java.util.ArrayList;
import java.util.List;

public class MemberDetailBean
{
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private String id;
  private MemberPersonalIdentificationBean memberPersonalIdentification;
  private RelationshipTypeEnum relationship;
  private List<TobaccoStatusBean> tobaccoStatuses = new ArrayList();

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public String getId()
  {
    return this.id;
  }

  public MemberPersonalIdentificationBean getMemberPersonalIdentification()
  {
    return this.memberPersonalIdentification;
  }

  public RelationshipTypeEnum getRelationship()
  {
    return this.relationship;
  }

  public List<TobaccoStatusBean> getTobaccoStatuses()
  {
    return this.tobaccoStatuses;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setMemberPersonalIdentification(MemberPersonalIdentificationBean paramMemberPersonalIdentificationBean)
  {
    this.memberPersonalIdentification = paramMemberPersonalIdentificationBean;
  }

  public void setRelationship(RelationshipTypeEnum paramRelationshipTypeEnum)
  {
    this.relationship = paramRelationshipTypeEnum;
  }

  public void setTobaccoStatuses(List<TobaccoStatusBean> paramList)
  {
    this.tobaccoStatuses = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.individual.MemberDetailBean
 * JD-Core Version:    0.6.0
 */