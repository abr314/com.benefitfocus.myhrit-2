package com.benefitfocus.api.service.common.individual;

import com.benefitfocus.api.constant.member.EthnicityTypeEnum;
import com.benefitfocus.api.constant.member.GenderTypeEnum;
import com.benefitfocus.api.constant.member.MaritalStatusTypeEnum;
import com.benefitfocus.api.service.common.AddressBean;
import com.benefitfocus.api.service.common.PersonNameBean;
import java.util.Date;

public class MemberPersonalIdentificationBean
{
  private String alternatePhoneNumber;
  private Date birthDate;
  private Date deceasedDate;
  private String emailAddress;
  private EthnicityTypeEnum ethnicity;
  private GenderTypeEnum gender;
  private AddressBean homeAddress;
  private String homePhoneNumber;
  private MaritalStatusTypeEnum maritalStatus;
  private String mobilePhoneNumber;
  private String personId;
  private PersonNameBean personName;
  private Date personalIdentificationChangeEffectiveDate;
  private String ssn;
  private AddressBean workAddress;

  public String getAlternatePhoneNumber()
  {
    return this.alternatePhoneNumber;
  }

  public Date getBirthDate()
  {
    return this.birthDate;
  }

  public Date getDeceasedDate()
  {
    return this.deceasedDate;
  }

  public String getEmailAddress()
  {
    return this.emailAddress;
  }

  public EthnicityTypeEnum getEthnicity()
  {
    return this.ethnicity;
  }

  public GenderTypeEnum getGender()
  {
    return this.gender;
  }

  public AddressBean getHomeAddress()
  {
    return this.homeAddress;
  }

  public String getHomePhoneNumber()
  {
    return this.homePhoneNumber;
  }

  public MaritalStatusTypeEnum getMaritalStatus()
  {
    return this.maritalStatus;
  }

  public String getMobilePhoneNumber()
  {
    return this.mobilePhoneNumber;
  }

  public String getPersonId()
  {
    return this.personId;
  }

  public PersonNameBean getPersonName()
  {
    return this.personName;
  }

  public Date getPersonalIdentificationChangeEffectiveDate()
  {
    return this.personalIdentificationChangeEffectiveDate;
  }

  public String getSsn()
  {
    return this.ssn;
  }

  public AddressBean getWorkAddress()
  {
    return this.workAddress;
  }

  public void setAlternatePhoneNumber(String paramString)
  {
    this.alternatePhoneNumber = paramString;
  }

  public void setBirthDate(Date paramDate)
  {
    this.birthDate = paramDate;
  }

  public void setDeceasedDate(Date paramDate)
  {
    this.deceasedDate = paramDate;
  }

  public void setEmailAddress(String paramString)
  {
    this.emailAddress = paramString;
  }

  public void setEthnicity(EthnicityTypeEnum paramEthnicityTypeEnum)
  {
    this.ethnicity = paramEthnicityTypeEnum;
  }

  public void setGender(GenderTypeEnum paramGenderTypeEnum)
  {
    this.gender = paramGenderTypeEnum;
  }

  public void setHomeAddress(AddressBean paramAddressBean)
  {
    this.homeAddress = paramAddressBean;
  }

  public void setHomePhoneNumber(String paramString)
  {
    this.homePhoneNumber = paramString;
  }

  public void setMaritalStatus(MaritalStatusTypeEnum paramMaritalStatusTypeEnum)
  {
    this.maritalStatus = paramMaritalStatusTypeEnum;
  }

  public void setMobilePhoneNumber(String paramString)
  {
    this.mobilePhoneNumber = paramString;
  }

  public void setPersonId(String paramString)
  {
    this.personId = paramString;
  }

  public void setPersonName(PersonNameBean paramPersonNameBean)
  {
    this.personName = paramPersonNameBean;
  }

  public void setPersonalIdentificationChangeEffectiveDate(Date paramDate)
  {
    this.personalIdentificationChangeEffectiveDate = paramDate;
  }

  public void setSsn(String paramString)
  {
    this.ssn = paramString;
  }

  public void setWorkAddress(AddressBean paramAddressBean)
  {
    this.workAddress = paramAddressBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.individual.MemberPersonalIdentificationBean
 * JD-Core Version:    0.6.0
 */