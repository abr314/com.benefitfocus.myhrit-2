package com.benefitfocus.api.service.common.individual;

import com.benefitfocus.api.service.common.DateRangeBean;

public class TobaccoStatusBean
{
  private DateRangeBean dateRange;
  private Boolean tobaccoIndicator;

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public Boolean getTobaccoIndicator()
  {
    return this.tobaccoIndicator;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setTobaccoIndicator(Boolean paramBoolean)
  {
    this.tobaccoIndicator = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.individual.TobaccoStatusBean
 * JD-Core Version:    0.6.0
 */