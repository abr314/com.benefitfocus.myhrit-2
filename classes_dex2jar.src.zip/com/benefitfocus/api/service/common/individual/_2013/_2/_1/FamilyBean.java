package com.benefitfocus.api.service.common.individual._2013._2._1;

import com.benefitfocus.api.service.common.benefit._2013._2._1.BenefitDetailBean;
import com.benefitfocus.api.service.common.individual.MemberDetailBean;
import java.util.ArrayList;
import java.util.List;

public class FamilyBean
{
  List<BenefitDetailBean> benefitDetails = new ArrayList();
  List<MemberDetailBean> memberDetails = new ArrayList();

  public List<BenefitDetailBean> getBenefitDetails()
  {
    return this.benefitDetails;
  }

  public List<MemberDetailBean> getMemberDetails()
  {
    return this.memberDetails;
  }

  public void setBenefitDetails(List<BenefitDetailBean> paramList)
  {
    this.benefitDetails = paramList;
  }

  public void setMemberDetails(List<MemberDetailBean> paramList)
  {
    this.memberDetails = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.individual._2013._2._1.FamilyBean
 * JD-Core Version:    0.6.0
 */