package com.benefitfocus.api.service.common;

public class SponsorAdminBean
{
  private String email;
  private boolean isAdmin;
  private PersonNameBean name;
  private String phone;

  public String getEmail()
  {
    return this.email;
  }

  public PersonNameBean getName()
  {
    return this.name;
  }

  public String getPhone()
  {
    return this.phone;
  }

  public boolean isAdmin()
  {
    return this.isAdmin;
  }

  public void setAdmin(boolean paramBoolean)
  {
    this.isAdmin = paramBoolean;
  }

  public void setEmail(String paramString)
  {
    this.email = paramString;
  }

  public void setName(PersonNameBean paramPersonNameBean)
  {
    this.name = paramPersonNameBean;
  }

  public void setPhone(String paramString)
  {
    this.phone = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.SponsorAdminBean
 * JD-Core Version:    0.6.0
 */