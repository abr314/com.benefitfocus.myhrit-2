package com.benefitfocus.api.service.common;

public class PrivateLabelElementBean
{
  private String key;
  private String type;
  private String value;

  public String getKey()
  {
    return this.key;
  }

  public String getType()
  {
    return this.type;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setKey(String paramString)
  {
    this.key = paramString;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.PrivateLabelElementBean
 * JD-Core Version:    0.6.0
 */