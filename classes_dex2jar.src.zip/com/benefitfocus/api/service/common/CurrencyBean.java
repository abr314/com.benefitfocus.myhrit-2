package com.benefitfocus.api.service.common;

import java.math.BigDecimal;

public class CurrencyBean
{
  private BigDecimal amount;
  private String type;

  public BigDecimal getAmount()
  {
    return this.amount;
  }

  public String getType()
  {
    return this.type;
  }

  public void setAmount(BigDecimal paramBigDecimal)
  {
    this.amount = paramBigDecimal;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.CurrencyBean
 * JD-Core Version:    0.6.0
 */