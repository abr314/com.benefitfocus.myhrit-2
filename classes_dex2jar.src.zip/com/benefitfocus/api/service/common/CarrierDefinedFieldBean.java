package com.benefitfocus.api.service.common;

import com.benefitfocus.api.constant.carrierDefinedField.DataValueType;

public class CarrierDefinedFieldBean
{
  private String carrierId;
  private DataValueType dataValueType;
  private DateRangeBean dateRange;
  private String displayName;
  private String id;
  private String type;
  private String value;

  public String getCarrierId()
  {
    return this.carrierId;
  }

  public DataValueType getDataValueType()
  {
    return this.dataValueType;
  }

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public String getDisplayName()
  {
    return this.displayName;
  }

  public String getId()
  {
    return this.id;
  }

  public String getType()
  {
    return this.type;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setCarrierId(String paramString)
  {
    this.carrierId = paramString;
  }

  public void setDataValueType(DataValueType paramDataValueType)
  {
    this.dataValueType = paramDataValueType;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setDisplayName(String paramString)
  {
    this.displayName = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.CarrierDefinedFieldBean
 * JD-Core Version:    0.6.0
 */