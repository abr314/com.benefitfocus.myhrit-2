package com.benefitfocus.api.service.common.rate;

import com.benefitfocus.api.constant.payment.PaymentFrequencyBean;
import com.benefitfocus.api.service.common.CurrencyBean;
import com.benefitfocus.api.service.common.DateRangeBean;
import com.benefitfocus.api.service.common.benefit.CoverageLevelBean;
import java.util.Date;

public class RateBean
{
  private Date anniversaryDate;
  private CurrencyBean basePremium;
  private Double basePremiumFactor;
  private String changeReason;
  private CoverageLevelBean coverageLevel;
  private DateRangeBean dateRange;
  private CurrencyBean memberCost;
  private PaymentFrequencyBean paymentFrequency;
  private RateComponentBean rateComponent;
  private Date rateGuaranteeExpirationDate;
  private String rateType;

  public Date getAnniversaryDate()
  {
    return this.anniversaryDate;
  }

  public CurrencyBean getBasePremium()
  {
    return this.basePremium;
  }

  public Double getBasePremiumFactor()
  {
    return this.basePremiumFactor;
  }

  public String getChangeReason()
  {
    return this.changeReason;
  }

  public CoverageLevelBean getCoverageLevel()
  {
    return this.coverageLevel;
  }

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public CurrencyBean getMemberCost()
  {
    return this.memberCost;
  }

  public PaymentFrequencyBean getPaymentFrequency()
  {
    return this.paymentFrequency;
  }

  public RateComponentBean getRateComponent()
  {
    return this.rateComponent;
  }

  public Date getRateGuaranteeExpirationDate()
  {
    return this.rateGuaranteeExpirationDate;
  }

  public String getRateType()
  {
    return this.rateType;
  }

  public void setAnniversaryDate(Date paramDate)
  {
    this.anniversaryDate = paramDate;
  }

  public void setBasePremium(CurrencyBean paramCurrencyBean)
  {
    this.basePremium = paramCurrencyBean;
  }

  public void setBasePremiumFactor(Double paramDouble)
  {
    this.basePremiumFactor = paramDouble;
  }

  public void setChangeReason(String paramString)
  {
    this.changeReason = paramString;
  }

  public void setCoverageLevel(CoverageLevelBean paramCoverageLevelBean)
  {
    this.coverageLevel = paramCoverageLevelBean;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setMemberCost(CurrencyBean paramCurrencyBean)
  {
    this.memberCost = paramCurrencyBean;
  }

  public void setPaymentFrequency(PaymentFrequencyBean paramPaymentFrequencyBean)
  {
    this.paymentFrequency = paramPaymentFrequencyBean;
  }

  public void setRateComponent(RateComponentBean paramRateComponentBean)
  {
    this.rateComponent = paramRateComponentBean;
  }

  public void setRateGuaranteeExpirationDate(Date paramDate)
  {
    this.rateGuaranteeExpirationDate = paramDate;
  }

  public void setRateType(String paramString)
  {
    this.rateType = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.rate.RateBean
 * JD-Core Version:    0.6.0
 */