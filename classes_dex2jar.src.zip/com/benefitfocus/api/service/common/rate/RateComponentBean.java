package com.benefitfocus.api.service.common.rate;

import java.math.BigDecimal;

public class RateComponentBean
{
  private String name;
  private BigDecimal rate;

  public String getName()
  {
    return this.name;
  }

  public BigDecimal getRate()
  {
    return this.rate;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setRate(BigDecimal paramBigDecimal)
  {
    this.rate = paramBigDecimal;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.rate.RateComponentBean
 * JD-Core Version:    0.6.0
 */