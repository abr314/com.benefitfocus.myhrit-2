package com.benefitfocus.api.service.common;

import java.util.Date;

public class DateRangeBean
{
  private Date effectiveDate;
  private Date expirationDate;
  private Date originalEffectiveDate;

  public boolean containsDate(Date paramDate)
  {
    int i;
    if (this.effectiveDate != null)
    {
      i = 1;
      if (this.expirationDate == null)
        break label59;
    }
    label59: for (int j = 1; ; j = 0)
    {
      if (((i & j) == 0) || (paramDate == null) || (this.effectiveDate.compareTo(paramDate) == 1) || (this.expirationDate.compareTo(paramDate) == -1))
        break label64;
      return true;
      i = 0;
      break;
    }
    label64: return false;
  }

  public Date getEffectiveDate()
  {
    return this.effectiveDate;
  }

  public Date getExpirationDate()
  {
    return this.expirationDate;
  }

  public Date getOriginalEffectiveDate()
  {
    return this.originalEffectiveDate;
  }

  public void setEffectiveDate(Date paramDate)
  {
    this.effectiveDate = paramDate;
  }

  public void setExpirationDate(Date paramDate)
  {
    this.expirationDate = paramDate;
  }

  public void setOriginalEffectiveDate(Date paramDate)
  {
    this.originalEffectiveDate = paramDate;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.DateRangeBean
 * JD-Core Version:    0.6.0
 */