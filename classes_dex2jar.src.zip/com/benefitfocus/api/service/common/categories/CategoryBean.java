package com.benefitfocus.api.service.common.categories;

public class CategoryBean
{
  private String categoryName;
  private String categoryTypeId;
  private String description;
  private String id;
  private boolean isDefault;

  public String getCategoryName()
  {
    return this.categoryName;
  }

  public String getCategoryTypeId()
  {
    return this.categoryTypeId;
  }

  public String getDescription()
  {
    return this.description;
  }

  public String getId()
  {
    return this.id;
  }

  public boolean isDefault()
  {
    return this.isDefault;
  }

  public void setCategoryName(String paramString)
  {
    this.categoryName = paramString;
  }

  public void setCategoryTypeId(String paramString)
  {
    this.categoryTypeId = paramString;
  }

  public void setDefault(boolean paramBoolean)
  {
    this.isDefault = paramBoolean;
  }

  public void setDescription(String paramString)
  {
    this.description = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.categories.CategoryBean
 * JD-Core Version:    0.6.0
 */