package com.benefitfocus.api.service.common.categories;

import java.util.ArrayList;
import java.util.List;

public class EnablementBean
{
  private List<CategoryTypeCategoriesBean> categoryTypeCategories = new ArrayList();

  public List<CategoryTypeCategoriesBean> getCategoryTypeCategories()
  {
    return this.categoryTypeCategories;
  }

  public void setCategoryTypeCategories(List<CategoryTypeCategoriesBean> paramList)
  {
    this.categoryTypeCategories = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.categories.EnablementBean
 * JD-Core Version:    0.6.0
 */