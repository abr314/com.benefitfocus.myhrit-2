package com.benefitfocus.api.service.common.categories;

import java.util.ArrayList;
import java.util.List;

public class CategoryTypeCategoriesBean
{
  private List<String> categoryIds = new ArrayList();
  private String categoryTypeId;

  public List<String> getCategoryIds()
  {
    return this.categoryIds;
  }

  public String getCategoryTypeId()
  {
    return this.categoryTypeId;
  }

  public void setCategoryIds(List<String> paramList)
  {
    this.categoryIds = paramList;
  }

  public void setCategoryTypeId(String paramString)
  {
    this.categoryTypeId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.categories.CategoryTypeCategoriesBean
 * JD-Core Version:    0.6.0
 */