package com.benefitfocus.api.service.common.categories;

import java.util.ArrayList;
import java.util.List;

public class CategoryTypeBean
{
  private List<CategoryBean> categoryBeans = new ArrayList();
  private String categoryTypeName;
  private String id;
  private boolean isSelectionRequired;

  public List<CategoryBean> getCategoryBeans()
  {
    return this.categoryBeans;
  }

  public String getCategoryTypeName()
  {
    return this.categoryTypeName;
  }

  public String getId()
  {
    return this.id;
  }

  public boolean isSelectionRequired()
  {
    return this.isSelectionRequired;
  }

  public void setCategoryBeans(List<CategoryBean> paramList)
  {
    this.categoryBeans = paramList;
  }

  public void setCategoryTypeName(String paramString)
  {
    this.categoryTypeName = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setSelectionRequired(boolean paramBoolean)
  {
    this.isSelectionRequired = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.categories.CategoryTypeBean
 * JD-Core Version:    0.6.0
 */