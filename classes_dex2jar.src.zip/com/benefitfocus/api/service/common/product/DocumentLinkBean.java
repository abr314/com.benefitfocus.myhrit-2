package com.benefitfocus.api.service.common.product;

import com.benefitfocus.api.constant.product.ProductLinkTypeEnum;
import java.io.Serializable;

public class DocumentLinkBean
  implements Serializable
{
  private String URL;
  private Boolean appendProductID;
  private Boolean groupProducts;
  private ProductLinkTypeEnum productLinkType;
  private String title;

  public ProductLinkTypeEnum getProductLinkType()
  {
    return this.productLinkType;
  }

  public String getTitle()
  {
    return this.title;
  }

  public String getURL()
  {
    return this.URL;
  }

  public Boolean isAppendProductID()
  {
    return this.appendProductID;
  }

  public Boolean isGroupProducts()
  {
    return this.groupProducts;
  }

  public void setAppendProductID(Boolean paramBoolean)
  {
    this.appendProductID = paramBoolean;
  }

  public void setGroupProducts(Boolean paramBoolean)
  {
    this.groupProducts = paramBoolean;
  }

  public void setProductLinkType(ProductLinkTypeEnum paramProductLinkTypeEnum)
  {
    this.productLinkType = paramProductLinkTypeEnum;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public void setURL(String paramString)
  {
    this.URL = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product.DocumentLinkBean
 * JD-Core Version:    0.6.0
 */