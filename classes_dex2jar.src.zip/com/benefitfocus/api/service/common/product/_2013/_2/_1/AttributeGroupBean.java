package com.benefitfocus.api.service.common.product._2013._2._1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AttributeGroupBean
  implements Serializable
{
  private List<AttributeBean> attributes = new ArrayList();
  private String customCode;
  private String id;
  private Boolean isInSearchOption;
  private String name;
  private Integer sortOrder;

  public List<AttributeBean> getAttributes()
  {
    return this.attributes;
  }

  public String getCustomCode()
  {
    return this.customCode;
  }

  public String getId()
  {
    return this.id;
  }

  public String getName()
  {
    return this.name;
  }

  public Integer getSortOrder()
  {
    return this.sortOrder;
  }

  public Boolean isInSearchOption()
  {
    return this.isInSearchOption;
  }

  public void setAttributes(List<AttributeBean> paramList)
  {
    this.attributes = paramList;
  }

  public void setCustomCode(String paramString)
  {
    this.customCode = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setInSearchOption(Boolean paramBoolean)
  {
    this.isInSearchOption = paramBoolean;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setSortOrder(Integer paramInteger)
  {
    this.sortOrder = paramInteger;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._2._1.AttributeGroupBean
 * JD-Core Version:    0.6.0
 */