package com.benefitfocus.api.service.common.product._2013._1._1;

import java.util.ArrayList;
import java.util.List;

public class AttributeGroupBean
{
  private List<AttributeBean> attributes = new ArrayList();
  private String name;

  public List<AttributeBean> getAttributes()
  {
    return this.attributes;
  }

  public String getName()
  {
    return this.name;
  }

  public void setAttributes(List<AttributeBean> paramList)
  {
    this.attributes = paramList;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._1._1.AttributeGroupBean
 * JD-Core Version:    0.6.0
 */