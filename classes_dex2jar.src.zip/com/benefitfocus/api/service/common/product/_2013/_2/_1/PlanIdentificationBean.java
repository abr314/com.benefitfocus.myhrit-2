package com.benefitfocus.api.service.common.product._2013._2._1;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.benefit.ProductPlanTypeEnum;
import com.benefitfocus.api.service.common.CarrierIdentificationBean;
import com.benefitfocus.api.service.common.DateRangeBean;
import com.benefitfocus.api.service.common.product.DocumentLinkBean;
import java.util.ArrayList;
import java.util.List;

public class PlanIdentificationBean
{
  private List<AttributeGroupBean> attributeGroups = new ArrayList();
  private BenefitTypeEnum benefitType;
  private CarrierIdentificationBean carrierIdentification;
  private DateRangeBean dateRange;
  private String planId;
  private String planName;
  private DocumentLinkBean productCarrierLink;
  private String productId;
  private ProductPlanTypeEnum productType;

  public List<AttributeGroupBean> getAttributeGroups()
  {
    return this.attributeGroups;
  }

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public CarrierIdentificationBean getCarrierIdentification()
  {
    return this.carrierIdentification;
  }

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public String getPlanId()
  {
    return this.planId;
  }

  public String getPlanName()
  {
    return this.planName;
  }

  public DocumentLinkBean getProductCarrierLink()
  {
    return this.productCarrierLink;
  }

  public String getProductId()
  {
    return this.productId;
  }

  public ProductPlanTypeEnum getProductType()
  {
    return this.productType;
  }

  public void setAttributeGroups(List<AttributeGroupBean> paramList)
  {
    this.attributeGroups = paramList;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setCarrierIdentification(CarrierIdentificationBean paramCarrierIdentificationBean)
  {
    this.carrierIdentification = paramCarrierIdentificationBean;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setPlanId(String paramString)
  {
    this.planId = paramString;
  }

  public void setPlanName(String paramString)
  {
    this.planName = paramString;
  }

  public void setProductCarrierLink(DocumentLinkBean paramDocumentLinkBean)
  {
    this.productCarrierLink = paramDocumentLinkBean;
  }

  public void setProductId(String paramString)
  {
    this.productId = paramString;
  }

  public void setProductType(ProductPlanTypeEnum paramProductPlanTypeEnum)
  {
    this.productType = paramProductPlanTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._2._1.PlanIdentificationBean
 * JD-Core Version:    0.6.0
 */