package com.benefitfocus.api.service.common.product._2013._1._1;

import com.benefitfocus.api.constant.product.ProductLinkTypeEnum;
import java.io.Serializable;

public class ProductCarrierLinkBean
  implements Serializable
{
  private String URL;
  private boolean appendProductID;
  private boolean groupProducts;
  private ProductLinkTypeEnum productLinkType;
  private String title;

  public ProductLinkTypeEnum getProductLinkType()
  {
    return this.productLinkType;
  }

  public String getTitle()
  {
    return this.title;
  }

  public String getURL()
  {
    return this.URL;
  }

  public boolean isAppendProductID()
  {
    return this.appendProductID;
  }

  public boolean isGroupProducts()
  {
    return this.groupProducts;
  }

  public void setAppendProductID(boolean paramBoolean)
  {
    this.appendProductID = paramBoolean;
  }

  public void setGroupProducts(boolean paramBoolean)
  {
    this.groupProducts = paramBoolean;
  }

  public void setProductLinkType(ProductLinkTypeEnum paramProductLinkTypeEnum)
  {
    this.productLinkType = paramProductLinkTypeEnum;
  }

  public void setTitle(String paramString)
  {
    this.title = paramString;
  }

  public void setURL(String paramString)
  {
    this.URL = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._1._1.ProductCarrierLinkBean
 * JD-Core Version:    0.6.0
 */