package com.benefitfocus.api.service.common.product._2013._1._1;

public class AttributeBean
{
  private Integer attributeSequence;
  private String name;
  private Boolean networkIndicator;
  private Boolean summaryAttributeIndicator;
  private String value;

  public Integer getAttributeSequence()
  {
    return this.attributeSequence;
  }

  public String getName()
  {
    return this.name;
  }

  public Boolean getNetworkIndicator()
  {
    return this.networkIndicator;
  }

  public Boolean getSummaryAttributeIndicator()
  {
    return this.summaryAttributeIndicator;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setAttributeSequence(Integer paramInteger)
  {
    this.attributeSequence = paramInteger;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setNetworkIndicator(Boolean paramBoolean)
  {
    this.networkIndicator = paramBoolean;
  }

  public void setSummaryAttributeIndicator(Boolean paramBoolean)
  {
    this.summaryAttributeIndicator = paramBoolean;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._1._1.AttributeBean
 * JD-Core Version:    0.6.0
 */