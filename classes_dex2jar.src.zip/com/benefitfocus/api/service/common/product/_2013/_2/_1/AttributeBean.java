package com.benefitfocus.api.service.common.product._2013._2._1;

import java.io.Serializable;

public class AttributeBean
  implements Serializable
{
  private String customCode;
  private String id;
  private Boolean isInSearchOption;
  private Boolean isShowOnPlanListing;
  private String name;
  private Integer sortOrder;
  private Boolean summaryAttributeIndicator;
  private String value;

  public String getCustomCode()
  {
    return this.customCode;
  }

  public String getId()
  {
    return this.id;
  }

  public String getName()
  {
    return this.name;
  }

  public Boolean getShowOnPlanListing()
  {
    return this.isShowOnPlanListing;
  }

  public Integer getSortOrder()
  {
    return this.sortOrder;
  }

  public Boolean getSummaryAttributeIndicator()
  {
    return this.summaryAttributeIndicator;
  }

  public String getValue()
  {
    return this.value;
  }

  public Boolean isInSearchOption()
  {
    return this.isInSearchOption;
  }

  public void setCustomCode(String paramString)
  {
    this.customCode = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setInSearchOption(Boolean paramBoolean)
  {
    this.isInSearchOption = paramBoolean;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setShowOnPlanListing(Boolean paramBoolean)
  {
    this.isShowOnPlanListing = paramBoolean;
  }

  public void setSortOrder(Integer paramInteger)
  {
    this.sortOrder = paramInteger;
  }

  public void setSummaryAttributeIndicator(Boolean paramBoolean)
  {
    this.summaryAttributeIndicator = paramBoolean;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product._2013._2._1.AttributeBean
 * JD-Core Version:    0.6.0
 */