package com.benefitfocus.api.service.common.product;

import java.io.Serializable;

public class RateBandBean
  implements Serializable
{
  private String id;
  private Integer max;
  private Integer min;
  private String text;
  private String type;

  public String getId()
  {
    return this.id;
  }

  public Integer getMax()
  {
    return this.max;
  }

  public Integer getMin()
  {
    return this.min;
  }

  public String getText()
  {
    return this.text;
  }

  public String getType()
  {
    return this.type;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setMax(Integer paramInteger)
  {
    this.max = paramInteger;
  }

  public void setMin(Integer paramInteger)
  {
    this.min = paramInteger;
  }

  public void setText(String paramString)
  {
    this.text = paramString;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product.RateBandBean
 * JD-Core Version:    0.6.0
 */