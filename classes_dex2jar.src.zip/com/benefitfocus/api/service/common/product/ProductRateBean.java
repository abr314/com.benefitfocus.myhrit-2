package com.benefitfocus.api.service.common.product;

import com.benefitfocus.api.service.common.CurrencyBean;
import com.benefitfocus.api.service.common.DateRangeBean;
import java.io.Serializable;

public class ProductRateBean
  implements Serializable
{
  private RateApplicabilityBean appliesTo;
  private CurrencyBean cost;
  private DateRangeBean dateRange;
  private String id;

  public RateApplicabilityBean getAppliesTo()
  {
    return this.appliesTo;
  }

  public CurrencyBean getCost()
  {
    return this.cost;
  }

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public String getId()
  {
    return this.id;
  }

  public void setAppliesTo(RateApplicabilityBean paramRateApplicabilityBean)
  {
    this.appliesTo = paramRateApplicabilityBean;
  }

  public void setCost(CurrencyBean paramCurrencyBean)
  {
    this.cost = paramCurrencyBean;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product.ProductRateBean
 * JD-Core Version:    0.6.0
 */