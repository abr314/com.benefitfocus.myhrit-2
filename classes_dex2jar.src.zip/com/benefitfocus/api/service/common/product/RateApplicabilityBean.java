package com.benefitfocus.api.service.common.product;

import java.io.Serializable;

public class RateApplicabilityBean
  implements Serializable
{
  private String bundleId;
  private String coverageLevelId;
  private String individualId;
  private String planId;
  private String rateBandId;

  public String getBundleId()
  {
    return this.bundleId;
  }

  public String getCoverageLevelId()
  {
    return this.coverageLevelId;
  }

  public String getIndividualId()
  {
    return this.individualId;
  }

  public String getPlanId()
  {
    return this.planId;
  }

  public String getRateBandId()
  {
    return this.rateBandId;
  }

  public void setBundleId(String paramString)
  {
    this.bundleId = paramString;
  }

  public void setCoverageLevelId(String paramString)
  {
    this.coverageLevelId = paramString;
  }

  public void setIndividualId(String paramString)
  {
    this.individualId = paramString;
  }

  public void setPlanId(String paramString)
  {
    this.planId = paramString;
  }

  public void setRateBandId(String paramString)
  {
    this.rateBandId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.product.RateApplicabilityBean
 * JD-Core Version:    0.6.0
 */