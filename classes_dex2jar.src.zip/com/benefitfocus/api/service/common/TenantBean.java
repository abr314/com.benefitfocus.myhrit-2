package com.benefitfocus.api.service.common;

import com.benefitfocus.api.constant.tenant.TenantTypeEnum;
import com.benefitfocus.api.service.platform.sponsor.SponsorIdentificationBean;

public class TenantBean
{
  private CarrierIdentificationBean carrierIdentification;
  private String marketSegmentId;
  private SponsorIdentificationBean sponsorIdentification;
  private TenantTypeEnum tenantType;

  public CarrierIdentificationBean getCarrierIdentification()
  {
    return this.carrierIdentification;
  }

  public String getMarketSegmentId()
  {
    return this.marketSegmentId;
  }

  public SponsorIdentificationBean getSponsorIdentification()
  {
    return this.sponsorIdentification;
  }

  public TenantTypeEnum getTenantType()
  {
    return this.tenantType;
  }

  public void setCarrierIdentification(CarrierIdentificationBean paramCarrierIdentificationBean)
  {
    this.carrierIdentification = paramCarrierIdentificationBean;
  }

  public void setMarketSegmentId(String paramString)
  {
    this.marketSegmentId = paramString;
  }

  public void setSponsorIdentification(SponsorIdentificationBean paramSponsorIdentificationBean)
  {
    this.sponsorIdentification = paramSponsorIdentificationBean;
  }

  public void setTenantType(TenantTypeEnum paramTenantTypeEnum)
  {
    this.tenantType = paramTenantTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.TenantBean
 * JD-Core Version:    0.6.0
 */