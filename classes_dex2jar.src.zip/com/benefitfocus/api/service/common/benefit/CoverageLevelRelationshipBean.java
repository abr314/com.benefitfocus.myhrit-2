package com.benefitfocus.api.service.common.benefit;

import com.benefitfocus.api.constant.product.RelationshipTypeEnum;

public class CoverageLevelRelationshipBean
{
  private boolean isRequired;
  private RelationshipTypeEnum relationshipType;
  private String value;

  public RelationshipTypeEnum getRelationshipType()
  {
    return this.relationshipType;
  }

  public String getValue()
  {
    return this.value;
  }

  public boolean isRequired()
  {
    return this.isRequired;
  }

  public void setRelationshipType(RelationshipTypeEnum paramRelationshipTypeEnum)
  {
    this.relationshipType = paramRelationshipTypeEnum;
  }

  public void setRequired(boolean paramBoolean)
  {
    this.isRequired = paramBoolean;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.CoverageLevelRelationshipBean
 * JD-Core Version:    0.6.0
 */