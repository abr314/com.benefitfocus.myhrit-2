package com.benefitfocus.api.service.common.benefit._2013._2._1;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.product.CoverageLevelTypeEnum;
import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import com.benefitfocus.api.service.common.benefit.EnrolleeBean;
import com.benefitfocus.api.service.common.product._2013._2._1.PlanIdentificationBean;
import com.benefitfocus.api.service.common.rate.RateBean;
import java.util.ArrayList;
import java.util.List;

public class BenefitDetailBean
{
  private BenefitTypeEnum benefitType;
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private CoverageLevelTypeEnum coverageLevelType;
  private List<EnrolleeBean> enrollees = new ArrayList();
  private PlanIdentificationBean planIdentification;
  private RateBean rate;

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public CoverageLevelTypeEnum getCoverageLevelType()
  {
    return this.coverageLevelType;
  }

  public List<EnrolleeBean> getEnrollees()
  {
    return this.enrollees;
  }

  public PlanIdentificationBean getPlanIdentification()
  {
    return this.planIdentification;
  }

  public RateBean getPlanRate()
  {
    return this.rate;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setCoverageLevelType(CoverageLevelTypeEnum paramCoverageLevelTypeEnum)
  {
    this.coverageLevelType = paramCoverageLevelTypeEnum;
  }

  public void setEnrollees(List<EnrolleeBean> paramList)
  {
    this.enrollees = paramList;
  }

  public void setPlanIdentification(PlanIdentificationBean paramPlanIdentificationBean)
  {
    this.planIdentification = paramPlanIdentificationBean;
  }

  public void setPlanRate(RateBean paramRateBean)
  {
    this.rate = paramRateBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit._2013._2._1.BenefitDetailBean
 * JD-Core Version:    0.6.0
 */