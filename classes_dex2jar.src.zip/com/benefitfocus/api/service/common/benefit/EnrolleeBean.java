package com.benefitfocus.api.service.common.benefit;

import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import com.benefitfocus.api.service.common.DateRangeBean;
import java.util.ArrayList;
import java.util.List;

public class EnrolleeBean
{
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private DateRangeBean dateRange;
  private String personId;

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public DateRangeBean getDateRange()
  {
    return this.dateRange;
  }

  public String getPersonId()
  {
    return this.personId;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setDateRange(DateRangeBean paramDateRangeBean)
  {
    this.dateRange = paramDateRangeBean;
  }

  public void setPersonId(String paramString)
  {
    this.personId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.EnrolleeBean
 * JD-Core Version:    0.6.0
 */