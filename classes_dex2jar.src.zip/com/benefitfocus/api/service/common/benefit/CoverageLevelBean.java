package com.benefitfocus.api.service.common.benefit;

import com.benefitfocus.api.constant.product.CoverageLevelTypeEnum;
import java.util.ArrayList;
import java.util.List;

public class CoverageLevelBean
{
  private String coverageLevelName;
  private List<CoverageLevelRelationshipBean> coverageLevelRelationshipList = new ArrayList();
  private CoverageLevelTypeEnum coverageLevelType;
  private String id;
  private Integer maxAllowedEmployees;
  private Integer minRequiredEmployees;

  public String getCoverageLevelName()
  {
    return this.coverageLevelName;
  }

  public List<CoverageLevelRelationshipBean> getCoverageLevelRelationshipList()
  {
    return this.coverageLevelRelationshipList;
  }

  public CoverageLevelTypeEnum getCoverageLevelType()
  {
    return this.coverageLevelType;
  }

  public String getId()
  {
    return this.id;
  }

  public Integer getMaxAllowedEmployees()
  {
    return this.maxAllowedEmployees;
  }

  public Integer getMinRequiredEmployees()
  {
    return this.minRequiredEmployees;
  }

  public void setCoverageLevelName(String paramString)
  {
    this.coverageLevelName = paramString;
  }

  public void setCoverageLevelRelationshipList(List<CoverageLevelRelationshipBean> paramList)
  {
    this.coverageLevelRelationshipList = paramList;
  }

  public void setCoverageLevelType(CoverageLevelTypeEnum paramCoverageLevelTypeEnum)
  {
    this.coverageLevelType = paramCoverageLevelTypeEnum;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setMaxAllowedEmployees(Integer paramInteger)
  {
    this.maxAllowedEmployees = paramInteger;
  }

  public void setMinRequiredEmployees(Integer paramInteger)
  {
    this.minRequiredEmployees = paramInteger;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.CoverageLevelBean
 * JD-Core Version:    0.6.0
 */