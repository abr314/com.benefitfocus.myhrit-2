package com.benefitfocus.api.service.common.benefit;

import java.util.ArrayList;
import java.util.List;

public class BenefitElementBean
{
  private String GUID;
  private String benefitType;
  private boolean cOBRASupported;
  private String name;
  private List<SponsorProductBean> sponsorProducts = new ArrayList();

  public String getBenefitType()
  {
    return this.benefitType;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public String getName()
  {
    return this.name;
  }

  public List<SponsorProductBean> getSponsorProducts()
  {
    return this.sponsorProducts;
  }

  public boolean iscOBRASupported()
  {
    return this.cOBRASupported;
  }

  public void setBenefitType(String paramString)
  {
    this.benefitType = paramString;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setSponsorProducts(List<SponsorProductBean> paramList)
  {
    this.sponsorProducts = paramList;
  }

  public void setcOBRASupported(boolean paramBoolean)
  {
    this.cOBRASupported = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.BenefitElementBean
 * JD-Core Version:    0.6.0
 */