package com.benefitfocus.api.service.common.benefit;

import com.benefitfocus.api.service.common.DateRangeBean;
import java.util.ArrayList;
import java.util.List;

public class OfferBean
{
  private List<BenefitElementBean> benefitElements = new ArrayList();
  private String name;
  private List<DateRangeBean> openEnrollmentPeriods = new ArrayList();
  private DateRangeBean participationPeriod;

  public List<BenefitElementBean> getBenefitElements()
  {
    return this.benefitElements;
  }

  public String getName()
  {
    return this.name;
  }

  public List<DateRangeBean> getOpenEnrollmentPeriods()
  {
    return this.openEnrollmentPeriods;
  }

  public DateRangeBean getParticipationPeriod()
  {
    return this.participationPeriod;
  }

  public void setBenefitElements(List<BenefitElementBean> paramList)
  {
    this.benefitElements = paramList;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setOpenEnrollmentPeriods(List<DateRangeBean> paramList)
  {
    this.openEnrollmentPeriods = paramList;
  }

  public void setParticipationPeriod(DateRangeBean paramDateRangeBean)
  {
    this.participationPeriod = paramDateRangeBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.OfferBean
 * JD-Core Version:    0.6.0
 */