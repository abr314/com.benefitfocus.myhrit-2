package com.benefitfocus.api.service.common.benefit;

import com.benefitfocus.api.service.common.DateRangeBean;
import java.util.ArrayList;
import java.util.List;

public class SponsorProductBean
{
  private String GUID;
  private List<CoverageLevelBean> coverageLevels = new ArrayList();
  private String name;
  private DateRangeBean participationPeriod;

  public List<CoverageLevelBean> getCoverageLevels()
  {
    return this.coverageLevels;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public String getName()
  {
    return this.name;
  }

  public DateRangeBean getParticipationPeriod()
  {
    return this.participationPeriod;
  }

  public void setCoverageLevels(List<CoverageLevelBean> paramList)
  {
    this.coverageLevels = paramList;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setParticipationPeriod(DateRangeBean paramDateRangeBean)
  {
    this.participationPeriod = paramDateRangeBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.benefit.SponsorProductBean
 * JD-Core Version:    0.6.0
 */