package com.benefitfocus.api.service.common;

import java.io.Serializable;

public class AddressBean
  implements Serializable
{
  private String address1;
  private String address2;
  private String city;
  private String country;
  private String county;
  private String state;
  private String zip;

  public String getAddress1()
  {
    return this.address1;
  }

  public String getAddress2()
  {
    return this.address2;
  }

  public String getCity()
  {
    return this.city;
  }

  public String getCountry()
  {
    return this.country;
  }

  public String getCounty()
  {
    return this.county;
  }

  public String getState()
  {
    return this.state;
  }

  public String getZip()
  {
    return this.zip;
  }

  public void setAddress1(String paramString)
  {
    this.address1 = paramString;
  }

  public void setAddress2(String paramString)
  {
    this.address2 = paramString;
  }

  public void setCity(String paramString)
  {
    this.city = paramString;
  }

  public void setCountry(String paramString)
  {
    this.country = paramString;
  }

  public void setCounty(String paramString)
  {
    this.county = paramString;
  }

  public void setState(String paramString)
  {
    this.state = paramString;
  }

  public void setZip(String paramString)
  {
    this.zip = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.AddressBean
 * JD-Core Version:    0.6.0
 */