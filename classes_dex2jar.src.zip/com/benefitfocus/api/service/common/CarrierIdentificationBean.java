package com.benefitfocus.api.service.common;

public class CarrierIdentificationBean
{
  private String carrierId;
  private String shortCarrierName;

  public String getCarrierId()
  {
    return this.carrierId;
  }

  public String getShortCarrierName()
  {
    return this.shortCarrierName;
  }

  public void setCarrierId(String paramString)
  {
    this.carrierId = paramString;
  }

  public void setShortCarrierName(String paramString)
  {
    this.shortCarrierName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.common.CarrierIdentificationBean
 * JD-Core Version:    0.6.0
 */