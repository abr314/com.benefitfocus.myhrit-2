package com.benefitfocus.api.service.platform.sponsor;

import java.io.Serializable;

public class SponsorCountsBean
  implements Serializable
{
  private int memberCount;
  private int subscriberCount;

  public int getMemberCount()
  {
    return this.memberCount;
  }

  public int getSubscriberCount()
  {
    return this.subscriberCount;
  }

  public void setMemberCount(int paramInt)
  {
    this.memberCount = paramInt;
  }

  public void setSubscriberCount(int paramInt)
  {
    this.subscriberCount = paramInt;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.sponsor.SponsorCountsBean
 * JD-Core Version:    0.6.0
 */