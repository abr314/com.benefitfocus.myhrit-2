package com.benefitfocus.api.service.platform.sponsor;

import java.io.Serializable;

public class CarrierProfileBean
  implements Serializable
{
  private String carrierId;
  private String marketSegmentId;

  public String getCarrierId()
  {
    return this.carrierId;
  }

  public String getMarketSegmentId()
  {
    return this.marketSegmentId;
  }

  public void setCarrierId(String paramString)
  {
    this.carrierId = paramString;
  }

  public void setMarketSegmentId(String paramString)
  {
    this.marketSegmentId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.sponsor.CarrierProfileBean
 * JD-Core Version:    0.6.0
 */