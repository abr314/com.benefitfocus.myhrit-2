package com.benefitfocus.api.service.platform.sponsor;

import com.benefitfocus.api.service.common.AddressBean;
import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import com.benefitfocus.api.service.common.PrivateLabelElementBean;
import com.benefitfocus.api.service.common.SponsorAdminBean;
import com.benefitfocus.api.service.common.benefit.OfferBean;
import com.benefitfocus.api.service.common.categories.CategoryTypeBean;
import com.benefitfocus.api.service.platform.workflow.CarrierSponsorWorkflowBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SponsorBean
  implements Serializable
{
  private AddressBean address;
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private List<CategoryTypeBean> categoryTypes = new ArrayList();
  private SponsorCountsBean counts;
  private List<OfferBean> currentOffers = new ArrayList();
  private List<String> editableFields = new ArrayList();
  private List<OfferBean> futureOffers = new ArrayList();
  private String marketSegment;
  private Boolean myBenefitsEnabled;
  private String phoneNumber;
  private CarrierSponsorWorkflowBean primaryCarrierActiveWorkflow;
  private CarrierProfileBean primaryCarrierProfile;
  private List<PrivateLabelElementBean> privateLabelElements = new ArrayList();
  private String sICCode;
  private List<SponsorAdminBean> sponsorAdmins = new ArrayList();
  private String sponsorGUID;
  private String sponsorName;
  private String sponsoringCarrierID;
  private String taxID;
  private Boolean temporaryProspectIndicator;

  public AddressBean getAddress()
  {
    return this.address;
  }

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public List<CategoryTypeBean> getCategoryTypes()
  {
    return this.categoryTypes;
  }

  public SponsorCountsBean getCounts()
  {
    return this.counts;
  }

  public List<OfferBean> getCurrentOffers()
  {
    return this.currentOffers;
  }

  public List<String> getEditableFields()
  {
    return this.editableFields;
  }

  public List<OfferBean> getFutureOffers()
  {
    return this.futureOffers;
  }

  public String getMarketSegment()
  {
    return this.marketSegment;
  }

  public String getPhoneNumber()
  {
    return this.phoneNumber;
  }

  public CarrierSponsorWorkflowBean getPrimaryCarrierActiveWorkflow()
  {
    return this.primaryCarrierActiveWorkflow;
  }

  public CarrierProfileBean getPrimaryCarrierProfile()
  {
    return this.primaryCarrierProfile;
  }

  public List<PrivateLabelElementBean> getPrivateLabelElements()
  {
    return this.privateLabelElements;
  }

  public List<SponsorAdminBean> getSponsorAdmins()
  {
    return this.sponsorAdmins;
  }

  public String getSponsorGUID()
  {
    return this.sponsorGUID;
  }

  public String getSponsorName()
  {
    return this.sponsorName;
  }

  public String getSponsoringCarrierID()
  {
    return this.sponsoringCarrierID;
  }

  public String getTaxID()
  {
    return this.taxID;
  }

  public String getsICCode()
  {
    return this.sICCode;
  }

  public Boolean isMyBenefitsEnabled()
  {
    return this.myBenefitsEnabled;
  }

  public Boolean isTemporaryProspectIndicator()
  {
    return this.temporaryProspectIndicator;
  }

  public void setAddress(AddressBean paramAddressBean)
  {
    this.address = paramAddressBean;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setCategoryTypes(List<CategoryTypeBean> paramList)
  {
    this.categoryTypes = paramList;
  }

  public void setCounts(SponsorCountsBean paramSponsorCountsBean)
  {
    this.counts = paramSponsorCountsBean;
  }

  public void setCurrentOffers(List<OfferBean> paramList)
  {
    this.currentOffers = paramList;
  }

  public void setEditableFields(List<String> paramList)
  {
    this.editableFields = paramList;
  }

  public void setFutureOffers(List<OfferBean> paramList)
  {
    this.futureOffers = paramList;
  }

  public void setMarketSegment(String paramString)
  {
    this.marketSegment = paramString;
  }

  public void setMyBenefitsEnabled(Boolean paramBoolean)
  {
    this.myBenefitsEnabled = paramBoolean;
  }

  public void setPhoneNumber(String paramString)
  {
    this.phoneNumber = paramString;
  }

  public void setPrimaryCarrierActiveWorkflow(CarrierSponsorWorkflowBean paramCarrierSponsorWorkflowBean)
  {
    this.primaryCarrierActiveWorkflow = paramCarrierSponsorWorkflowBean;
  }

  public void setPrimaryCarrierProfile(CarrierProfileBean paramCarrierProfileBean)
  {
    this.primaryCarrierProfile = paramCarrierProfileBean;
  }

  public void setPrivateLabelElements(List<PrivateLabelElementBean> paramList)
  {
    this.privateLabelElements = paramList;
  }

  public void setSponsorAdmins(List<SponsorAdminBean> paramList)
  {
    this.sponsorAdmins = paramList;
  }

  public void setSponsorGUID(String paramString)
  {
    this.sponsorGUID = paramString;
  }

  public void setSponsorName(String paramString)
  {
    this.sponsorName = paramString;
  }

  public void setSponsoringCarrierID(String paramString)
  {
    this.sponsoringCarrierID = paramString;
  }

  public void setTaxID(String paramString)
  {
    this.taxID = paramString;
  }

  public void setTemporaryProspectIndicator(Boolean paramBoolean)
  {
    this.temporaryProspectIndicator = paramBoolean;
  }

  public void setsICCode(String paramString)
  {
    this.sICCode = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.sponsor.SponsorBean
 * JD-Core Version:    0.6.0
 */