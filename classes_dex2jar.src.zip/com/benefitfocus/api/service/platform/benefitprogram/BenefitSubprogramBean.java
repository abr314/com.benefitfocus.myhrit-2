package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.benefit.CreditStrategyTypeEnum;
import java.util.Date;

public class BenefitSubprogramBean
{
  private String GUID;
  private BenefitTypeEnum benefitType;
  private BenefitSubprogramCreditConfigurationBean creditConfigurationForByPlanSetup;
  private Boolean creditEditableByAdmin;
  private CreditStrategyTypeEnum creditStrategyType;
  private Boolean enabledInIEInd;
  private Boolean enabledInOEInd;
  private boolean isEditable;
  private BenefitSubprogramRemainingCreditsBean remainingCredits;
  private Double subprogramCreditAmount;
  private Double subprogramCreditMaxAmount;
  private String subprogramDescription;
  private Date subprogramEffectiveDate;
  private Date subprogramExpirationDate;
  private String subprogramName;
  private String subprogramType;

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public BenefitSubprogramCreditConfigurationBean getCreditConfigurationForByPlanSetup()
  {
    return this.creditConfigurationForByPlanSetup;
  }

  public Boolean getCreditEditableByAdmin()
  {
    return this.creditEditableByAdmin;
  }

  public CreditStrategyTypeEnum getCreditStrategyType()
  {
    return this.creditStrategyType;
  }

  public Boolean getEnabledInIEInd()
  {
    return this.enabledInIEInd;
  }

  public Boolean getEnabledInOEInd()
  {
    return this.enabledInOEInd;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public BenefitSubprogramRemainingCreditsBean getRemainingCredits()
  {
    return this.remainingCredits;
  }

  public Double getSubprogramCreditAmount()
  {
    return this.subprogramCreditAmount;
  }

  public Double getSubprogramCreditMaxAmount()
  {
    return this.subprogramCreditMaxAmount;
  }

  public String getSubprogramDescription()
  {
    return this.subprogramDescription;
  }

  public Date getSubprogramEffectiveDate()
  {
    return this.subprogramEffectiveDate;
  }

  public Date getSubprogramExpirationDate()
  {
    return this.subprogramExpirationDate;
  }

  public String getSubprogramName()
  {
    return this.subprogramName;
  }

  public String getSubprogramType()
  {
    return this.subprogramType;
  }

  public boolean isEditable()
  {
    return this.isEditable;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setCreditConfigurationForByPlanSetup(BenefitSubprogramCreditConfigurationBean paramBenefitSubprogramCreditConfigurationBean)
  {
    this.creditConfigurationForByPlanSetup = paramBenefitSubprogramCreditConfigurationBean;
  }

  public void setCreditEditableByAdmin(Boolean paramBoolean)
  {
    this.creditEditableByAdmin = paramBoolean;
  }

  public void setCreditStrategyType(CreditStrategyTypeEnum paramCreditStrategyTypeEnum)
  {
    this.creditStrategyType = paramCreditStrategyTypeEnum;
  }

  public void setEditable(boolean paramBoolean)
  {
    this.isEditable = paramBoolean;
  }

  public void setEnabledInIEInd(Boolean paramBoolean)
  {
    this.enabledInIEInd = paramBoolean;
  }

  public void setEnabledInOEInd(Boolean paramBoolean)
  {
    this.enabledInOEInd = paramBoolean;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setRemainingCredits(BenefitSubprogramRemainingCreditsBean paramBenefitSubprogramRemainingCreditsBean)
  {
    this.remainingCredits = paramBenefitSubprogramRemainingCreditsBean;
  }

  public void setSubprogramCreditAmount(Double paramDouble)
  {
    this.subprogramCreditAmount = paramDouble;
  }

  public void setSubprogramCreditMaxAmount(Double paramDouble)
  {
    this.subprogramCreditMaxAmount = paramDouble;
  }

  public void setSubprogramDescription(String paramString)
  {
    this.subprogramDescription = paramString;
  }

  public void setSubprogramEffectiveDate(Date paramDate)
  {
    this.subprogramEffectiveDate = paramDate;
  }

  public void setSubprogramExpirationDate(Date paramDate)
  {
    this.subprogramExpirationDate = paramDate;
  }

  public void setSubprogramName(String paramString)
  {
    this.subprogramName = paramString;
  }

  public void setSubprogramType(String paramString)
  {
    this.subprogramType = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramBean
 * JD-Core Version:    0.6.0
 */