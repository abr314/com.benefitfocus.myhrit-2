package com.benefitfocus.api.service.platform.benefitprogram;

public class BenefitSubprogramPlanCoverageLevelBean
{
  private String coverageLevelId;
  private String planId;

  public String getCoverageLevelId()
  {
    return this.coverageLevelId;
  }

  public String getPlanId()
  {
    return this.planId;
  }

  public void setCoverageLevelId(String paramString)
  {
    this.coverageLevelId = paramString;
  }

  public void setPlanId(String paramString)
  {
    this.planId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramPlanCoverageLevelBean
 * JD-Core Version:    0.6.0
 */