package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import java.util.ArrayList;
import java.util.List;

public class BenefitSubprogramCreditConfigurationBean
{
  private List<BenefitSubprogramCreditValueBean> benefitSubprogramCreditValues = new ArrayList();
  private BenefitTypeEnum benefitTypeForCalculation;

  public List<BenefitSubprogramCreditValueBean> getBenefitSubprogramCreditValues()
  {
    return this.benefitSubprogramCreditValues;
  }

  public BenefitTypeEnum getBenefitTypeForCalculation()
  {
    return this.benefitTypeForCalculation;
  }

  public void setBenefitSubprogramCreditValues(List<BenefitSubprogramCreditValueBean> paramList)
  {
    this.benefitSubprogramCreditValues = paramList;
  }

  public void setBenefitTypeForCalculation(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitTypeForCalculation = paramBenefitTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramCreditConfigurationBean
 * JD-Core Version:    0.6.0
 */