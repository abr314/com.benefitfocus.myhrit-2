package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.ArrayList;
import java.util.List;

public abstract class BenefitProgramPersistenceRequestBean extends MethodRequestBean
{
  private List<BenefitProgramBean> benefitPrograms = new ArrayList();

  public List<BenefitProgramBean> getBenefitPrograms()
  {
    return this.benefitPrograms;
  }

  public void setBenefitPrograms(List<BenefitProgramBean> paramList)
  {
    this.benefitPrograms = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramPersistenceRequestBean
 * JD-Core Version:    0.6.0
 */