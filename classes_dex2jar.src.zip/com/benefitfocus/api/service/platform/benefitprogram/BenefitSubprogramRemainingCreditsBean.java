package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.benefit.RemainingCreditSelectionEnum;
import java.util.ArrayList;
import java.util.List;

public class BenefitSubprogramRemainingCreditsBean
{
  private List<BenefitTypeEnum> remainingCreditsBenefitTypes = new ArrayList();
  private List<RemainingCreditSelectionEnum> remainingCreditsSelections = new ArrayList();
  private Boolean useRemainingCredits;

  public List<BenefitTypeEnum> getRemainingCreditsBenefitTypes()
  {
    return this.remainingCreditsBenefitTypes;
  }

  public List<RemainingCreditSelectionEnum> getRemainingCreditsSelections()
  {
    return this.remainingCreditsSelections;
  }

  public Boolean getUseRemainingCredits()
  {
    return this.useRemainingCredits;
  }

  public void setRemainingCreditsBenefitTypes(List<BenefitTypeEnum> paramList)
  {
    this.remainingCreditsBenefitTypes = paramList;
  }

  public void setRemainingCreditsSelections(List<RemainingCreditSelectionEnum> paramList)
  {
    this.remainingCreditsSelections = paramList;
  }

  public void setUseRemainingCredits(Boolean paramBoolean)
  {
    this.useRemainingCredits = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramRemainingCreditsBean
 * JD-Core Version:    0.6.0
 */