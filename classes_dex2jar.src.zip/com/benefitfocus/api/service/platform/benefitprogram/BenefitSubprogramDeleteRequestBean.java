package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public class BenefitSubprogramDeleteRequestBean extends MethodRequestBean
{
  private String GUID;

  public String getGUID()
  {
    return this.GUID;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramDeleteRequestBean
 * JD-Core Version:    0.6.0
 */