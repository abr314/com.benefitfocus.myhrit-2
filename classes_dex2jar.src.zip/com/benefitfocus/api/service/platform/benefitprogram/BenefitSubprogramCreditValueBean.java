package com.benefitfocus.api.service.platform.benefitprogram;

import java.util.ArrayList;
import java.util.List;

public class BenefitSubprogramCreditValueBean
{
  private Double amount;
  private boolean isRefused;
  private List<BenefitSubprogramPlanCoverageLevelBean> planCoverageLevels = new ArrayList();

  public Double getAmount()
  {
    return this.amount;
  }

  public List<BenefitSubprogramPlanCoverageLevelBean> getPlanCoverageLevels()
  {
    return this.planCoverageLevels;
  }

  public boolean isRefused()
  {
    return this.isRefused;
  }

  public void setAmount(Double paramDouble)
  {
    this.amount = paramDouble;
  }

  public void setPlanCoverageLevels(List<BenefitSubprogramPlanCoverageLevelBean> paramList)
  {
    this.planCoverageLevels = paramList;
  }

  public void setRefused(boolean paramBoolean)
  {
    this.isRefused = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramCreditValueBean
 * JD-Core Version:    0.6.0
 */