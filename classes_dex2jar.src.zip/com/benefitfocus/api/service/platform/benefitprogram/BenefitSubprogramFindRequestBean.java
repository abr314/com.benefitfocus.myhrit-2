package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.Date;

public class BenefitSubprogramFindRequestBean extends MethodRequestBean
{
  private String GUID;
  private String benefitProgramGUID;
  private Date endDate;
  private String sponsorGUID;
  private Date startDate;

  public String getGUID()
  {
    return this.GUID;
  }

  public String getSponsorGUID()
  {
    return this.sponsorGUID;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setSponsorGUID(String paramString)
  {
    this.sponsorGUID = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramFindRequestBean
 * JD-Core Version:    0.6.0
 */