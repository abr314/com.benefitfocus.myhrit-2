package com.benefitfocus.api.service.platform.benefitprogram;

public class BenefitProgramEnablementBean
{
  private String GUID;
  private String categoryName;
  private String categoryType;

  public String getCategoryName()
  {
    return this.categoryName;
  }

  public String getCategoryType()
  {
    return this.categoryType;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public void setCategoryName(String paramString)
  {
    this.categoryName = paramString;
  }

  public void setCategoryType(String paramString)
  {
    this.categoryType = paramString;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramEnablementBean
 * JD-Core Version:    0.6.0
 */