package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public abstract class BenefitSubprogramPersistenceRequestBean extends MethodRequestBean
{
  private BenefitSubprogramBean benefitSubprogramBean;

  public BenefitSubprogramBean getBenefitSubprogramBean()
  {
    return this.benefitSubprogramBean;
  }

  public void setBenefitSubprogramBean(BenefitSubprogramBean paramBenefitSubprogramBean)
  {
    this.benefitSubprogramBean = paramBenefitSubprogramBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitSubprogramPersistenceRequestBean
 * JD-Core Version:    0.6.0
 */