package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitProgramTypeEnum;
import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.service.common.categories.EnablementBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BenefitProgramBean
  implements Serializable
{
  private List<BenefitTypeEnum> benefitAllocationOrder = new ArrayList();
  private BenefitProgramTypeEnum benefitProgramType;
  private String completedWithinRule;
  private List<EnablementBean> enablements = new ArrayList();
  private String groupSetUpBenefitProgramDescription;
  private String id;
  private String programName;
  private List<BenefitSubprogramBean> subprogramList = new ArrayList();

  public List<BenefitTypeEnum> getBenefitAllocationOrder()
  {
    return this.benefitAllocationOrder;
  }

  public BenefitProgramTypeEnum getBenefitProgramType()
  {
    return this.benefitProgramType;
  }

  public String getCompletedWithinRule()
  {
    return this.completedWithinRule;
  }

  public List<EnablementBean> getEnablements()
  {
    return this.enablements;
  }

  public String getGroupSetUpBenefitProgramDescription()
  {
    return this.groupSetUpBenefitProgramDescription;
  }

  public String getId()
  {
    return this.id;
  }

  public String getProgramName()
  {
    return this.programName;
  }

  public List<BenefitSubprogramBean> getSubprogramList()
  {
    return this.subprogramList;
  }

  public void setBenefitAllocationOrder(List<BenefitTypeEnum> paramList)
  {
    this.benefitAllocationOrder = paramList;
  }

  public void setBenefitProgramType(BenefitProgramTypeEnum paramBenefitProgramTypeEnum)
  {
    this.benefitProgramType = paramBenefitProgramTypeEnum;
  }

  public void setCompletedWithinRule(String paramString)
  {
    this.completedWithinRule = paramString;
  }

  public void setEnablements(List<EnablementBean> paramList)
  {
    this.enablements = paramList;
  }

  public void setGroupSetUpBenefitProgramDescription(String paramString)
  {
    this.groupSetUpBenefitProgramDescription = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setProgramName(String paramString)
  {
    this.programName = paramString;
  }

  public void setSubprogramList(List<BenefitSubprogramBean> paramList)
  {
    this.subprogramList = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramBean
 * JD-Core Version:    0.6.0
 */