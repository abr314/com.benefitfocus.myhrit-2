package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitProgramTypeEnum;
import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.ArrayList;
import java.util.List;

public class BenefitProgramDeleteRequestBean extends MethodRequestBean
{
  private List<String> benefitProgramIds = new ArrayList();
  private BenefitProgramTypeEnum benefitProgramType;
  private String sponsorId;

  public List<String> getBenefitProgramIds()
  {
    return this.benefitProgramIds;
  }

  public BenefitProgramTypeEnum getBenefitProgramType()
  {
    return this.benefitProgramType;
  }

  public String getSponsorId()
  {
    return this.sponsorId;
  }

  public void setBenefitProgramIds(List<String> paramList)
  {
    this.benefitProgramIds = paramList;
  }

  public void setBenefitProgramType(BenefitProgramTypeEnum paramBenefitProgramTypeEnum)
  {
    this.benefitProgramType = paramBenefitProgramTypeEnum;
  }

  public void setSponsorId(String paramString)
  {
    this.sponsorId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramDeleteRequestBean
 * JD-Core Version:    0.6.0
 */