package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.constant.benefit.BenefitProgramTypeEnum;
import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class BenefitProgramFindRequestBean extends MethodRequestBean
{
  private String GUID;
  private BenefitProgramTypeEnum benefitProgramType;
  private Date endDate;
  private String sponsorGUID;
  private Date startDate;

  public BenefitProgramTypeEnum getBenefitProgramType()
  {
    return this.benefitProgramType;
  }

  public Date getEndDate()
  {
    return this.endDate;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public String getSponsorGUID()
  {
    return this.sponsorGUID;
  }

  public Date getStartDate()
  {
    return this.startDate;
  }

  public void setBenefitProgramType(BenefitProgramTypeEnum paramBenefitProgramTypeEnum)
  {
    this.benefitProgramType = paramBenefitProgramTypeEnum;
  }

  public void setEndDate(Date paramDate)
  {
    this.endDate = paramDate;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setSponsorGUID(String paramString)
  {
    this.sponsorGUID = paramString;
  }

  public void setStartDate(Date paramDate)
  {
    this.startDate = paramDate;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramFindRequestBean
 * JD-Core Version:    0.6.0
 */