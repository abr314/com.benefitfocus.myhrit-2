package com.benefitfocus.api.service.platform.benefitprogram;

import com.benefitfocus.api.service.common.service.MethodResponseBean;
import java.util.ArrayList;
import java.util.List;

public class BenefitProgramPersistenceResponseBean extends MethodResponseBean
{
  private List<BenefitProgramBean> results = new ArrayList();

  public List<BenefitProgramBean> getResults()
  {
    return this.results;
  }

  public void setResults(List<BenefitProgramBean> paramList)
  {
    this.results = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.benefitprogram.BenefitProgramPersistenceResponseBean
 * JD-Core Version:    0.6.0
 */