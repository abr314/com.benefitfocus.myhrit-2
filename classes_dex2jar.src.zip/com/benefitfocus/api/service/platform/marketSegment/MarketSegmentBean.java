package com.benefitfocus.api.service.platform.marketSegment;

import java.io.Serializable;

public class MarketSegmentBean
  implements Serializable
{
  private String description;
  private String id;
  private Integer max;
  private Integer min;

  public String getDescription()
  {
    return this.description;
  }

  public String getId()
  {
    return this.id;
  }

  public Integer getMax()
  {
    return this.max;
  }

  public Integer getMin()
  {
    return this.min;
  }

  public void setDescription(String paramString)
  {
    this.description = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setMax(Integer paramInteger)
  {
    this.max = paramInteger;
  }

  public void setMin(Integer paramInteger)
  {
    this.min = paramInteger;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.marketSegment.MarketSegmentBean
 * JD-Core Version:    0.6.0
 */