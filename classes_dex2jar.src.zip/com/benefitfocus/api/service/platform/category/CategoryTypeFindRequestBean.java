package com.benefitfocus.api.service.platform.category;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public class CategoryTypeFindRequestBean extends MethodRequestBean
{
  private String categoryId;
  private String categoryTypeId;
  private String sponsorId;

  public String getCategoryId()
  {
    return this.categoryId;
  }

  public String getCategoryTypeId()
  {
    return this.categoryTypeId;
  }

  public String getSponsorId()
  {
    return this.sponsorId;
  }

  public void setCategoryId(String paramString)
  {
    this.categoryId = paramString;
  }

  public void setCategoryTypeId(String paramString)
  {
    this.categoryTypeId = paramString;
  }

  public void setSponsorId(String paramString)
  {
    this.sponsorId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.category.CategoryTypeFindRequestBean
 * JD-Core Version:    0.6.0
 */