package com.benefitfocus.api.service.platform.category;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public class CategoryFindRequestBean extends MethodRequestBean
{
  private String categoryId;

  public String getCategoryId()
  {
    return this.categoryId;
  }

  public void setCategoryId(String paramString)
  {
    this.categoryId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.category.CategoryFindRequestBean
 * JD-Core Version:    0.6.0
 */