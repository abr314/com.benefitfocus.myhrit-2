package com.benefitfocus.api.service.platform.quoteProduct;

import java.util.ArrayList;
import java.util.List;

public class QuoteProductGroupBean
{
  private String groupId;
  private String id;
  private List<QuoteProductBean> quoteProducts = new ArrayList();

  public String getGroupId()
  {
    return this.groupId;
  }

  public String getId()
  {
    return this.id;
  }

  public List<QuoteProductBean> getQuoteProducts()
  {
    return this.quoteProducts;
  }

  public void setGroupId(String paramString)
  {
    this.groupId = paramString;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setQuoteProducts(List<QuoteProductBean> paramList)
  {
    this.quoteProducts = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.quoteProduct.QuoteProductGroupBean
 * JD-Core Version:    0.6.0
 */