package com.benefitfocus.api.service.platform.quoteProduct;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.payment.PaymentFrequencyBean;
import com.benefitfocus.api.constant.product.RateTypeEnum;
import com.benefitfocus.api.service.common.benefit.CoverageLevelBean;
import com.benefitfocus.api.service.common.individual._2013._2._1.FamilyBean;
import com.benefitfocus.api.service.common.product.ProductRateBean;
import com.benefitfocus.api.service.common.product.RateBandBean;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BenefitTypeQuoteProductsBean
  implements Serializable
{
  private BenefitTypeEnum benefitType;
  private String benefitTypeDescription;
  private List<CoverageLevelBean> coverageLevels = new ArrayList();
  private List<FamilyBean> families = new ArrayList();
  private PaymentFrequencyBean paymentFrequency;
  private List<QuoteProductBean> quoteProducts = new ArrayList();
  private List<RateBandBean> rateBands = new ArrayList();
  private RateTypeEnum rateType;
  private List<ProductRateBean> rates = new ArrayList();

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public String getBenefitTypeDescription()
  {
    return this.benefitTypeDescription;
  }

  public List<CoverageLevelBean> getCoverageLevels()
  {
    return this.coverageLevels;
  }

  public List<FamilyBean> getFamilies()
  {
    return this.families;
  }

  public PaymentFrequencyBean getPaymentFrequency()
  {
    return this.paymentFrequency;
  }

  public List<QuoteProductBean> getQuoteProducts()
  {
    return this.quoteProducts;
  }

  public List<RateBandBean> getRateBands()
  {
    return this.rateBands;
  }

  public RateTypeEnum getRateType()
  {
    return this.rateType;
  }

  public List<ProductRateBean> getRates()
  {
    return this.rates;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setBenefitTypeDescription(String paramString)
  {
    this.benefitTypeDescription = paramString;
  }

  public void setCoverageLevels(List<CoverageLevelBean> paramList)
  {
    this.coverageLevels = paramList;
  }

  public void setFamilies(List<FamilyBean> paramList)
  {
    this.families = paramList;
  }

  public void setPaymentFrequency(PaymentFrequencyBean paramPaymentFrequencyBean)
  {
    this.paymentFrequency = paramPaymentFrequencyBean;
  }

  public void setQuoteProducts(List<QuoteProductBean> paramList)
  {
    this.quoteProducts = paramList;
  }

  public void setRateBands(List<RateBandBean> paramList)
  {
    this.rateBands = paramList;
  }

  public void setRateType(RateTypeEnum paramRateTypeEnum)
  {
    this.rateType = paramRateTypeEnum;
  }

  public void setRates(List<ProductRateBean> paramList)
  {
    this.rates = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.quoteProduct.BenefitTypeQuoteProductsBean
 * JD-Core Version:    0.6.0
 */