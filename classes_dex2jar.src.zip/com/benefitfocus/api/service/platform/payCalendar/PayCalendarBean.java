package com.benefitfocus.api.service.platform.payCalendar;

import com.benefitfocus.api.constant.payCalendar.PayCalendarType;
import com.benefitfocus.api.constant.payCalendar.PayPeriodType;
import java.util.ArrayList;
import java.util.List;

public class PayCalendarBean
{
  private PayCalendarType calendarType;
  private String id;
  private String name;
  private PayPeriodType payPeriodType;
  private List<PayCalendarPeriodBean> periods = new ArrayList();

  public PayCalendarType getCalendarType()
  {
    return this.calendarType;
  }

  public String getId()
  {
    return this.id;
  }

  public String getName()
  {
    return this.name;
  }

  public PayPeriodType getPayPeriodType()
  {
    return this.payPeriodType;
  }

  public List<PayCalendarPeriodBean> getPeriods()
  {
    return this.periods;
  }

  public void setCalendarType(PayCalendarType paramPayCalendarType)
  {
    this.calendarType = paramPayCalendarType;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPayPeriodType(PayPeriodType paramPayPeriodType)
  {
    this.payPeriodType = paramPayPeriodType;
  }

  public void setPeriods(List<PayCalendarPeriodBean> paramList)
  {
    this.periods = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.payCalendar.PayCalendarBean
 * JD-Core Version:    0.6.0
 */