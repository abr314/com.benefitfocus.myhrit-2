package com.benefitfocus.api.service.platform.payCalendar;

import java.util.Date;

public class PayCalendarDateEntryBean
{
  private Date date;
  private boolean eom;

  public Date getDate()
  {
    return this.date;
  }

  public boolean isEOM()
  {
    return this.eom;
  }

  public void setDate(Date paramDate)
  {
    this.date = paramDate;
  }

  public void setEOM(boolean paramBoolean)
  {
    this.eom = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.payCalendar.PayCalendarDateEntryBean
 * JD-Core Version:    0.6.0
 */