package com.benefitfocus.api.service.platform.payCalendar;

public class PayCalendarPeriodBean
{
  private PayCalendarDateEntryBean checkDate;
  private PayCalendarDateEntryBean cutOffDate;
  private PayCalendarDateEntryBean endDate;
  private PayCalendarDateEntryBean startDate;

  public PayCalendarDateEntryBean getCheckDate()
  {
    return this.checkDate;
  }

  public PayCalendarDateEntryBean getCutOffDate()
  {
    return this.cutOffDate;
  }

  public PayCalendarDateEntryBean getEndDate()
  {
    return this.endDate;
  }

  public PayCalendarDateEntryBean getStartDate()
  {
    return this.startDate;
  }

  public void setCheckDate(PayCalendarDateEntryBean paramPayCalendarDateEntryBean)
  {
    this.checkDate = paramPayCalendarDateEntryBean;
  }

  public void setCutOffDate(PayCalendarDateEntryBean paramPayCalendarDateEntryBean)
  {
    this.cutOffDate = paramPayCalendarDateEntryBean;
  }

  public void setEndDate(PayCalendarDateEntryBean paramPayCalendarDateEntryBean)
  {
    this.endDate = paramPayCalendarDateEntryBean;
  }

  public void setStartDate(PayCalendarDateEntryBean paramPayCalendarDateEntryBean)
  {
    this.startDate = paramPayCalendarDateEntryBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.payCalendar.PayCalendarPeriodBean
 * JD-Core Version:    0.6.0
 */