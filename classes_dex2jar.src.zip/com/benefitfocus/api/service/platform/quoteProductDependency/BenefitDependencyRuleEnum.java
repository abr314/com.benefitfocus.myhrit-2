package com.benefitfocus.api.service.platform.quoteProductDependency;

public enum BenefitDependencyRuleEnum
{
  static
  {
    DEPEND_EXACTLYONE_ALL = new BenefitDependencyRuleEnum("DEPEND_EXACTLYONE_ALL", 3);
    DEPEND_ATLEASTONE_ANY = new BenefitDependencyRuleEnum("DEPEND_ATLEASTONE_ANY", 4);
    DEPEND_ATLEASTONE_ALL = new BenefitDependencyRuleEnum("DEPEND_ATLEASTONE_ALL", 5);
    DEPEND_REFUSE_ALL = new BenefitDependencyRuleEnum("DEPEND_REFUSE_ALL", 6);
    DEPEND_REFUSE_ANY = new BenefitDependencyRuleEnum("DEPEND_REFUSE_ANY", 7);
    BenefitDependencyRuleEnum[] arrayOfBenefitDependencyRuleEnum = new BenefitDependencyRuleEnum[8];
    arrayOfBenefitDependencyRuleEnum[0] = DEPEND_ACCEPT_ALL;
    arrayOfBenefitDependencyRuleEnum[1] = DEPEND_ACCEPT_ANY;
    arrayOfBenefitDependencyRuleEnum[2] = DEPEND_EXACTLYONE_ANY;
    arrayOfBenefitDependencyRuleEnum[3] = DEPEND_EXACTLYONE_ALL;
    arrayOfBenefitDependencyRuleEnum[4] = DEPEND_ATLEASTONE_ANY;
    arrayOfBenefitDependencyRuleEnum[5] = DEPEND_ATLEASTONE_ALL;
    arrayOfBenefitDependencyRuleEnum[6] = DEPEND_REFUSE_ALL;
    arrayOfBenefitDependencyRuleEnum[7] = DEPEND_REFUSE_ANY;
    $VALUES = arrayOfBenefitDependencyRuleEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.quoteProductDependency.BenefitDependencyRuleEnum
 * JD-Core Version:    0.6.0
 */