package com.benefitfocus.api.service.platform.quoteProductDependency;

import java.io.Serializable;

public class QuoteProductDependencyBean
  implements Serializable
{
  private DependencyElementBean child;
  private String id;
  private DependencyElementBean parent;
  private BenefitDependencyRuleEnum rule;

  public DependencyElementBean getChild()
  {
    return this.child;
  }

  public String getId()
  {
    return this.id;
  }

  public DependencyElementBean getParent()
  {
    return this.parent;
  }

  public BenefitDependencyRuleEnum getRule()
  {
    return this.rule;
  }

  public void setChild(DependencyElementBean paramDependencyElementBean)
  {
    this.child = paramDependencyElementBean;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setParent(DependencyElementBean paramDependencyElementBean)
  {
    this.parent = paramDependencyElementBean;
  }

  public void setRule(BenefitDependencyRuleEnum paramBenefitDependencyRuleEnum)
  {
    this.rule = paramBenefitDependencyRuleEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.quoteProductDependency.QuoteProductDependencyBean
 * JD-Core Version:    0.6.0
 */