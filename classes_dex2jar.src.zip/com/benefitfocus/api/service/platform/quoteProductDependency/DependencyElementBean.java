package com.benefitfocus.api.service.platform.quoteProductDependency;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.benefit.ProductPlanTypeEnum;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class DependencyElementBean
  implements Serializable
{
  private List<BenefitTypeEnum> benefitTypes = new ArrayList();
  private List<String> productIds = new ArrayList();
  private List<ProductPlanTypeEnum> productTypes = new ArrayList();

  public List<BenefitTypeEnum> getBenefitTypes()
  {
    return this.benefitTypes;
  }

  public List<String> getProductIds()
  {
    return this.productIds;
  }

  public List<ProductPlanTypeEnum> getProductTypes()
  {
    return this.productTypes;
  }

  public void setBenefitTypes(List<BenefitTypeEnum> paramList)
  {
    this.benefitTypes = paramList;
  }

  public void setProductIds(List<String> paramList)
  {
    this.productIds = paramList;
  }

  public void setProductTypes(List<ProductPlanTypeEnum> paramList)
  {
    this.productTypes = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.quoteProductDependency.DependencyElementBean
 * JD-Core Version:    0.6.0
 */