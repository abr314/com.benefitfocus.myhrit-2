package com.benefitfocus.api.service.platform.carrier;

import com.benefitfocus.api.service.common.service.MethodResponseBean;
import java.util.ArrayList;
import java.util.List;

public class GetCarrierInfoResponseBean extends MethodResponseBean
{
  private List<CarrierInfoBean> carriers = new ArrayList();

  public List<CarrierInfoBean> getCarriers()
  {
    return this.carriers;
  }

  public void setCarriers(List<CarrierInfoBean> paramList)
  {
    this.carriers = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.carrier.GetCarrierInfoResponseBean
 * JD-Core Version:    0.6.0
 */