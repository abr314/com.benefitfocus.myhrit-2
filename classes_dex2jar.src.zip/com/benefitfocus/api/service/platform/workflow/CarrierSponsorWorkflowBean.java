package com.benefitfocus.api.service.platform.workflow;

import com.benefitfocus.api.constant.eSales.CarrierWorkflowStatusTypeEnum;
import java.io.Serializable;
import java.util.Date;

public class CarrierSponsorWorkflowBean
  implements Serializable
{
  private Date benefitStartDate;
  private CarrierWorkflowStatusTypeEnum workflowStatusType;

  public Date getBenefitStartDate()
  {
    return this.benefitStartDate;
  }

  public CarrierWorkflowStatusTypeEnum getWorkflowStatusType()
  {
    return this.workflowStatusType;
  }

  public void setBenefitStartDate(Date paramDate)
  {
    this.benefitStartDate = paramDate;
  }

  public void setWorkflowStatusType(CarrierWorkflowStatusTypeEnum paramCarrierWorkflowStatusTypeEnum)
  {
    this.workflowStatusType = paramCarrierWorkflowStatusTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.workflow.CarrierSponsorWorkflowBean
 * JD-Core Version:    0.6.0
 */