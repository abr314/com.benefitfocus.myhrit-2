package com.benefitfocus.api.service.platform.taxSavings;

public class ContributionMatchingBean
{
  private Double amount;
  private ContributionMatchingTypeEnum contributionMatchingType;
  private Double percent;

  public Double getAmount()
  {
    return this.amount;
  }

  public ContributionMatchingTypeEnum getContributionMatchingType()
  {
    return this.contributionMatchingType;
  }

  public Double getPercent()
  {
    return this.percent;
  }

  public void setAmount(Double paramDouble)
  {
    this.amount = paramDouble;
  }

  public void setContributionMatchingType(ContributionMatchingTypeEnum paramContributionMatchingTypeEnum)
  {
    this.contributionMatchingType = paramContributionMatchingTypeEnum;
  }

  public void setPercent(Double paramDouble)
  {
    this.percent = paramDouble;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.taxSavings.ContributionMatchingBean
 * JD-Core Version:    0.6.0
 */