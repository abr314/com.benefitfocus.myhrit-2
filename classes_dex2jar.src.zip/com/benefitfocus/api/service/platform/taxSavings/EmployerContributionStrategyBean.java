package com.benefitfocus.api.service.platform.taxSavings;

import com.benefitfocus.api.service.common.categories.EnablementBean;
import java.util.ArrayList;
import java.util.List;

public class EmployerContributionStrategyBean
{
  private ContributionTypeBean contributionType;
  private List<String> coverageLevelIds = new ArrayList();
  private EnablementBean enablement;
  private String name;
  private List<String> planIds = new ArrayList();

  public ContributionTypeBean getContributionType()
  {
    return this.contributionType;
  }

  public List<String> getCoverageLevelIds()
  {
    return this.coverageLevelIds;
  }

  public EnablementBean getEnablement()
  {
    return this.enablement;
  }

  public String getName()
  {
    return this.name;
  }

  public List<String> getPlanIds()
  {
    return this.planIds;
  }

  public void setContributionType(ContributionTypeBean paramContributionTypeBean)
  {
    this.contributionType = paramContributionTypeBean;
  }

  public void setCoverageLevelIds(List<String> paramList)
  {
    this.coverageLevelIds = paramList;
  }

  public void setEnablement(EnablementBean paramEnablementBean)
  {
    this.enablement = paramEnablementBean;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPlanIds(List<String> paramList)
  {
    this.planIds = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.taxSavings.EmployerContributionStrategyBean
 * JD-Core Version:    0.6.0
 */