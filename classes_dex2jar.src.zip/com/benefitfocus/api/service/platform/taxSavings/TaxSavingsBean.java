package com.benefitfocus.api.service.platform.taxSavings;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TaxSavingsBean
{
  private Date effectiveDate;
  private List<EmployerContributionStrategyBean> employerContributionStrategyBeans = new ArrayList();
  private Date expirationDate;
  private String id;
  private boolean isEditable;
  private TaxSavingsProgramTypeEnum programType;

  public Date getEffectiveDate()
  {
    return this.effectiveDate;
  }

  public List<EmployerContributionStrategyBean> getEmployerContributionStrategyBeans()
  {
    return this.employerContributionStrategyBeans;
  }

  public Date getExpirationDate()
  {
    return this.expirationDate;
  }

  public String getId()
  {
    return this.id;
  }

  public TaxSavingsProgramTypeEnum getProgramType()
  {
    return this.programType;
  }

  public boolean isEditable()
  {
    return this.isEditable;
  }

  public void setEditable(boolean paramBoolean)
  {
    this.isEditable = paramBoolean;
  }

  public void setEffectiveDate(Date paramDate)
  {
    this.effectiveDate = paramDate;
  }

  public void setEmployerContributionStrategyBeans(List<EmployerContributionStrategyBean> paramList)
  {
    this.employerContributionStrategyBeans = paramList;
  }

  public void setExpirationDate(Date paramDate)
  {
    this.expirationDate = paramDate;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setProgramType(TaxSavingsProgramTypeEnum paramTaxSavingsProgramTypeEnum)
  {
    this.programType = paramTaxSavingsProgramTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.taxSavings.TaxSavingsBean
 * JD-Core Version:    0.6.0
 */