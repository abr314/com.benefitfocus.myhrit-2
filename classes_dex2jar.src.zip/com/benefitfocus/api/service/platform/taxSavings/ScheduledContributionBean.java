package com.benefitfocus.api.service.platform.taxSavings;

import java.util.Date;

public class ScheduledContributionBean
{
  private Double amount;
  private Date date;

  public Double getAmount()
  {
    return this.amount;
  }

  public Date getDate()
  {
    return this.date;
  }

  public void setAmount(Double paramDouble)
  {
    this.amount = paramDouble;
  }

  public void setDate(Date paramDate)
  {
    this.date = paramDate;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.taxSavings.ScheduledContributionBean
 * JD-Core Version:    0.6.0
 */