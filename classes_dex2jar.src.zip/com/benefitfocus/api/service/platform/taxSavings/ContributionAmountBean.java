package com.benefitfocus.api.service.platform.taxSavings;

public class ContributionAmountBean
{
  private Double amount;
  private ContributionMatchingBean contributionMatchingBean;
  private boolean isProrated;

  public Double getAmount()
  {
    return this.amount;
  }

  public ContributionMatchingBean getContributionMatchingBean()
  {
    return this.contributionMatchingBean;
  }

  public boolean isProrated()
  {
    return this.isProrated;
  }

  public void setAmount(Double paramDouble)
  {
    this.amount = paramDouble;
  }

  public void setContributionMatchingBean(ContributionMatchingBean paramContributionMatchingBean)
  {
    this.contributionMatchingBean = paramContributionMatchingBean;
  }

  public void setProrated(boolean paramBoolean)
  {
    this.isProrated = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.taxSavings.ContributionAmountBean
 * JD-Core Version:    0.6.0
 */