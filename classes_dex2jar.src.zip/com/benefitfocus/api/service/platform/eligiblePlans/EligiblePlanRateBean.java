package com.benefitfocus.api.service.platform.eligiblePlans;

import com.benefitfocus.api.service.common.CurrencyBean;

public class EligiblePlanRateBean
{
  String coverageLevelName;
  CurrencyBean employeeCost;
  CurrencyBean employerCost;

  public String getCoverageLevelName()
  {
    return this.coverageLevelName;
  }

  public CurrencyBean getEmployeeCost()
  {
    return this.employeeCost;
  }

  public CurrencyBean getEmployerCost()
  {
    return this.employerCost;
  }

  public void setCoverageLevelName(String paramString)
  {
    this.coverageLevelName = paramString;
  }

  public void setEmployeeCost(CurrencyBean paramCurrencyBean)
  {
    this.employeeCost = paramCurrencyBean;
  }

  public void setEmployerCost(CurrencyBean paramCurrencyBean)
  {
    this.employerCost = paramCurrencyBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.eligiblePlans.EligiblePlanRateBean
 * JD-Core Version:    0.6.0
 */