package com.benefitfocus.api.service.platform.eligiblePlans;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.Date;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GetEligiblePlanListRequestBean extends MethodRequestBean
{
  private BenefitTypeEnum benefitType;
  private Date date;
  private String personOid;

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public Date getDate()
  {
    return this.date;
  }

  public String getPersonOid()
  {
    return this.personOid;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setDate(Date paramDate)
  {
    this.date = paramDate;
  }

  public void setPersonOid(String paramString)
  {
    this.personOid = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.eligiblePlans.GetEligiblePlanListRequestBean
 * JD-Core Version:    0.6.0
 */