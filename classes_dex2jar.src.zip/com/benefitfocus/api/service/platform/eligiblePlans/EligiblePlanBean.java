package com.benefitfocus.api.service.platform.eligiblePlans;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import java.util.Date;
import java.util.List;

public class EligiblePlanBean
{
  private BenefitTypeEnum benefitType;
  private boolean isEligible;
  private Date participationPeriodEndDate;
  private Date participationPeriodStartDate;
  private List<EligiblePlanRateBean> planRates;
  private String sponsorProductName;

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public Date getParticipationPeriodEndDate()
  {
    return this.participationPeriodEndDate;
  }

  public Date getParticipationPeriodStartDate()
  {
    return this.participationPeriodStartDate;
  }

  public List<EligiblePlanRateBean> getPlanRates()
  {
    return this.planRates;
  }

  public String getSponsorProductName()
  {
    return this.sponsorProductName;
  }

  public boolean isEligible()
  {
    return this.isEligible;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setEligible(boolean paramBoolean)
  {
    this.isEligible = paramBoolean;
  }

  public void setParticipationPeriodEndDate(Date paramDate)
  {
    this.participationPeriodEndDate = paramDate;
  }

  public void setParticipationPeriodStartDate(Date paramDate)
  {
    this.participationPeriodStartDate = paramDate;
  }

  public void setPlanRates(List<EligiblePlanRateBean> paramList)
  {
    this.planRates = paramList;
  }

  public void setSponsorProductName(String paramString)
  {
    this.sponsorProductName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.eligiblePlans.EligiblePlanBean
 * JD-Core Version:    0.6.0
 */