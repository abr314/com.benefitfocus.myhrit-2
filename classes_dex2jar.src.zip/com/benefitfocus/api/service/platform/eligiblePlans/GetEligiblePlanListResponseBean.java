package com.benefitfocus.api.service.platform.eligiblePlans;

import com.benefitfocus.api.service.common.service.MethodResponseBean;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class GetEligiblePlanListResponseBean extends MethodResponseBean
{
  private List<EligiblePlanBean> resultsList = new ArrayList();

  public List<EligiblePlanBean> getResultsList()
  {
    return this.resultsList;
  }

  public void setResultsList(List<EligiblePlanBean> paramList)
  {
    this.resultsList = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.eligiblePlans.GetEligiblePlanListResponseBean
 * JD-Core Version:    0.6.0
 */