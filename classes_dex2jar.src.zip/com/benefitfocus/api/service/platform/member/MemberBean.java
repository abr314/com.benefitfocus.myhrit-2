package com.benefitfocus.api.service.platform.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MemberBean
  implements Serializable
{
  private static final long serialVersionUID = -6636211852273244930L;
  String address1;
  String address2;
  private String alternatePhone;
  String city;
  private List<ContactBean> contacts = new ArrayList();
  String country;
  private String emailAddress;
  private String firstName;
  private String homePhone;
  private String lastName;
  private String middleName;
  private String mobilePhone;
  String postalCode;
  private String referenceGuid;
  String state;
  private boolean subscriber;
  private String suffix;

  public String getAddress1()
  {
    return this.address1;
  }

  public String getAddress2()
  {
    return this.address2;
  }

  public String getAlternatePhone()
  {
    return this.alternatePhone;
  }

  public String getCity()
  {
    return this.city;
  }

  public List<ContactBean> getContacts()
  {
    return this.contacts;
  }

  public String getCountry()
  {
    return this.country;
  }

  public String getEmailAddress()
  {
    return this.emailAddress;
  }

  public String getFirstName()
  {
    return this.firstName;
  }

  public String getHomePhone()
  {
    return this.homePhone;
  }

  public String getLastName()
  {
    return this.lastName;
  }

  public String getMiddleName()
  {
    return this.middleName;
  }

  public String getMobilePhone()
  {
    return this.mobilePhone;
  }

  public String getPostalCode()
  {
    return this.postalCode;
  }

  public String getReferenceGuid()
  {
    return this.referenceGuid;
  }

  public String getState()
  {
    return this.state;
  }

  public String getSuffix()
  {
    return this.suffix;
  }

  public boolean isSubscriber()
  {
    return this.subscriber;
  }

  public void setAddress1(String paramString)
  {
    this.address1 = paramString;
  }

  public void setAddress2(String paramString)
  {
    this.address2 = paramString;
  }

  public void setAlternatePhone(String paramString)
  {
    this.alternatePhone = paramString;
  }

  public void setCity(String paramString)
  {
    this.city = paramString;
  }

  public void setContacts(List<ContactBean> paramList)
  {
    this.contacts = paramList;
  }

  public void setCountry(String paramString)
  {
    this.country = paramString;
  }

  public void setEmailAddress(String paramString)
  {
    this.emailAddress = paramString;
  }

  public void setFirstName(String paramString)
  {
    this.firstName = paramString;
  }

  public void setHomePhone(String paramString)
  {
    this.homePhone = paramString;
  }

  public void setLastName(String paramString)
  {
    this.lastName = paramString;
  }

  public void setMiddleName(String paramString)
  {
    this.middleName = paramString;
  }

  public void setMobilePhone(String paramString)
  {
    this.mobilePhone = paramString;
  }

  public void setPostalCode(String paramString)
  {
    this.postalCode = paramString;
  }

  public void setReferenceGuid(String paramString)
  {
    this.referenceGuid = paramString;
  }

  public void setState(String paramString)
  {
    this.state = paramString;
  }

  public void setSubscriber(boolean paramBoolean)
  {
    this.subscriber = paramBoolean;
  }

  public void setSuffix(String paramString)
  {
    this.suffix = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.member.MemberBean
 * JD-Core Version:    0.6.0
 */