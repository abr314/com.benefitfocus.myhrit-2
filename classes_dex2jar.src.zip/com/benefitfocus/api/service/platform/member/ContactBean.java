package com.benefitfocus.api.service.platform.member;

public class ContactBean
{
  private String address1;
  private String address2;
  private String alternatePhoneNumber;
  private String city;
  private String country;
  private String emailAddress;
  private String name;
  private String phoneNumber;
  private String postalCode;
  private String referenceOid;
  private String relationship;
  private int sortOrder;
  private String state;
  private boolean useEmployeeAddress;

  public String getAddress1()
  {
    return this.address1;
  }

  public String getAddress2()
  {
    return this.address2;
  }

  public String getAlternatePhoneNumber()
  {
    return this.alternatePhoneNumber;
  }

  public String getCity()
  {
    return this.city;
  }

  public String getCountry()
  {
    return this.country;
  }

  public String getEmailAddress()
  {
    return this.emailAddress;
  }

  public String getName()
  {
    return this.name;
  }

  public String getPhoneNumber()
  {
    return this.phoneNumber;
  }

  public String getPostalCode()
  {
    return this.postalCode;
  }

  public String getReferenceOid()
  {
    return this.referenceOid;
  }

  public String getRelationship()
  {
    return this.relationship;
  }

  public int getSortOrder()
  {
    return this.sortOrder;
  }

  public String getState()
  {
    return this.state;
  }

  public boolean isUseEmployeeAddress()
  {
    return this.useEmployeeAddress;
  }

  public void setAddress1(String paramString)
  {
    this.address1 = paramString;
  }

  public void setAddress2(String paramString)
  {
    this.address2 = paramString;
  }

  public void setAlternatePhoneNumber(String paramString)
  {
    this.alternatePhoneNumber = paramString;
  }

  public void setCity(String paramString)
  {
    this.city = paramString;
  }

  public void setCountry(String paramString)
  {
    this.country = paramString;
  }

  public void setEmailAddress(String paramString)
  {
    this.emailAddress = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPhoneNumber(String paramString)
  {
    this.phoneNumber = paramString;
  }

  public void setPostalCode(String paramString)
  {
    this.postalCode = paramString;
  }

  public void setReferenceOid(String paramString)
  {
    this.referenceOid = paramString;
  }

  public void setRelationship(String paramString)
  {
    this.relationship = paramString;
  }

  public void setSortOrder(int paramInt)
  {
    this.sortOrder = paramInt;
  }

  public void setState(String paramString)
  {
    this.state = paramString;
  }

  public void setUseEmployeeAddress(boolean paramBoolean)
  {
    this.useEmployeeAddress = paramBoolean;
  }

  public static enum ContactType
  {
    static
    {
      CARRIER = new ContactType("CARRIER", 1);
      ContactType[] arrayOfContactType = new ContactType[2];
      arrayOfContactType[0] = PERSONEMERGENCY;
      arrayOfContactType[1] = CARRIER;
      $VALUES = arrayOfContactType;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.member.ContactBean
 * JD-Core Version:    0.6.0
 */