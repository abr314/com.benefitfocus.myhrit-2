package com.benefitfocus.api.service.platform.planList;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.benefit.ProductPlanTypeEnum;
import com.benefitfocus.api.service.common.DateRangeBean;
import com.benefitfocus.api.service.common.benefit.CoverageLevelBean;
import java.util.ArrayList;
import java.util.List;

public class PlanBean
{
  private String GUID;
  private BenefitTypeEnum benefitType;
  private List<CoverageLevelBean> coverageLevels = new ArrayList();
  private DateRangeBean participationPeriod;
  private ProductPlanTypeEnum planType;
  private String sponsorProductName;

  public void addToCoverageLevelList(CoverageLevelBean paramCoverageLevelBean)
  {
    this.coverageLevels.add(paramCoverageLevelBean);
  }

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public List<CoverageLevelBean> getCoverageLevels()
  {
    return this.coverageLevels;
  }

  public String getGUID()
  {
    return this.GUID;
  }

  public DateRangeBean getParticipationPeriod()
  {
    return this.participationPeriod;
  }

  public ProductPlanTypeEnum getPlanType()
  {
    return this.planType;
  }

  public String getSponsorProductName()
  {
    return this.sponsorProductName;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setCoverageLevels(List<CoverageLevelBean> paramList)
  {
    this.coverageLevels = paramList;
  }

  public void setGUID(String paramString)
  {
    this.GUID = paramString;
  }

  public void setParticipationPeriod(DateRangeBean paramDateRangeBean)
  {
    this.participationPeriod = paramDateRangeBean;
  }

  public void setPlanType(ProductPlanTypeEnum paramProductPlanTypeEnum)
  {
    this.planType = paramProductPlanTypeEnum;
  }

  public void setSponsorProductName(String paramString)
  {
    this.sponsorProductName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.platform.planList.PlanBean
 * JD-Core Version:    0.6.0
 */