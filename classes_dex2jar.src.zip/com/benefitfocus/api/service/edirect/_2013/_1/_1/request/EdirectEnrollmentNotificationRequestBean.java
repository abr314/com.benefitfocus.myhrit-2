package com.benefitfocus.api.service.edirect._2013._1._1.request;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public class EdirectEnrollmentNotificationRequestBean extends MethodRequestBean
{
  private Boolean enrollmentComplete;
  private String message;
  private String notificationId;
  private String partnerReceiptId;
  private String status;
  private String subscriberAlternateId;
  private String subscriberMemberId;
  private String workflowState;

  public String getMessage()
  {
    return this.message;
  }

  public String getNotificationId()
  {
    return this.notificationId;
  }

  public String getPartnerReceiptId()
  {
    return this.partnerReceiptId;
  }

  public String getStatus()
  {
    return this.status;
  }

  public String getSubscriberAlternateId()
  {
    return this.subscriberAlternateId;
  }

  public String getSubscriberMemberId()
  {
    return this.subscriberMemberId;
  }

  public String getWorkflowState()
  {
    return this.workflowState;
  }

  public Boolean isEnrollmentComplete()
  {
    return this.enrollmentComplete;
  }

  public void setEnrollmentComplete(Boolean paramBoolean)
  {
    this.enrollmentComplete = paramBoolean;
  }

  public void setMessage(String paramString)
  {
    this.message = paramString;
  }

  public void setNotificationId(String paramString)
  {
    this.notificationId = paramString;
  }

  public void setPartnerReceiptId(String paramString)
  {
    this.partnerReceiptId = paramString;
  }

  public void setStatus(String paramString)
  {
    this.status = paramString;
  }

  public void setSubscriberAlternateId(String paramString)
  {
    this.subscriberAlternateId = paramString;
  }

  public void setSubscriberMemberId(String paramString)
  {
    this.subscriberMemberId = paramString;
  }

  public void setWorkflowState(String paramString)
  {
    this.workflowState = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.edirect._2013._1._1.request.EdirectEnrollmentNotificationRequestBean
 * JD-Core Version:    0.6.0
 */