package com.benefitfocus.api.service.edirect._2013._1._1.response;

import com.benefitfocus.api.service.common.service.MethodResponseBean;

public class EdirectEnrollmentNotificationResponseBean extends MethodResponseBean
{
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.edirect._2013._1._1.response.EdirectEnrollmentNotificationResponseBean
 * JD-Core Version:    0.6.0
 */