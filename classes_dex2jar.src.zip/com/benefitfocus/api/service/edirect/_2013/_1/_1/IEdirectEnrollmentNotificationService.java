package com.benefitfocus.api.service.edirect._2013._1._1;

import com.benefitfocus.api.service.edirect._2013._1._1.request.EdirectEnrollmentNotificationRequestBean;
import com.benefitfocus.api.service.edirect._2013._1._1.response.EdirectEnrollmentNotificationResponseBean;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;

@WebService(serviceName="EdirectEnrollmentNotificationService", targetNamespace="http://services.benefitfocus.com/serviceApi/notification/2013/1/1")
@SOAPBinding(parameterStyle=SOAPBinding.ParameterStyle.BARE)
public abstract interface IEdirectEnrollmentNotificationService
{
  @WebMethod(operationName="processNotification")
  public abstract EdirectEnrollmentNotificationResponseBean processNotification(@WebParam(name="request") EdirectEnrollmentNotificationRequestBean paramEdirectEnrollmentNotificationRequestBean);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.edirect._2013._1._1.IEdirectEnrollmentNotificationService
 * JD-Core Version:    0.6.0
 */