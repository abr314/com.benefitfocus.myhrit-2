package com.benefitfocus.api.service.enterprise.testService;

import com.benefitfocus.api.service.common.service.MethodRequestBean;

public class EnterpriseTestServiceRequestBean extends MethodRequestBean
{
  private String personID;

  public String getPersonID()
  {
    return this.personID;
  }

  public void setPersonID(String paramString)
  {
    this.personID = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.testService.EnterpriseTestServiceRequestBean
 * JD-Core Version:    0.6.0
 */