package com.benefitfocus.api.service.enterprise.testService;

import com.benefitfocus.api.service.common.service.MethodResponseBean;

public class EnterpriseTestServiceResponseBean extends MethodResponseBean
{
  private String personName;

  public String getPersonName()
  {
    return this.personName;
  }

  public void setPersonName(String paramString)
  {
    this.personName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.testService.EnterpriseTestServiceResponseBean
 * JD-Core Version:    0.6.0
 */