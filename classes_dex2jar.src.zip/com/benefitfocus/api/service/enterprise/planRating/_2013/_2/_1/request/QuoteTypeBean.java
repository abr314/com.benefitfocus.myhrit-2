package com.benefitfocus.api.service.enterprise.planRating._2013._2._1.request;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.payment.PaymentFrequencyBean;
import com.benefitfocus.api.constant.planRating.RateSourceEnum;
import com.benefitfocus.api.constant.product.RateTypeEnum;
import com.benefitfocus.api.service.common.product._2013._2._1.PlanIdentificationBean;
import com.benefitfocus.api.service.enterprise.planRating.GroupPopulationBean;
import java.util.ArrayList;
import java.util.List;

public class QuoteTypeBean
{
  private BenefitTypeEnum benefitType;
  private GroupPopulationBean groupPopulation;
  private PaymentFrequencyBean paymentFrequency;
  private List<PlanIdentificationBean> planIdentifications = new ArrayList();
  private RateSourceEnum rateSource;
  private RateTypeEnum rateType;

  public BenefitTypeEnum getBenefitType()
  {
    return this.benefitType;
  }

  public GroupPopulationBean getGroupPopulation()
  {
    return this.groupPopulation;
  }

  public PaymentFrequencyBean getPaymentFrequency()
  {
    return this.paymentFrequency;
  }

  public List<PlanIdentificationBean> getPlanIdentifications()
  {
    return this.planIdentifications;
  }

  public RateSourceEnum getRateSource()
  {
    return this.rateSource;
  }

  public RateTypeEnum getRateType()
  {
    return this.rateType;
  }

  public void setBenefitType(BenefitTypeEnum paramBenefitTypeEnum)
  {
    this.benefitType = paramBenefitTypeEnum;
  }

  public void setGroupPopulation(GroupPopulationBean paramGroupPopulationBean)
  {
    this.groupPopulation = paramGroupPopulationBean;
  }

  public void setPaymentFrequency(PaymentFrequencyBean paramPaymentFrequencyBean)
  {
    this.paymentFrequency = paramPaymentFrequencyBean;
  }

  public void setPlanIdentifications(List<PlanIdentificationBean> paramList)
  {
    this.planIdentifications = paramList;
  }

  public void setRateSource(RateSourceEnum paramRateSourceEnum)
  {
    this.rateSource = paramRateSourceEnum;
  }

  public void setRateType(RateTypeEnum paramRateTypeEnum)
  {
    this.rateType = paramRateTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._2._1.request.QuoteTypeBean
 * JD-Core Version:    0.6.0
 */