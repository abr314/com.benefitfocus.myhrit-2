package com.benefitfocus.api.service.enterprise.planRating._2013._2._1.request;

import com.benefitfocus.api.constant.service.DataToReturnTypeEnum;
import com.benefitfocus.api.service.common.TenantBean;
import com.benefitfocus.api.service.common.service.MethodRequestBean;
import java.util.ArrayList;
import java.util.List;

public class GetPlanRatesRequestBean extends MethodRequestBean
{
  private List<DataToReturnTypeEnum> dataToReturnTypes = new ArrayList();
  private PlanRatesFilterBean planRatesFilter;
  private TenantBean tenant;

  public List<DataToReturnTypeEnum> getDataToReturnTypes()
  {
    return this.dataToReturnTypes;
  }

  public PlanRatesFilterBean getPlanRatesFilter()
  {
    return this.planRatesFilter;
  }

  public TenantBean getTenant()
  {
    return this.tenant;
  }

  public void setDataToReturnTypes(List<DataToReturnTypeEnum> paramList)
  {
    this.dataToReturnTypes = paramList;
  }

  public void setPlanRatesFilter(PlanRatesFilterBean paramPlanRatesFilterBean)
  {
    this.planRatesFilter = paramPlanRatesFilterBean;
  }

  public void setTenant(TenantBean paramTenantBean)
  {
    this.tenant = paramTenantBean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._2._1.request.GetPlanRatesRequestBean
 * JD-Core Version:    0.6.0
 */