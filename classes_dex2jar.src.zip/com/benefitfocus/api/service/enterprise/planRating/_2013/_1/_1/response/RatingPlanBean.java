package com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response;

import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import com.benefitfocus.api.service.common.product._2013._1._1.PlanIdentificationBean;
import com.benefitfocus.api.service.common.rate.RateBean;
import java.util.ArrayList;
import java.util.List;

public class RatingPlanBean
{
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private Boolean isPlanChanged;
  private PlanIdentificationBean planIdentfication;
  private List<RateBean> rates = new ArrayList();
  private String ratingArea;

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public Boolean getPlanChanged()
  {
    return this.isPlanChanged;
  }

  public PlanIdentificationBean getPlanIdentfication()
  {
    return this.planIdentfication;
  }

  public List<RateBean> getRates()
  {
    return this.rates;
  }

  public String getRatingArea()
  {
    return this.ratingArea;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setPlanChanged(Boolean paramBoolean)
  {
    this.isPlanChanged = paramBoolean;
  }

  public void setPlanIdentfication(PlanIdentificationBean paramPlanIdentificationBean)
  {
    this.planIdentfication = paramPlanIdentificationBean;
  }

  public void setRates(List<RateBean> paramList)
  {
    this.rates = paramList;
  }

  public void setRatingArea(String paramString)
  {
    this.ratingArea = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response.RatingPlanBean
 * JD-Core Version:    0.6.0
 */