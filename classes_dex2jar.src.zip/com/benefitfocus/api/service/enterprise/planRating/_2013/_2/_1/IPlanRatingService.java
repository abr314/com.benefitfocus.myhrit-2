package com.benefitfocus.api.service.enterprise.planRating._2013._2._1;

import com.benefitfocus.api.service.enterprise.planRating._2013._2._1.request.GetPlanRatesRequestBean;
import com.benefitfocus.api.service.enterprise.planRating._2013._2._1.response.GetPlanRatesResponseBean;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;

@WebService(serviceName="PlanRatingService", targetNamespace="http://services.benefitfocus.com/serviceApi/planRating/2013/2/1")
@SOAPBinding(parameterStyle=SOAPBinding.ParameterStyle.BARE)
public abstract interface IPlanRatingService
{
  @WebMethod(operationName="getPlanRates")
  public abstract GetPlanRatesResponseBean getPlanRates(@WebParam(name="request") GetPlanRatesRequestBean paramGetPlanRatesRequestBean);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._2._1.IPlanRatingService
 * JD-Core Version:    0.6.0
 */