package com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response;

import com.benefitfocus.api.service.common.product._2013._1._1.AttributeGroupBean;
import com.benefitfocus.api.service.common.rate.RateBean;
import java.util.ArrayList;
import java.util.List;

public class BenefitPackageBean
{
  private List<AttributeGroupBean> attributeGroups = new ArrayList();
  private Boolean comparableIndicator;
  private String name;
  private List<RatingPlanBean> planTypes = new ArrayList();
  private List<RateBean> rates = new ArrayList();

  public List<AttributeGroupBean> getAttributeGroups()
  {
    return this.attributeGroups;
  }

  public Boolean getComparableIndicator()
  {
    return this.comparableIndicator;
  }

  public String getName()
  {
    return this.name;
  }

  public List<RatingPlanBean> getPlanTypes()
  {
    return this.planTypes;
  }

  public List<RateBean> getRates()
  {
    return this.rates;
  }

  public void setAttributeGroups(List<AttributeGroupBean> paramList)
  {
    this.attributeGroups = paramList;
  }

  public void setComparableIndicator(Boolean paramBoolean)
  {
    this.comparableIndicator = paramBoolean;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPlanTypes(List<RatingPlanBean> paramList)
  {
    this.planTypes = paramList;
  }

  public void setRates(List<RateBean> paramList)
  {
    this.rates = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response.BenefitPackageBean
 * JD-Core Version:    0.6.0
 */