package com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response;

import com.benefitfocus.api.service.common.service.MethodResponseBean;
import java.util.ArrayList;
import java.util.List;

public class GetPlanRatesResponseBean extends MethodResponseBean
{
  List<BenefitPackageBean> alternateBenefitPackages = new ArrayList();
  List<BenefitPackageBean> benefitPackages = new ArrayList();

  public List<BenefitPackageBean> getAlternateBenefitPackages()
  {
    return this.alternateBenefitPackages;
  }

  public List<BenefitPackageBean> getBenefitPackages()
  {
    return this.benefitPackages;
  }

  public void setAlternateBenefitPackages(List<BenefitPackageBean> paramList)
  {
    this.alternateBenefitPackages = paramList;
  }

  public void setBenefitPackages(List<BenefitPackageBean> paramList)
  {
    this.benefitPackages = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._1._1.response.GetPlanRatesResponseBean
 * JD-Core Version:    0.6.0
 */