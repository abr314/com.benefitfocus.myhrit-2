package com.benefitfocus.api.service.enterprise.planRating._2013._1._1.request;

import com.benefitfocus.api.constant.benefit.BenefitTypeEnum;
import com.benefitfocus.api.constant.eSales.WorkflowTypeEnum;
import com.benefitfocus.api.service.common.CarrierDefinedFieldBean;
import com.benefitfocus.api.service.common.individual._2013._1._1.FamilyBean;
import com.benefitfocus.api.service.enterprise.planRating.ProductSetBean;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PlanRatesFilterBean
{
  private Date anniversaryDate;
  private List<BenefitTypeEnum> benefitTypes = new ArrayList();
  private WorkflowTypeEnum businessType;
  private List<CarrierDefinedFieldBean> carrierDefinedFields = new ArrayList();
  private Date eligibilityEffectiveDate;
  private List<FamilyBean> families = new ArrayList();
  private String productID;
  private ProductSetBean productSet;
  private List<QuoteTypeBean> quoteTypes;

  public Date getAnniversaryDate()
  {
    return this.anniversaryDate;
  }

  public List<BenefitTypeEnum> getBenefitTypes()
  {
    return this.benefitTypes;
  }

  public WorkflowTypeEnum getBusinessType()
  {
    return this.businessType;
  }

  public List<CarrierDefinedFieldBean> getCarrierDefinedFields()
  {
    return this.carrierDefinedFields;
  }

  public Date getEligibilityEffectiveDate()
  {
    return this.eligibilityEffectiveDate;
  }

  public List<FamilyBean> getFamilies()
  {
    return this.families;
  }

  public String getProductID()
  {
    return this.productID;
  }

  public ProductSetBean getProductSet()
  {
    return this.productSet;
  }

  public List<QuoteTypeBean> getQuoteType()
  {
    return this.quoteTypes;
  }

  public void setAnniversaryDate(Date paramDate)
  {
    this.anniversaryDate = paramDate;
  }

  public void setBenefitTypes(List<BenefitTypeEnum> paramList)
  {
    this.benefitTypes = paramList;
  }

  public void setBusinessType(WorkflowTypeEnum paramWorkflowTypeEnum)
  {
    this.businessType = paramWorkflowTypeEnum;
  }

  public void setCarrierDefinedFields(List<CarrierDefinedFieldBean> paramList)
  {
    this.carrierDefinedFields = paramList;
  }

  public void setEligibilityEffectiveDate(Date paramDate)
  {
    this.eligibilityEffectiveDate = paramDate;
  }

  public void setFamilies(List<FamilyBean> paramList)
  {
    this.families = paramList;
  }

  public void setProductID(String paramString)
  {
    this.productID = paramString;
  }

  public void setProductSet(ProductSetBean paramProductSetBean)
  {
    this.productSet = paramProductSetBean;
  }

  public void setQuoteType(List<QuoteTypeBean> paramList)
  {
    this.quoteTypes = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._1._1.request.PlanRatesFilterBean
 * JD-Core Version:    0.6.0
 */