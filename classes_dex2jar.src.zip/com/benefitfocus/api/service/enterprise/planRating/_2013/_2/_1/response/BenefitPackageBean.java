package com.benefitfocus.api.service.enterprise.planRating._2013._2._1.response;

import com.benefitfocus.api.constant.payment.PaymentFrequencyBean;
import com.benefitfocus.api.service.common.benefit.CoverageLevelBean;
import com.benefitfocus.api.service.common.product.RateBandBean;
import com.benefitfocus.api.service.common.product._2013._2._1.AttributeGroupBean;
import com.benefitfocus.api.service.common.rate.RateBean;
import java.util.ArrayList;
import java.util.List;

public class BenefitPackageBean
{
  private List<AttributeGroupBean> attributeGroups = new ArrayList();
  private Boolean comparableIndicator;
  private List<CoverageLevelBean> coverageLevels = new ArrayList();
  private String id;
  private Boolean isEligible;
  private String name;
  private PaymentFrequencyBean paymentFrequency;
  private List<RatingPlanBean> planTypes = new ArrayList();
  private List<RatingPlanBean> plans = new ArrayList();
  private List<RateBandBean> rateBands = new ArrayList();
  private List<RateBean> rates = new ArrayList();

  public List<AttributeGroupBean> getAttributeGroups()
  {
    return this.attributeGroups;
  }

  public Boolean getComparableIndicator()
  {
    return this.comparableIndicator;
  }

  public List<CoverageLevelBean> getCoverageLevels()
  {
    return this.coverageLevels;
  }

  public Boolean getEligible()
  {
    return this.isEligible;
  }

  public String getId()
  {
    return this.id;
  }

  public String getName()
  {
    return this.name;
  }

  public PaymentFrequencyBean getPaymentFrequency()
  {
    return this.paymentFrequency;
  }

  public List<RatingPlanBean> getPlanTypes()
  {
    return this.planTypes;
  }

  public List<RatingPlanBean> getPlans()
  {
    return this.plans;
  }

  public List<RateBandBean> getRateBands()
  {
    return this.rateBands;
  }

  public List<RateBean> getRates()
  {
    return this.rates;
  }

  public void setAttributeGroups(List<AttributeGroupBean> paramList)
  {
    this.attributeGroups = paramList;
  }

  public void setComparableIndicator(Boolean paramBoolean)
  {
    this.comparableIndicator = paramBoolean;
  }

  public void setCoverageLevels(List<CoverageLevelBean> paramList)
  {
    this.coverageLevels = paramList;
  }

  public void setEligible(Boolean paramBoolean)
  {
    this.isEligible = paramBoolean;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPaymentFrequency(PaymentFrequencyBean paramPaymentFrequencyBean)
  {
    this.paymentFrequency = paramPaymentFrequencyBean;
  }

  public void setPlanTypes(List<RatingPlanBean> paramList)
  {
    this.planTypes = paramList;
  }

  public void setPlans(List<RatingPlanBean> paramList)
  {
    this.plans = paramList;
  }

  public void setRateBands(List<RateBandBean> paramList)
  {
    this.rateBands = paramList;
  }

  public void setRates(List<RateBean> paramList)
  {
    this.rates = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating._2013._2._1.response.BenefitPackageBean
 * JD-Core Version:    0.6.0
 */