package com.benefitfocus.api.service.enterprise.planRating;

import java.math.BigInteger;

public class GroupPopulationBean
{
  private BigInteger numberOfDeclinedSpouses;
  private BigInteger numberOfEligibleMembers;
  private BigInteger numberOfSubscribers;

  public BigInteger getNumberOfDeclinedSpouses()
  {
    return this.numberOfDeclinedSpouses;
  }

  public BigInteger getNumberOfEligibleMembers()
  {
    return this.numberOfEligibleMembers;
  }

  public BigInteger getNumberOfSubscribers()
  {
    return this.numberOfSubscribers;
  }

  public void setNumberOfDeclinedSpouses(BigInteger paramBigInteger)
  {
    this.numberOfDeclinedSpouses = paramBigInteger;
  }

  public void setNumberOfEligibleMembers(BigInteger paramBigInteger)
  {
    this.numberOfEligibleMembers = paramBigInteger;
  }

  public void setNumberOfSubscribers(BigInteger paramBigInteger)
  {
    this.numberOfSubscribers = paramBigInteger;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating.GroupPopulationBean
 * JD-Core Version:    0.6.0
 */