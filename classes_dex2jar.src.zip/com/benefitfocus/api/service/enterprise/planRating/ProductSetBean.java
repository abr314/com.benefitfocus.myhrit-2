package com.benefitfocus.api.service.enterprise.planRating;

import com.benefitfocus.api.constant.benefit.ProductSetTypeEnum;

public class ProductSetBean
{
  private Boolean includeAlternatePlans;
  private ProductSetTypeEnum productSetType;

  public Boolean getIncludeAlternatePlans()
  {
    return this.includeAlternatePlans;
  }

  public ProductSetTypeEnum getProductSetType()
  {
    return this.productSetType;
  }

  public void setIncludeAlternatePlans(Boolean paramBoolean)
  {
    this.includeAlternatePlans = paramBoolean;
  }

  public void setProductSetType(ProductSetTypeEnum paramProductSetTypeEnum)
  {
    this.productSetType = paramProductSetTypeEnum;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.enterprise.planRating.ProductSetBean
 * JD-Core Version:    0.6.0
 */