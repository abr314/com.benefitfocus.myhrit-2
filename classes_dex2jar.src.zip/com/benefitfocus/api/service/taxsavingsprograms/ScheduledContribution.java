package com.benefitfocus.api.service.taxsavingsprograms;

import java.math.BigDecimal;
import java.util.Date;

public class ScheduledContribution
{
  private BigDecimal amount;
  private Date date;

  public BigDecimal getAmount()
  {
    return this.amount;
  }

  public Date getDate()
  {
    return this.date;
  }

  public void setAmount(BigDecimal paramBigDecimal)
  {
    this.amount = paramBigDecimal;
  }

  public void setDate(Date paramDate)
  {
    this.date = paramDate;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.taxsavingsprograms.ScheduledContribution
 * JD-Core Version:    0.6.0
 */