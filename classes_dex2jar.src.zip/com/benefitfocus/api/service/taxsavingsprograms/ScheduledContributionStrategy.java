package com.benefitfocus.api.service.taxsavingsprograms;

import java.util.List;

public class ScheduledContributionStrategy
{
  private List<ScheduledContribution> scheduledContributions;

  public List<ScheduledContribution> getScheduledContributions()
  {
    return this.scheduledContributions;
  }

  public void setScheduledContributions(List<ScheduledContribution> paramList)
  {
    this.scheduledContributions = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.taxsavingsprograms.ScheduledContributionStrategy
 * JD-Core Version:    0.6.0
 */