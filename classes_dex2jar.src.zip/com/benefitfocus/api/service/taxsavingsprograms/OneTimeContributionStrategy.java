package com.benefitfocus.api.service.taxsavingsprograms;

import java.math.BigDecimal;

public class OneTimeContributionStrategy
{
  private BigDecimal flatAmount;
  private ContributionMatchingStrategy initialContributionMatching;

  public BigDecimal getFlatAmount()
  {
    return this.flatAmount;
  }

  public ContributionMatchingStrategy getInitialContributionMatching()
  {
    return this.initialContributionMatching;
  }

  public void setFlatAmount(BigDecimal paramBigDecimal)
  {
    this.flatAmount = paramBigDecimal;
  }

  public void setInitialContributionMatching(ContributionMatchingStrategy paramContributionMatchingStrategy)
  {
    this.initialContributionMatching = paramContributionMatchingStrategy;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.taxsavingsprograms.OneTimeContributionStrategy
 * JD-Core Version:    0.6.0
 */