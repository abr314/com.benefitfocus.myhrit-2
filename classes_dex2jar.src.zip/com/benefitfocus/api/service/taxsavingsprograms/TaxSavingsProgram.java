package com.benefitfocus.api.service.taxsavingsprograms;

import java.util.List;

public class TaxSavingsProgram
{
  private AnnualContributionStrategy annualContributionStrategy;
  private List<String> applicableProductIds;
  private String category;
  private List<String> coverageLevels;
  private InitialContributionStrategy initialContributionStrategy;
  private String programId;
  private ProgramType programType;
  private ScheduledContributionStrategy scheduledContributionStrategy;

  public AnnualContributionStrategy getAnnualContributionStrategy()
  {
    return this.annualContributionStrategy;
  }

  public List<String> getApplicableProductIds()
  {
    return this.applicableProductIds;
  }

  public String getCategory()
  {
    return this.category;
  }

  public List<String> getCoverageLevels()
  {
    return this.coverageLevels;
  }

  public InitialContributionStrategy getInitialContributionStrategy()
  {
    return this.initialContributionStrategy;
  }

  public String getProgramId()
  {
    return this.programId;
  }

  public ProgramType getProgramType()
  {
    return this.programType;
  }

  public ScheduledContributionStrategy getScheduledContributionStrategy()
  {
    return this.scheduledContributionStrategy;
  }

  public void setAnnualContributionStrategy(AnnualContributionStrategy paramAnnualContributionStrategy)
  {
    this.annualContributionStrategy = paramAnnualContributionStrategy;
  }

  public void setApplicableProductIds(List<String> paramList)
  {
    this.applicableProductIds = paramList;
  }

  public void setCategory(String paramString)
  {
    this.category = paramString;
  }

  public void setCoverageLevels(List<String> paramList)
  {
    this.coverageLevels = paramList;
  }

  public void setInitialContributionStrategy(InitialContributionStrategy paramInitialContributionStrategy)
  {
    this.initialContributionStrategy = paramInitialContributionStrategy;
  }

  public void setProgramId(String paramString)
  {
    this.programId = paramString;
  }

  public void setProgramType(ProgramType paramProgramType)
  {
    this.programType = paramProgramType;
  }

  public void setScheduledContributionStrategy(ScheduledContributionStrategy paramScheduledContributionStrategy)
  {
    this.scheduledContributionStrategy = paramScheduledContributionStrategy;
  }

  public static enum ProgramType
  {
    static
    {
      HRA = new ProgramType("HRA", 1);
      CDHP = new ProgramType("CDHP", 2);
      ProgramType[] arrayOfProgramType = new ProgramType[3];
      arrayOfProgramType[0] = HSA;
      arrayOfProgramType[1] = HRA;
      arrayOfProgramType[2] = CDHP;
      $VALUES = arrayOfProgramType;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.taxsavingsprograms.TaxSavingsProgram
 * JD-Core Version:    0.6.0
 */