package com.benefitfocus.api.service.taxsavingsprograms;

import java.math.BigDecimal;

public class ContributionMatchingStrategy
{
  private BigDecimal maximumContribution;
  private BigDecimal percent;

  public BigDecimal getMaximumContribution()
  {
    return this.maximumContribution;
  }

  public BigDecimal getPercent()
  {
    return this.percent;
  }

  public void setMaximumContribution(BigDecimal paramBigDecimal)
  {
    this.maximumContribution = paramBigDecimal;
  }

  public void setPercent(BigDecimal paramBigDecimal)
  {
    this.percent = paramBigDecimal;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.api.service.taxsavingsprograms.ContributionMatchingStrategy
 * JD-Core Version:    0.6.0
 */