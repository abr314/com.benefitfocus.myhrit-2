package com.benefitfocus.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;

public class MobileUtil
{
  private static final String TAG = MobileUtil.class.getSimpleName();

  public static boolean isDecimalString(CharSequence paramCharSequence)
  {
    if (TextUtils.isEmpty(paramCharSequence))
      return false;
    for (int i = 0; ; i++)
    {
      if (i >= paramCharSequence.length())
        return true;
      char c = paramCharSequence.charAt(i);
      if ((c != '.') && (!Character.isDigit(c)))
        break;
    }
  }

  public static boolean isNetworkActive(Context paramContext)
  {
    ConnectivityManager localConnectivityManager = (ConnectivityManager)paramContext.getSystemService("connectivity");
    NetworkInfo localNetworkInfo1 = localConnectivityManager.getNetworkInfo(0);
    NetworkInfo localNetworkInfo2 = localConnectivityManager.getNetworkInfo(1);
    int i;
    if ((localNetworkInfo2 != null) && (localNetworkInfo2.isConnected()))
      i = 1;
    boolean bool;
    do
    {
      do
      {
        return i;
        i = 0;
      }
      while (localNetworkInfo1 == null);
      bool = localNetworkInfo1.isConnected();
      i = 0;
    }
    while (!bool);
    return true;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.util.MobileUtil
 * JD-Core Version:    0.6.0
 */