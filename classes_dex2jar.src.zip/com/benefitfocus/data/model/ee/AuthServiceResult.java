package com.benefitfocus.data.model.ee;

import com.google.gson.Gson;
import com.google.gson.internal.StringMap;
import java.util.HashMap;
import java.util.Map;

public class AuthServiceResult
{
  public static final String DISABLED_ACCOUNT = "account has been disabled";
  public static final int FAILED = 3;
  public static final int SUCCESS = 0;
  public static final int SUCCESS_PWD_EXPIRED = 1;
  public static final int SUCCESS_PWD_RESET = 2;
  private String BFToken;
  private int LoginResult = -1;
  private String Message;
  private String ResultsAsJson;
  private String Stack;
  private String UserName;
  private String sponsorId;
  private String userGuid;
  private String userOid = null;

  public int getLoginResult()
  {
    return this.LoginResult;
  }

  public String getMessage()
  {
    return this.Message;
  }

  public String getResultAsJson()
  {
    return this.ResultsAsJson;
  }

  public String getSponsorId()
  {
    if (this.sponsorId == null);
    try
    {
      Gson localGson = new Gson();
      HashMap localHashMap = new HashMap();
      this.userGuid = ((StringMap)((StringMap)((Map)localGson.fromJson(this.ResultsAsJson, localHashMap.getClass())).get("NewDataSet")).get("UserProfile")).get("SPONSOR_ID").toString();
      return this.userGuid;
    }
    catch (Exception localException)
    {
      while (true)
        this.userGuid = "";
    }
  }

  public String getStack()
  {
    return this.Stack;
  }

  public String getToken()
  {
    return this.BFToken;
  }

  public String getUserGuid()
  {
    if (this.userGuid == null);
    try
    {
      Gson localGson = new Gson();
      HashMap localHashMap = new HashMap();
      this.userGuid = ((StringMap)((StringMap)((Map)localGson.fromJson(this.ResultsAsJson, localHashMap.getClass())).get("NewDataSet")).get("UserProfile")).get("USER_GUID").toString();
      return this.userGuid;
    }
    catch (Exception localException)
    {
      while (true)
        this.userGuid = "";
    }
  }

  public String getUserName()
  {
    return this.UserName;
  }

  public String getUserOid()
  {
    if (this.userOid == null);
    try
    {
      Gson localGson = new Gson();
      HashMap localHashMap = new HashMap();
      this.userOid = ((StringMap)((StringMap)((Map)localGson.fromJson(this.ResultsAsJson, localHashMap.getClass())).get("NewDataSet")).get("UserProfile")).get("USER_OID").toString();
      return this.userOid;
    }
    catch (Exception localException)
    {
      while (true)
        this.userOid = "";
    }
  }

  public void setLoginResult(int paramInt)
  {
    this.LoginResult = paramInt;
  }

  public void setMessage(String paramString)
  {
    this.Message = paramString;
  }

  public void setResultAsJson(String paramString)
  {
    this.ResultsAsJson = paramString;
  }

  public void setStack(String paramString)
  {
    this.Stack = paramString;
  }

  public void setToken(String paramString)
  {
    this.BFToken = paramString;
  }

  public void setUserName(String paramString)
  {
    this.UserName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.AuthServiceResult
 * JD-Core Version:    0.6.0
 */