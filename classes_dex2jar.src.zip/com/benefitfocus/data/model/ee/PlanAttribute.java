package com.benefitfocus.data.model.ee;

import java.util.ArrayList;

public class PlanAttribute
{
  private Offer offer = new Offer();
  private ArrayList<PlanAttributeGroup> planAttributeGroups = new ArrayList();

  public Offer getOffer()
  {
    return this.offer;
  }

  public ArrayList<PlanAttributeGroup> getPlanAttributeGroups()
  {
    return this.planAttributeGroups;
  }

  public void setOffer(Offer paramOffer)
  {
    this.offer = paramOffer;
  }

  public void setPlanAttributeGroups(ArrayList<PlanAttributeGroup> paramArrayList)
  {
    this.planAttributeGroups = paramArrayList;
  }

  public static class Offer
  {
    private String benefitElementName;
    private int benefitPeriod;

    public String getBenefitElementName()
    {
      return this.benefitElementName;
    }

    public int getBenefitPeriod()
    {
      return this.benefitPeriod;
    }

    public void setBenefitElementName(String paramString)
    {
      this.benefitElementName = paramString;
    }

    public void setBenefitPeriod(int paramInt)
    {
      this.benefitPeriod = paramInt;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.PlanAttribute
 * JD-Core Version:    0.6.0
 */