package com.benefitfocus.data.model.ee;

import java.util.ArrayList;
import java.util.Iterator;

public class PodConfiguration
{
  private ArrayList<Configuration> configuration;
  private String pod;

  public Configuration findByKey(String paramString)
  {
    Iterator localIterator = this.configuration.iterator();
    Configuration localConfiguration;
    do
    {
      if (!localIterator.hasNext())
        return null;
      localConfiguration = (Configuration)localIterator.next();
    }
    while (!localConfiguration.id.equals(paramString));
    return localConfiguration;
  }

  public ArrayList<Configuration> getConfiguration()
  {
    return this.configuration;
  }

  public String getPod()
  {
    return this.pod;
  }

  public void setConfiguration(ArrayList<Configuration> paramArrayList)
  {
    this.configuration = paramArrayList;
  }

  public void setPod(String paramString)
  {
    this.pod = paramString;
  }

  public static class Configuration
  {
    private String id;
    private String value;

    public String getId()
    {
      return this.id;
    }

    public String getValue()
    {
      return this.value;
    }

    public void setId(String paramString)
    {
      this.id = paramString;
    }

    public void setValue(String paramString)
    {
      this.value = paramString;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.PodConfiguration
 * JD-Core Version:    0.6.0
 */