package com.benefitfocus.data.model.ee;

import java.util.ArrayList;

public class PlanAttributeGroup
{
  private ArrayList<Attribute> attributes = new ArrayList();
  long carrierId;
  private int comparisonSortOrder;
  private String name;
  private int sortOrder;

  public int getComparisonSortOrder()
  {
    return this.comparisonSortOrder;
  }

  public String getName()
  {
    return this.name;
  }

  public ArrayList<Attribute> getProductAttributes()
  {
    return this.attributes;
  }

  public int getSortOrder()
  {
    return this.sortOrder;
  }

  public void setComparisonSortOrder(int paramInt)
  {
    this.comparisonSortOrder = paramInt;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setProductAttributes(ArrayList<Attribute> paramArrayList)
  {
    this.attributes = paramArrayList;
  }

  public void setSortOrder(int paramInt)
  {
    this.sortOrder = paramInt;
  }

  public static class Attribute
  {
    private String attributeDisplay;
    private String attributeName;
    private String comparisonAttributeType;
    private String customAttributeCode;
    private boolean displayable = true;
    private String value;

    public Attribute(String paramString1, String paramString2)
    {
      this.attributeDisplay = paramString1;
      this.value = paramString2;
    }

    public String getAttributeDisplay()
    {
      return this.attributeDisplay;
    }

    public String getAttributeName()
    {
      return this.attributeName;
    }

    public String getComparisonAttributeType()
    {
      return this.comparisonAttributeType;
    }

    public String getCustomAttributeCode()
    {
      return this.customAttributeCode;
    }

    public String getValue()
    {
      return this.value;
    }

    public boolean isDisplayable()
    {
      return this.displayable;
    }

    public void setAttributeDisplay(String paramString)
    {
      this.attributeDisplay = paramString;
    }

    public void setAttributeName(String paramString)
    {
      this.attributeName = paramString;
    }

    public void setComparisonAttributeType(String paramString)
    {
      this.comparisonAttributeType = paramString;
    }

    public void setCustomAttributeCode(String paramString)
    {
      this.customAttributeCode = paramString;
    }

    public void setDisplayable(boolean paramBoolean)
    {
      this.displayable = paramBoolean;
    }

    public void setValue(String paramString)
    {
      this.value = paramString;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.PlanAttributeGroup
 * JD-Core Version:    0.6.0
 */