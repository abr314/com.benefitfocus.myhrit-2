package com.benefitfocus.data.model.ee;

public class PodResponse
{
  private String message;
  private String mobileHRiTMinVersion = "0.0";
  private String pod;
  private String status;
  private String tenant;

  public String getMessage()
  {
    return this.message;
  }

  public String getMinSupportedVersion()
  {
    return this.mobileHRiTMinVersion;
  }

  public String getPod()
  {
    return this.pod;
  }

  public String getStatus()
  {
    return this.status;
  }

  public String getTenant()
  {
    return this.tenant;
  }

  public void setMessage(String paramString)
  {
    this.message = paramString;
  }

  public void setMinSupportedVersion(String paramString)
  {
    this.mobileHRiTMinVersion = paramString;
  }

  public void setPod(String paramString)
  {
    this.pod = paramString;
  }

  public void setStatus(String paramString)
  {
    this.status = paramString;
  }

  public void setTenant(String paramString)
  {
    this.tenant = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.PodResponse
 * JD-Core Version:    0.6.0
 */