package com.benefitfocus.data.model.ee;

public class ActivationResponse
{
  private int found;
  private String mobileEnabled;
  private String sponsorID;
  private String tenantFullName;

  public int getFound()
  {
    return this.found;
  }

  public String getMobileEnabled()
  {
    return this.mobileEnabled;
  }

  public String getSponsorId()
  {
    return this.sponsorID;
  }

  public String getTenantFullName()
  {
    return this.tenantFullName;
  }

  public void setFound(int paramInt)
  {
    this.found = paramInt;
  }

  public void setMobileEnabled(String paramString)
  {
    this.mobileEnabled = paramString;
  }

  public void setSponsorId(String paramString)
  {
    this.sponsorID = paramString;
  }

  public void setTenantFullName(String paramString)
  {
    this.tenantFullName = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.ee.ActivationResponse
 * JD-Core Version:    0.6.0
 */