package com.benefitfocus.data.model.transactionhistory;

import com.benefitfocus.data.model.ee.PlanAttribute;
import java.util.ArrayList;

public class BenefitRecord
{
  public static final String STATUS_ACCEPTED = "ACCEPTED";
  private Approval approval;
  private Beneficiaries beneficiaries = new Beneficiaries();
  private String benefitCategoryType;
  private String benefitElementReferenceId;
  private String benefitIconType;
  private String benefitType;
  private String cobraStatusCode;
  private String costDisplayPeriod;
  private String coverageEffectiveDate;
  private String coverageEndDate;
  private String coverageLevel;
  private String coverageStartDate;
  private CoveredPersons coveredPersons = new CoveredPersons();
  private String employeeOngoingCost;
  private String employeePremiumAmount;
  private String employerOngoingCost;
  private String enrollmentReasonCode;
  private MobileDecoration mobile;
  private boolean nonManaged;
  private String originalEffectiveDate;
  private String participationPeriodEndDate;
  private String participationPeriodStartDate;
  private PlanAttribute planAttributes = new PlanAttribute();
  private String planType;
  private String preTaxIndicator;
  private String referenceId;
  private String refusedIndicator;
  private String relationship;
  private String sponsorBenefitOfferReferenceId;
  private String sponsorProductDisplayName;
  private String sponsorProductName;
  private String sponsorProductReferenceGUID;
  private String sponsorProductReferenceId;
  private UnderwritingCarrier underwritingCarrier;

  public Approval getApproval()
  {
    return this.approval;
  }

  public Beneficiaries getBeneficiaries()
  {
    return this.beneficiaries;
  }

  public String getBenefitCategoryType()
  {
    return this.benefitCategoryType;
  }

  public String getBenefitElementReferenceId()
  {
    return this.benefitElementReferenceId;
  }

  public String getBenefitIconType()
  {
    return this.benefitIconType;
  }

  public String getBenefitType()
  {
    return this.benefitType;
  }

  public String getCobraStatusCode()
  {
    return this.cobraStatusCode;
  }

  public String getCostDisplayPeriod()
  {
    return this.costDisplayPeriod;
  }

  public String getCoverageEffectiveDate()
  {
    return this.coverageEffectiveDate;
  }

  public String getCoverageEndDate()
  {
    return this.coverageEndDate;
  }

  public String getCoverageLevel()
  {
    return this.coverageLevel;
  }

  public String getCoverageStartDate()
  {
    return this.coverageStartDate;
  }

  public CoveredPersons getCoveredPersons()
  {
    return this.coveredPersons;
  }

  public String getEmployeeOngoingCost()
  {
    return this.employeeOngoingCost;
  }

  public String getEmployeePremiumAmount()
  {
    return this.employeePremiumAmount;
  }

  public String getEmployerOngoingCost()
  {
    return this.employerOngoingCost;
  }

  public String getEnrollmentReasonCode()
  {
    return this.enrollmentReasonCode;
  }

  public MobileDecoration getMobile()
  {
    return this.mobile;
  }

  public String getOriginalEffectiveDate()
  {
    return this.originalEffectiveDate;
  }

  public String getParticipationPeriodEndDate()
  {
    return this.participationPeriodEndDate;
  }

  public String getParticipationPeriodStartDate()
  {
    return this.participationPeriodStartDate;
  }

  public PlanAttribute getPlanAttributes()
  {
    return this.planAttributes;
  }

  public String getPlanType()
  {
    return this.planType;
  }

  public String getPreTaxIndicator()
  {
    return this.preTaxIndicator;
  }

  public String getReferenceId()
  {
    return this.referenceId;
  }

  public String getRefusedIndicator()
  {
    return this.refusedIndicator;
  }

  public String getRelationship()
  {
    return this.relationship;
  }

  public String getSponsorBenefitOfferReferenceId()
  {
    return this.sponsorBenefitOfferReferenceId;
  }

  public String getSponsorProductDisplayName()
  {
    return this.sponsorProductDisplayName;
  }

  public String getSponsorProductName()
  {
    return this.sponsorProductName;
  }

  public String getSponsorProductReferenceGUID()
  {
    return this.sponsorProductReferenceGUID;
  }

  public String getSponsorProductReferenceId()
  {
    return this.sponsorProductReferenceId;
  }

  public UnderwritingCarrier getUnderwritingCarrier()
  {
    return this.underwritingCarrier;
  }

  public boolean isNonManaged()
  {
    return this.nonManaged;
  }

  public void setApproval(Approval paramApproval)
  {
    this.approval = paramApproval;
  }

  public void setBeneficiaries(Beneficiaries paramBeneficiaries)
  {
    this.beneficiaries = paramBeneficiaries;
  }

  public void setBenefitCategoryType(String paramString)
  {
    this.benefitCategoryType = paramString;
  }

  public void setBenefitElementReferenceId(String paramString)
  {
    this.benefitElementReferenceId = paramString;
  }

  public void setBenefitIconType(String paramString)
  {
    this.benefitIconType = paramString;
  }

  public void setBenefitType(String paramString)
  {
    this.benefitType = paramString;
  }

  public void setCobraStatusCode(String paramString)
  {
    this.cobraStatusCode = paramString;
  }

  public void setCostDisplayPeriod(String paramString)
  {
    this.costDisplayPeriod = paramString;
  }

  public void setCoverageEffectiveDate(String paramString)
  {
    this.coverageEffectiveDate = paramString;
  }

  public void setCoverageEndDate(String paramString)
  {
    this.coverageEndDate = paramString;
  }

  public void setCoverageLevel(String paramString)
  {
    this.coverageLevel = paramString;
  }

  public void setCoverageStartDate(String paramString)
  {
    this.coverageStartDate = paramString;
  }

  public void setCoveredPersons(CoveredPersons paramCoveredPersons)
  {
    this.coveredPersons = paramCoveredPersons;
  }

  public void setEmployeeOngoingCost(String paramString)
  {
    this.employeeOngoingCost = paramString;
  }

  public void setEmployeePremiumAmount(String paramString)
  {
    this.employeePremiumAmount = paramString;
  }

  public void setEmployerOngoingCost(String paramString)
  {
    this.employerOngoingCost = paramString;
  }

  public void setEnrollmentReasonCode(String paramString)
  {
    this.enrollmentReasonCode = paramString;
  }

  public void setMobile(MobileDecoration paramMobileDecoration)
  {
    this.mobile = paramMobileDecoration;
  }

  public void setNonManaged(boolean paramBoolean)
  {
    this.nonManaged = paramBoolean;
  }

  public void setOriginalEffectiveDate(String paramString)
  {
    this.originalEffectiveDate = paramString;
  }

  public void setParticipationPeriodEndDate(String paramString)
  {
    this.participationPeriodEndDate = paramString;
  }

  public void setParticipationPeriodStartDate(String paramString)
  {
    this.participationPeriodStartDate = paramString;
  }

  public void setPlanAttributes(PlanAttribute paramPlanAttribute)
  {
    this.planAttributes = paramPlanAttribute;
  }

  public void setPlanType(String paramString)
  {
    this.planType = paramString;
  }

  public void setPreTaxIndicator(String paramString)
  {
    this.preTaxIndicator = paramString;
  }

  public void setReferenceId(String paramString)
  {
    this.referenceId = paramString;
  }

  public void setRefusedIndicator(String paramString)
  {
    this.refusedIndicator = paramString;
  }

  public void setRelationship(String paramString)
  {
    this.relationship = paramString;
  }

  public void setSponsorBenefitOfferReferenceId(String paramString)
  {
    this.sponsorBenefitOfferReferenceId = paramString;
  }

  public void setSponsorProductDisplayName(String paramString)
  {
    this.sponsorProductDisplayName = paramString;
  }

  public void setSponsorProductName(String paramString)
  {
    this.sponsorProductName = paramString;
  }

  public void setSponsorProductReferenceGUID(String paramString)
  {
    this.sponsorProductReferenceGUID = paramString;
  }

  public void setSponsorProductReferenceId(String paramString)
  {
    this.sponsorProductReferenceId = paramString;
  }

  public void setUnderwritingCarrier(UnderwritingCarrier paramUnderwritingCarrier)
  {
    this.underwritingCarrier = paramUnderwritingCarrier;
  }

  public static class Beneficiaries
  {
    private ArrayList<Beneficiary> beneficiary = new ArrayList();

    public ArrayList<Beneficiary> getBeneficiaries()
    {
      return this.beneficiary;
    }

    public void setBeneficiaries(ArrayList<Beneficiary> paramArrayList)
    {
      this.beneficiary = paramArrayList;
    }
  }

  public static class CoveredPersons
  {
    private ArrayList<CoveredPerson> coveredPerson = new ArrayList();

    public ArrayList<CoveredPerson> getCoveredPerson()
    {
      return this.coveredPerson;
    }

    public void setCoveredPerson(ArrayList<CoveredPerson> paramArrayList)
    {
      this.coveredPerson = paramArrayList;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.BenefitRecord
 * JD-Core Version:    0.6.0
 */