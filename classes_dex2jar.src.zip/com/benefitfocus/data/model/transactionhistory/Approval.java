package com.benefitfocus.data.model.transactionhistory;

public class Approval
{
  private String approvedBy;
  private String approvedDt;

  public String getApprovedBy()
  {
    return this.approvedBy;
  }

  public String getApprovedDt()
  {
    return this.approvedDt;
  }

  public void setApprovedBy(String paramString)
  {
    this.approvedBy = paramString;
  }

  public void setApprovedDt(String paramString)
  {
    this.approvedDt = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Approval
 * JD-Core Version:    0.6.0
 */