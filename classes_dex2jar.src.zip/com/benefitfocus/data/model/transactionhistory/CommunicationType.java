package com.benefitfocus.data.model.transactionhistory;

public class CommunicationType
{
  public static final String ALTERNATE = "ALTERNATE";
  public static final String HOME = "HOME";
  public static final String MOBILE = "MOBILE";
  public static final String PAGER = "PAGER";
  public static final String PRIMARY = "PRIMARY";
  public static final String SECONDARY = "SECONDARY";
  public static final String WORK = "WORK";
  public static final String WORK_MOBILE = "WORK_MOBILE";
  private String commType;
  private String value;

  public String getCommType()
  {
    return this.commType;
  }

  public String getValue()
  {
    return this.value;
  }

  public void setCommType(String paramString)
  {
    this.commType = paramString;
  }

  public void setValue(String paramString)
  {
    this.value = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.CommunicationType
 * JD-Core Version:    0.6.0
 */