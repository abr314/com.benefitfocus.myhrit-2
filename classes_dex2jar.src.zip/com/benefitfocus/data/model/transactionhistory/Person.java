package com.benefitfocus.data.model.transactionhistory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Person
{
  public static final String PERSON_REFERENCE_ID = "PERSON_REFERENCE_ID";
  public static final String SUBSCRIBER = "SUBSCRIBER";
  private Address address;
  private String altMemberId;
  private Benefits benefits = new Benefits();
  private String birthDate;
  private EmailAddresses emailAddresses = new EmailAddresses();
  private ArrayList<Contact> emergencyContact = new ArrayList();
  private String ethnicity;
  private String firstName = "";
  private String gender;
  private String hireDate;
  private boolean isEmployee;
  private String languageIndicator;
  private String lastName = "";
  private String maritalStatus;
  private String memberId;
  private String middleName = "";
  private PhoneNumbers phoneNumbers = new PhoneNumbers();
  private String referenceGUID;
  private String referenceId;
  private String relationship;
  private String sponsorGuid;
  private String ssn;
  private Benefits viewOnlyBenefits = new Benefits();

  public Address getAddress()
  {
    return this.address;
  }

  public String getAltMemberId()
  {
    return this.altMemberId;
  }

  public Benefits getBenefits()
  {
    return this.benefits;
  }

  public String getBirthDate()
  {
    return this.birthDate;
  }

  public EmailAddresses getEmailAddresses()
  {
    return this.emailAddresses;
  }

  public ArrayList<Contact> getEmergencyContact()
  {
    return this.emergencyContact;
  }

  public String getEthnicity()
  {
    return this.ethnicity;
  }

  public String getFirstName()
  {
    return this.firstName;
  }

  public String getGender()
  {
    return this.gender;
  }

  public String getHireDate()
  {
    return this.hireDate;
  }

  public String getLanguageIndicator()
  {
    return this.languageIndicator;
  }

  public String getLastName()
  {
    return this.lastName;
  }

  public String getMaritalStatus()
  {
    return this.maritalStatus;
  }

  public String getMemberId()
  {
    return this.memberId;
  }

  public String getMiddleName()
  {
    return this.middleName;
  }

  public PhoneNumbers getPhoneNumbers()
  {
    return this.phoneNumbers;
  }

  public String getReferenceGUID()
  {
    return this.referenceGUID;
  }

  public String getReferenceId()
  {
    return this.referenceId;
  }

  public String getRelationship()
  {
    return this.relationship;
  }

  public String getSponsorGuid()
  {
    return this.sponsorGuid;
  }

  public String getSsn()
  {
    return this.ssn;
  }

  public Benefits getViewOnlyBenefits()
  {
    return this.viewOnlyBenefits;
  }

  public boolean isEmployee()
  {
    return this.isEmployee;
  }

  public void setAddress(Address paramAddress)
  {
    this.address = paramAddress;
  }

  public void setAltMemberId(String paramString)
  {
    this.altMemberId = paramString;
  }

  public void setBenefits(Benefits paramBenefits)
  {
    this.benefits = paramBenefits;
  }

  public void setBirthDate(String paramString)
  {
    this.birthDate = paramString;
  }

  public void setEmailAddresses(EmailAddresses paramEmailAddresses)
  {
    this.emailAddresses = paramEmailAddresses;
  }

  public void setEmergencyContact(ArrayList<Contact> paramArrayList)
  {
    this.emergencyContact = paramArrayList;
  }

  public void setEthnicity(String paramString)
  {
    this.ethnicity = paramString;
  }

  public void setFirstName(String paramString)
  {
    this.firstName = paramString;
  }

  public void setGender(String paramString)
  {
    this.gender = paramString;
  }

  public void setHireDate(String paramString)
  {
    this.hireDate = paramString;
  }

  public void setIsEmployee(boolean paramBoolean)
  {
    this.isEmployee = paramBoolean;
  }

  public void setLanguageIndicator(String paramString)
  {
    this.languageIndicator = paramString;
  }

  public void setLastName(String paramString)
  {
    this.lastName = paramString;
  }

  public void setMaritalStatus(String paramString)
  {
    this.maritalStatus = paramString;
  }

  public void setMemberId(String paramString)
  {
    this.memberId = paramString;
  }

  public void setMiddleName(String paramString)
  {
    this.middleName = paramString;
  }

  public void setPhoneNumbers(PhoneNumbers paramPhoneNumbers)
  {
    this.phoneNumbers = paramPhoneNumbers;
  }

  public void setReferenceGUID(String paramString)
  {
    this.referenceGUID = paramString;
  }

  public void setReferenceId(String paramString)
  {
    this.referenceId = paramString;
  }

  public void setRelationship(String paramString)
  {
    this.relationship = paramString;
  }

  public void setSponsorGuid(String paramString)
  {
    this.sponsorGuid = paramString;
  }

  public void setSsn(String paramString)
  {
    this.ssn = paramString;
  }

  public void setViewOnlyBenefits(Benefits paramBenefits)
  {
    this.viewOnlyBenefits = paramBenefits;
  }

  public String toString()
  {
    return this.firstName + " " + this.middleName + " " + this.lastName;
  }

  public static class Benefits
  {
    private List<BenefitRecord> benefitRecord = new ArrayList();

    public List<BenefitRecord> getBenefitRecord()
    {
      return this.benefitRecord;
    }

    public void setBenefitRecords(List<BenefitRecord> paramList)
    {
      this.benefitRecord = paramList;
    }
  }

  public static class EmailAddresses
  {
    private ArrayList<CommunicationType> emailAddress = new ArrayList();

    public CommunicationType getAddressByType(String paramString)
    {
      Iterator localIterator = this.emailAddress.iterator();
      CommunicationType localCommunicationType;
      do
      {
        if (!localIterator.hasNext())
          return null;
        localCommunicationType = (CommunicationType)localIterator.next();
      }
      while (!localCommunicationType.getCommType().equalsIgnoreCase(paramString));
      return localCommunicationType;
    }

    public ArrayList<CommunicationType> getEmailAddress()
    {
      return this.emailAddress;
    }

    public void setEmailAddress(ArrayList<CommunicationType> paramArrayList)
    {
      this.emailAddress = paramArrayList;
    }
  }

  public static class PhoneNumbers
  {
    private ArrayList<CommunicationType> phoneNumber = new ArrayList();

    public CommunicationType getPhoneByType(String paramString)
    {
      if (paramString == null);
      CommunicationType localCommunicationType;
      do
      {
        Iterator localIterator;
        while (!localIterator.hasNext())
        {
          return null;
          localIterator = this.phoneNumber.iterator();
        }
        localCommunicationType = (CommunicationType)localIterator.next();
      }
      while (!paramString.equalsIgnoreCase(localCommunicationType.getCommType()));
      return localCommunicationType;
    }

    public ArrayList<CommunicationType> getPhoneNumbers()
    {
      return this.phoneNumber;
    }

    public void setPhoneNumbers(ArrayList<CommunicationType> paramArrayList)
    {
      this.phoneNumber = paramArrayList;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Person
 * JD-Core Version:    0.6.0
 */