package com.benefitfocus.data.model.transactionhistory;

public class Contact
{
  private Address address;
  private Person.EmailAddresses emailAddresses = new Person.EmailAddresses();
  private String name;
  private Person.PhoneNumbers phoneNumbers = new Person.PhoneNumbers();
  private String referenceId;
  private String relationship;
  private int sortOrder;
  private boolean useEmployeeAddressInd;

  public Address getAddress()
  {
    return this.address;
  }

  public Person.EmailAddresses getEmailAddresses()
  {
    return this.emailAddresses;
  }

  public String getName()
  {
    return this.name;
  }

  public Person.PhoneNumbers getPhoneNumbers()
  {
    return this.phoneNumbers;
  }

  public String getReferenceId()
  {
    return this.referenceId;
  }

  public String getRelationship()
  {
    return this.relationship;
  }

  public int getSortOrder()
  {
    return this.sortOrder;
  }

  public boolean isUseEmployeeAddressInd()
  {
    return this.useEmployeeAddressInd;
  }

  public void setAddress(Address paramAddress)
  {
    this.address = paramAddress;
  }

  public void setEmailAddresses(Person.EmailAddresses paramEmailAddresses)
  {
    this.emailAddresses = paramEmailAddresses;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPhoneNumbers(Person.PhoneNumbers paramPhoneNumbers)
  {
    this.phoneNumbers = paramPhoneNumbers;
  }

  public void setReferenceId(String paramString)
  {
    this.referenceId = paramString;
  }

  public void setRelationship(String paramString)
  {
    this.relationship = paramString;
  }

  public void setSortOrder(int paramInt)
  {
    this.sortOrder = paramInt;
  }

  public void setUseEmployeeAddressInd(boolean paramBoolean)
  {
    this.useEmployeeAddressInd = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Contact
 * JD-Core Version:    0.6.0
 */