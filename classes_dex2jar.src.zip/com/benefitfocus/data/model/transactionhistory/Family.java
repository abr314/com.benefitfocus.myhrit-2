package com.benefitfocus.data.model.transactionhistory;

import java.util.ArrayList;
import java.util.List;

public class Family
{
  private List<Person> person = new ArrayList();

  public List<Person> getPerson()
  {
    return this.person;
  }

  public void setPerson(List<Person> paramList)
  {
    this.person = paramList;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Family
 * JD-Core Version:    0.6.0
 */