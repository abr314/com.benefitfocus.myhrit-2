package com.benefitfocus.data.model.transactionhistory;

public class Address
{
  private String city;
  private String country;
  private String postalCode;
  private String primaryStreet;
  private String secondaryStreet;
  private String state;

  public String getCity()
  {
    return this.city;
  }

  public String getCountry()
  {
    return this.country;
  }

  public String getFormattedAddress(boolean paramBoolean)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    if (paramBoolean);
    for (String str = "\n"; ; str = "")
    {
      if (this.primaryStreet != null)
      {
        localStringBuffer.append(this.primaryStreet);
        localStringBuffer.append(str);
      }
      if (this.secondaryStreet != null)
      {
        localStringBuffer.append(this.secondaryStreet);
        localStringBuffer.append(str);
      }
      if (this.city != null)
      {
        localStringBuffer.append(this.city);
        if (this.state != null)
        {
          localStringBuffer.append(", ");
          localStringBuffer.append(this.state);
        }
        if (this.postalCode != null)
        {
          localStringBuffer.append(" ");
          localStringBuffer.append(this.postalCode);
        }
      }
      if (this.country != null)
      {
        localStringBuffer.append(str);
        localStringBuffer.append(this.country);
      }
      return localStringBuffer.toString();
    }
  }

  public String getPostalCode()
  {
    return this.postalCode;
  }

  public String getPrimaryStreet()
  {
    return this.primaryStreet;
  }

  public String getSecondaryStreet()
  {
    return this.secondaryStreet;
  }

  public String getState()
  {
    return this.state;
  }

  public void setCity(String paramString)
  {
    this.city = paramString;
  }

  public void setCountry(String paramString)
  {
    this.country = paramString;
  }

  public void setPostalCode(String paramString)
  {
    this.postalCode = paramString;
  }

  public void setPrimaryStreet(String paramString)
  {
    this.primaryStreet = paramString;
  }

  public void setSecondaryStreet(String paramString)
  {
    this.secondaryStreet = paramString;
  }

  public void setState(String paramString)
  {
    this.state = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Address
 * JD-Core Version:    0.6.0
 */