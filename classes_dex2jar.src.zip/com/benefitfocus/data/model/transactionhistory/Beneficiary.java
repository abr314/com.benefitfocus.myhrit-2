package com.benefitfocus.data.model.transactionhistory;

public class Beneficiary
{
  private Address address;
  private String allocationPercentage;
  private String beneficiaryId;
  private String birthDate;
  private String name;
  private Boolean primaryIndicator;
  private String referenceId;
  private String relationship;
  private String type;

  public Address getAddress()
  {
    return this.address;
  }

  public String getAllocationPercentage()
  {
    return this.allocationPercentage;
  }

  public String getBeneficiaryId()
  {
    return this.beneficiaryId;
  }

  public String getBirthDate()
  {
    return this.birthDate;
  }

  public String getName()
  {
    return this.name;
  }

  public Boolean getPrimaryIndicator()
  {
    return this.primaryIndicator;
  }

  public String getReferenceId()
  {
    return this.referenceId;
  }

  public String getRelationship()
  {
    return this.relationship;
  }

  public String getType()
  {
    return this.type;
  }

  public void setAddress(Address paramAddress)
  {
    this.address = paramAddress;
  }

  public void setAllocationPercentage(String paramString)
  {
    this.allocationPercentage = paramString;
  }

  public void setBeneficiaryId(String paramString)
  {
    this.beneficiaryId = paramString;
  }

  public void setBirthDate(String paramString)
  {
    this.birthDate = paramString;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setPrimaryIndicator(Boolean paramBoolean)
  {
    this.primaryIndicator = paramBoolean;
  }

  public void setReferenceId(String paramString)
  {
    this.referenceId = paramString;
  }

  public void setRelationship(String paramString)
  {
    this.relationship = paramString;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.Beneficiary
 * JD-Core Version:    0.6.0
 */