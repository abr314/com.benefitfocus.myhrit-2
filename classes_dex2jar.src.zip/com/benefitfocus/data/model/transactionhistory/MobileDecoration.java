package com.benefitfocus.data.model.transactionhistory;

public class MobileDecoration
{
  private String benefitPeriod;
  private String contributionAmount;
  private String costPerPeriod;
  private String coverageType;
  private String coverageValue;
  private String definedContribution;
  private String employeeCostWithDefinedContrib;
  private String employeeInitialContributionAmount;
  private String employerInitialContributionAmount;
  private String employerOngoingContributionAmount;
  private boolean isOpenEnrollment;

  public String getBenefitPeriod()
  {
    return this.benefitPeriod;
  }

  public String getContributionAmount()
  {
    return this.contributionAmount;
  }

  public String getCostPerPeriod()
  {
    return this.costPerPeriod;
  }

  public String getCoverageType()
  {
    return this.coverageType;
  }

  public String getCoverageValue()
  {
    return this.coverageValue;
  }

  public String getDefinedContribution()
  {
    return this.definedContribution;
  }

  public String getEmployeeCostWithDefinedContrib()
  {
    return this.employeeCostWithDefinedContrib;
  }

  public String getEmployeeInitialContributionAmount()
  {
    return this.employeeInitialContributionAmount;
  }

  public String getEmployerInitialContributionAmount()
  {
    return this.employerInitialContributionAmount;
  }

  public String getEmployerOngoingContributionAmount()
  {
    return this.employerOngoingContributionAmount;
  }

  public boolean isOpenEnrollment()
  {
    return this.isOpenEnrollment;
  }

  public void setBenefitPeriod(String paramString)
  {
    this.benefitPeriod = paramString;
  }

  public void setContributionAmount(String paramString)
  {
    this.contributionAmount = paramString;
  }

  public void setCostPerPeriod(String paramString)
  {
    this.costPerPeriod = paramString;
  }

  public void setCoverageType(String paramString)
  {
    this.coverageType = paramString;
  }

  public void setCoverageValue(String paramString)
  {
    this.coverageValue = paramString;
  }

  public void setDefinedContribution(String paramString)
  {
    this.definedContribution = paramString;
  }

  public void setEmployeeCostWithDefinedContrib(String paramString)
  {
    this.employeeCostWithDefinedContrib = paramString;
  }

  public void setEmployeeInitialContributionAmount(String paramString)
  {
    this.employeeInitialContributionAmount = paramString;
  }

  public void setEmployerInitialContributionAmount(String paramString)
  {
    this.employerInitialContributionAmount = paramString;
  }

  public void setEmployerOngoingContributionAmount(String paramString)
  {
    this.employerOngoingContributionAmount = paramString;
  }

  public void setOpenEnrollment(boolean paramBoolean)
  {
    this.isOpenEnrollment = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.MobileDecoration
 * JD-Core Version:    0.6.0
 */