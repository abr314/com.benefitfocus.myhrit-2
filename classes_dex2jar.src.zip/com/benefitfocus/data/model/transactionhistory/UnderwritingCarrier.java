package com.benefitfocus.data.model.transactionhistory;

import java.io.Serializable;

public class UnderwritingCarrier
  implements Serializable
{
  private static final long serialVersionUID = 8319409437331369660L;
  private String name;
  private String referenceId;
  private String taxId;

  public String getName()
  {
    return this.name;
  }

  public String getReferenceId()
  {
    return this.referenceId;
  }

  public String getTaxId()
  {
    return this.taxId;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public void setReferenceId(String paramString)
  {
    this.referenceId = paramString;
  }

  public void setTaxId(String paramString)
  {
    this.taxId = paramString;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.data.model.transactionhistory.UnderwritingCarrier
 * JD-Core Version:    0.6.0
 */