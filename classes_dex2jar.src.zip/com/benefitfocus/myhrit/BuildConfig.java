package com.benefitfocus.myhrit;

public final class BuildConfig
{
  public static final boolean DEBUG;
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.BuildConfig
 * JD-Core Version:    0.6.0
 */