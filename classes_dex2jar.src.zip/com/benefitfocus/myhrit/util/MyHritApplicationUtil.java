package com.benefitfocus.myhrit.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import android.util.Log;
import com.benefitfocus.data.model.ee.ActivationResponse;
import com.benefitfocus.data.model.ee.PodConfiguration;
import com.benefitfocus.data.model.ee.PodConfiguration.Configuration;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyHritApplicationUtil
{
  private static final SimpleDateFormat INPUT_DATE_FORMATTER;
  private static final SimpleDateFormat OUTPUT_DATE_FORMATTER;
  private static final String PACKAGE_NAME = "com.benefitfocus.myhrit";
  private static final String TAG = MyHritApplicationUtil.class.getSimpleName();

  static
  {
    INPUT_DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
    OUTPUT_DATE_FORMATTER = new SimpleDateFormat("MM/dd/yyyy");
  }

  public static boolean applicationNeedsUpdating(Context paramContext, String paramString)
  {
    try
    {
      double d1 = Double.parseDouble(paramString);
      double d2 = Double.parseDouble(paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0).versionName);
      return d2 < d1;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      Log.e(TAG, localNameNotFoundException.getMessage());
    }
    return false;
  }

  public static void clearUserPreferences(Context paramContext)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).edit();
    localEditor.remove("PREFERENCE_ACTIVATION_CODE");
    localEditor.remove("pod");
    localEditor.remove("PREFERENCE_USERNAME");
    localEditor.remove("ProviderId");
    localEditor.remove("ForgotPasswordPageURL");
    localEditor.remove("VideoServiceUrl");
    localEditor.remove("AuthServiceBaseUrl");
    localEditor.remove("ProxyBaseUrl");
    localEditor.remove("ProfileService");
    localEditor.remove("SnapshotServiceURL");
    localEditor.remove("SponsorServiceURL");
    localEditor.remove("SupportPhoneNumber");
    localEditor.apply();
  }

  public static boolean getBooleanPreference(Context paramContext, String paramString)
  {
    return paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).getBoolean(paramString, false);
  }

  public static String getFormattedDate(String paramString)
  {
    try
    {
      Date localDate = INPUT_DATE_FORMATTER.parse(paramString);
      String str = OUTPUT_DATE_FORMATTER.format(localDate);
      return str;
    }
    catch (Exception localException)
    {
      Log.e(TAG, "Error parsing date " + paramString + " " + localException.toString());
    }
    return "";
  }

  public static String getStringPreference(Context paramContext, String paramString)
  {
    return paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).getString(paramString, null);
  }

  public static final int getStringResourceIdByName(Context paramContext, String paramString)
  {
    return paramContext.getResources().getIdentifier(paramString, "string", "com.benefitfocus.myhrit");
  }

  public static void removeUserPreference(Context paramContext, String paramString)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).edit();
    localEditor.remove(paramString);
    localEditor.apply();
  }

  public static void savePodConfigurations(Context paramContext, ActivationResponse paramActivationResponse, String paramString, PodConfiguration paramPodConfiguration)
  {
    if (paramPodConfiguration == null)
      return;
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).edit();
    if (paramActivationResponse != null)
    {
      localEditor.putString("PREFERENCE_SPONSOR_ID", paramActivationResponse.getSponsorId());
      localEditor.putString("PREFERENCE_TENANT_FULL_NAME", paramActivationResponse.getTenantFullName());
    }
    localEditor.putString("PREFERENCE_ACTIVATION_CODE", paramString);
    localEditor.putString("pod", paramPodConfiguration.getPod());
    PodConfiguration.Configuration localConfiguration1 = paramPodConfiguration.findByKey("ProviderID");
    String str1;
    PodConfiguration.Configuration localConfiguration2;
    String str2;
    label122: PodConfiguration.Configuration localConfiguration3;
    String str3;
    label151: PodConfiguration.Configuration localConfiguration4;
    String str4;
    label180: PodConfiguration.Configuration localConfiguration5;
    String str5;
    label209: PodConfiguration.Configuration localConfiguration6;
    String str6;
    label238: PodConfiguration.Configuration localConfiguration7;
    String str7;
    label267: PodConfiguration.Configuration localConfiguration8;
    String str8;
    label296: PodConfiguration.Configuration localConfiguration9;
    if (localConfiguration1 == null)
    {
      str1 = "";
      localEditor.putString("ProviderId", str1);
      localConfiguration2 = paramPodConfiguration.findByKey("ForgotPasswordPageURL");
      if (localConfiguration2 != null)
        break label355;
      str2 = "";
      localEditor.putString("ForgotPasswordPageURL", str2);
      localConfiguration3 = paramPodConfiguration.findByKey("VideoServiceUrl");
      if (localConfiguration3 != null)
        break label365;
      str3 = "";
      localEditor.putString("VideoServiceUrl", str3);
      localConfiguration4 = paramPodConfiguration.findByKey("AuthServiceBaseUrl");
      if (localConfiguration4 != null)
        break label375;
      str4 = "";
      localEditor.putString("AuthServiceBaseUrl", str4);
      localConfiguration5 = paramPodConfiguration.findByKey("ProxyBaseUrl");
      if (localConfiguration5 != null)
        break label385;
      str5 = "";
      localEditor.putString("ProxyBaseUrl", str5);
      localConfiguration6 = paramPodConfiguration.findByKey("ProfileService");
      if (localConfiguration6 != null)
        break label395;
      str6 = "";
      localEditor.putString("ProfileService", str6);
      localConfiguration7 = paramPodConfiguration.findByKey("SnapshotServiceURL");
      if (localConfiguration7 != null)
        break label405;
      str7 = "";
      localEditor.putString("SnapshotServiceURL", str7);
      localConfiguration8 = paramPodConfiguration.findByKey("SponsorServiceURL");
      if (localConfiguration8 != null)
        break label415;
      str8 = "";
      localEditor.putString("SponsorServiceURL", str8);
      localConfiguration9 = paramPodConfiguration.findByKey("SupportPhoneNumber");
      if (localConfiguration9 != null)
        break label425;
    }
    label385: label395: label405: label415: label425: for (String str9 = ""; ; str9 = localConfiguration9.getValue())
    {
      localEditor.putString("SupportPhoneNumber", str9);
      localEditor.apply();
      return;
      str1 = localConfiguration1.getValue();
      break;
      label355: str2 = localConfiguration2.getValue();
      break label122;
      label365: str3 = localConfiguration3.getValue();
      break label151;
      label375: str4 = localConfiguration4.getValue();
      break label180;
      str5 = localConfiguration5.getValue();
      break label209;
      str6 = localConfiguration6.getValue();
      break label238;
      str7 = localConfiguration7.getValue();
      break label267;
      str8 = localConfiguration8.getValue();
      break label296;
    }
  }

  public static void saveUserPreference(Context paramContext, String paramString1, String paramString2)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).edit();
    localEditor.putString(paramString1, paramString2);
    localEditor.apply();
  }

  public static void saveUserPreference(Context paramContext, String paramString, boolean paramBoolean)
  {
    SharedPreferences.Editor localEditor = paramContext.getSharedPreferences("HRINTOUCH-prefs", 0).edit();
    localEditor.putBoolean(paramString, paramBoolean);
    localEditor.apply();
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.util.MyHritApplicationUtil
 * JD-Core Version:    0.6.0
 */