package com.benefitfocus.myhrit.util;

public class MyHritApplicationConstants
{
  public static final String AUTH_CHANGE_PASSWORD_PATH = "changepassword";
  public static final String AUTH_INCLUDE_PROFILE = "IncludeProfile";
  public static final String AUTH_LOGIN_PATH = "login";
  public static final String AUTH_PASSWORD = "Password";
  public static final String AUTH_PROVIDER_ID = "ProviderId";
  public static final String AUTH_SERVICE_BASE_URL = "AuthServiceBaseUrl";
  public static final String AUTH_USERNAME = "Username";
  public static final String BENEFIT_REFERENCE_ID = "BENEFIT_REFERENCE_ID";
  public static final String BF_TOKEN_HEADER = "BFToken";
  public static final String CACHE_DIR = "HrIntouch/Cache";
  public static final long CACHE_MAX_AGE = 43200000L;
  public static final int CACHE_SIZE = 5242880;
  public static final String CURRENT = "CURRENT";
  public static final String EXTRA_DATA_BUNDLE = "EXTRA_DATA_BUNDLE";
  public static final String FORGOT_PASSWORD_URL = "ForgotPasswordPageURL";
  public static final String FUTURE = "FUTURE";
  public static final int MAX_SERVICE_RETRY_ATTEMPTS = 3;
  public static final String NEW_BFTOKEN_HEADER = "NewBFToken";
  public static final String NEW_PASSWORD = "NewPassword";
  public static final String NEW_PASSWORD_VERIFIED = "NewPasswordVerified";
  public static final long NO_ID = -1L;
  public static final String OLD_PASSWORD = "OldPassword";
  public static final String PERSON_REFERENCE_ID = "PERSON_REFERENCE_ID";
  public static final String POD_NAME = "pod";
  public static final String POD_PROVIDER_ID = "ProviderID";
  public static final String PREFERENCES = "HRINTOUCH-prefs";
  public static final String PREFERENCE_ACTIVATION_CODE = "PREFERENCE_ACTIVATION_CODE";
  public static final String PREFERENCE_SAVE_USERNAME = "PREFERENCE_SAVE_USERNAME";
  public static final String PREFERENCE_SPONSOR_ID = "PREFERENCE_SPONSOR_ID";
  public static final String PREFERENCE_TENANT_FULL_NAME = "PREFERENCE_TENANT_FULL_NAME";
  public static final String PREFERENCE_TERMS_OF_USE_ACCEPTED = "PREFERENCE_TERMS_OF_USE_ACCEPTED";
  public static final String PREFERENCE_USERNAME = "PREFERENCE_USERNAME";
  public static final String PROFILE_SERVICE_URL = "ProfileService";
  public static final int PROFILE_SERVICE_VERSION = 1;
  public static final String PROXY_BASE_URL = "ProxyBaseUrl";
  public static final String PROXY_GET_PATH = "GetStringInternal?url=";
  public static final String PROXY_POST_PATH = "PostStringInternal";
  public static final String PROXY_SERVICE_POST_DATA = "postData";
  public static final String SNAPSHOT_SERVICE_URL = "SnapshotServiceURL";
  public static final int SNAPSHOT_SERVICE_VERSION = 2;
  public static final String SPONSOR_SERVICE_URL = "SponsorServiceURL";
  public static final String SUPPORT_PHONE_NUMBER = "SupportPhoneNumber";
  public static final String USER = "User";
  public static final String VERSIONED = "versioned";
  public static final String VERSION_SPECIFIER_PARAM = "?version=";
  public static final String VIDEO_SERVICE_URL = "VideoServiceUrl";
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.util.MyHritApplicationConstants
 * JD-Core Version:    0.6.0
 */