package com.benefitfocus.myhrit.adapters;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.benefitfocus.data.model.ee.PlanAttribute;
import com.benefitfocus.data.model.ee.PlanAttribute.Offer;
import com.benefitfocus.data.model.transactionhistory.Approval;
import com.benefitfocus.data.model.transactionhistory.BenefitRecord;
import com.benefitfocus.myhrit.util.MyHritApplicationUtil;
import java.util.ArrayList;

public class BenefitOverviewListAdapter extends BaseAdapter
{
  public static final String ACTIVE_HEADER = "ACTIVE_HEADER";
  public static final int BENEFIT_VIEW = 2;
  public static final int HEADER_VIEW = 1;
  public static final String INACTIVE_HEADER = "INACTIVE_HEADER";
  public static final String NONMANAGED_HEADER = "NONMANAGED_HEADER";
  public static long NO_ID;
  private static String TAG = BenefitOverviewListAdapter.class.getSimpleName();
  private Context context;
  private ArrayList<BenefitRecord> data;

  static
  {
    NO_ID = -1L;
  }

  public BenefitOverviewListAdapter(Context paramContext, ArrayList<BenefitRecord> paramArrayList)
  {
    this.context = paramContext;
    this.data = paramArrayList;
  }

  private void setupViewForBenefitDisplay(ViewHolder paramViewHolder, BenefitRecord paramBenefitRecord)
  {
    paramViewHolder.header.setVisibility(8);
    paramViewHolder.enrollmentStatus.setVisibility(8);
    paramViewHolder.benefitElementName.setVisibility(0);
    paramViewHolder.benefitIcon.setVisibility(0);
    if (paramBenefitRecord.isNonManaged())
    {
      paramViewHolder.benefitElementName.setText(paramBenefitRecord.getBenefitType());
      paramViewHolder.planName.setText(paramBenefitRecord.getSponsorProductName());
    }
    while (true)
    {
      Object localObject;
      if (!"ACCEPTED".equalsIgnoreCase(paramBenefitRecord.getEnrollmentReasonCode()))
      {
        paramViewHolder.enrollmentStatus.setVisibility(0);
        paramViewHolder.planName.setGravity(0);
        paramViewHolder.planName.setVisibility(8);
        paramViewHolder.enrollmentStatus.setText(this.context.getString(MyHritApplicationUtil.getStringResourceIdByName(this.context, paramBenefitRecord.getEnrollmentReasonCode().toLowerCase())));
        paramViewHolder.enrollmentStatus.setTextColor(this.context.getResources().getColor(2131099682));
        if ((!paramBenefitRecord.isNonManaged()) && ((paramBenefitRecord.getApproval() == null) || (paramBenefitRecord.getApproval().getApprovedDt() == null)))
        {
          paramViewHolder.enrollmentStatus.setText(this.context.getString(2131427399));
          paramViewHolder.enrollmentStatus.setTextColor(this.context.getResources().getColor(2131099691));
          paramViewHolder.enrollmentStatus.setVisibility(0);
        }
        localObject = BenefitIconType.OTHER;
      }
      try
      {
        BenefitIconType localBenefitIconType = BenefitIconType.valueOf(paramBenefitRecord.getBenefitIconType());
        localObject = localBenefitIconType;
        label230: paramViewHolder.benefitIcon.setImageResource(((BenefitIconType)localObject).value);
        return;
        paramViewHolder.benefitElementName.setText(paramBenefitRecord.getPlanAttributes().getOffer().getBenefitElementName());
        if (TextUtils.isEmpty(paramViewHolder.benefitElementName.getText()))
          paramViewHolder.benefitElementName.setText(paramBenefitRecord.getBenefitType());
        paramViewHolder.planName.setText(paramBenefitRecord.getSponsorProductDisplayName());
        paramViewHolder.planName.setVisibility(0);
        continue;
        paramViewHolder.enrollmentStatus.setVisibility(8);
      }
      catch (Exception localException)
      {
        break label230;
      }
    }
  }

  private void setupViewForHeaderDisplay(ViewHolder paramViewHolder, BenefitRecord paramBenefitRecord)
  {
    paramViewHolder.header.setVisibility(0);
    paramViewHolder.benefitElementName.setVisibility(8);
    paramViewHolder.benefitIcon.setVisibility(8);
    paramViewHolder.enrollmentStatus.setVisibility(8);
    paramViewHolder.planName.setVisibility(4);
    if ("ACTIVE_HEADER".equals(paramBenefitRecord.getBenefitType()))
      paramViewHolder.header.setText(this.context.getString(2131427400));
    do
    {
      return;
      if (!"INACTIVE_HEADER".equals(paramBenefitRecord.getBenefitType()))
        continue;
      paramViewHolder.header.setText(this.context.getString(2131427401));
      return;
    }
    while (!"NONMANAGED_HEADER".equals(paramBenefitRecord.getBenefitType()));
    paramViewHolder.header.setText(this.context.getString(2131427402));
  }

  public boolean areAllItemsEnabled()
  {
    return true;
  }

  public int getCount()
  {
    return this.data.size();
  }

  public BenefitRecord getItem(int paramInt)
  {
    return (BenefitRecord)this.data.get(paramInt);
  }

  public long getItemId(int paramInt)
  {
    BenefitRecord localBenefitRecord = getItem(paramInt);
    try
    {
      if (!TextUtils.isEmpty(localBenefitRecord.getReferenceId()))
      {
        long l = Long.valueOf(localBenefitRecord.getReferenceId()).longValue();
        return l;
      }
    }
    catch (Exception localException)
    {
      Log.e(TAG, localException.getMessage());
    }
    return NO_ID;
  }

  public int getItemViewType(int paramInt)
  {
    BenefitRecord localBenefitRecord = getItem(paramInt);
    if (("ACTIVE_HEADER".equals(localBenefitRecord.getBenefitType())) || ("INACTIVE_HEADER".equals(localBenefitRecord.getBenefitType())) || ("NONMANAGED_HEADER".equals(localBenefitRecord.getBenefitType())))
      return 1;
    return 2;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      paramView = LayoutInflater.from(this.context).inflate(2130903071, paramViewGroup, false);
      localViewHolder = new ViewHolder();
      localViewHolder.planName = ((TextView)paramView.findViewById(2131034214));
      localViewHolder.benefitElementName = ((TextView)paramView.findViewById(2131034257));
      localViewHolder.enrollmentStatus = ((TextView)paramView.findViewById(2131034215));
      localViewHolder.benefitIcon = ((ImageView)paramView.findViewById(2131034213));
      localViewHolder.header = ((TextView)paramView.findViewById(2131034255));
      paramView.setTag(localViewHolder);
    }
    while (true)
      switch (getItemViewType(paramInt))
      {
      default:
        return paramView;
        localViewHolder = (ViewHolder)paramView.getTag();
      case 1:
      case 2:
      }
    setupViewForHeaderDisplay(localViewHolder, getItem(paramInt));
    paramView.setBackgroundColor(this.context.getResources().getColor(17170445));
    return paramView;
    setupViewForBenefitDisplay(localViewHolder, getItem(paramInt));
    paramView.setBackgroundResource(2130837626);
    return paramView;
  }

  public boolean isEnabled(int paramInt)
  {
    BenefitRecord localBenefitRecord = getItem(paramInt);
    return (getItemViewType(paramInt) == 2) && (!localBenefitRecord.isNonManaged());
  }

  public static enum BenefitIconType
  {
    private int value;

    static
    {
      DENTAL = new BenefitIconType("DENTAL", 1, 2130837631);
      VISION = new BenefitIconType("VISION", 2, 2130837642);
      DISABILITY = new BenefitIconType("DISABILITY", 3, 2130837633);
      LIFE = new BenefitIconType("LIFE", 4, 2130837636);
      HEALTH_SAVINGS = new BenefitIconType("HEALTH_SAVINGS", 5, 2130837640);
      FLEX_SPENDING = new BenefitIconType("FLEX_SPENDING", 6, 2130837634);
      RETIREMENT = new BenefitIconType("RETIREMENT", 7, 2130837640);
      PENSION = new BenefitIconType("PENSION", 8, 2130837640);
      LEGAL = new BenefitIconType("LEGAL", 9, 2130837635);
      CRITICAL_ILLNESS = new BenefitIconType("CRITICAL_ILLNESS", 10, 2130837630);
      LONG_TERM_DISABILITY = new BenefitIconType("LONG_TERM_DISABILITY", 11, 2130837637);
      SHORT_TERM_DISABILITY = new BenefitIconType("SHORT_TERM_DISABILITY", 12, 2130837641);
      OTHER = new BenefitIconType("OTHER", 13, 2130837639);
      BenefitIconType[] arrayOfBenefitIconType = new BenefitIconType[14];
      arrayOfBenefitIconType[0] = HEALTH;
      arrayOfBenefitIconType[1] = DENTAL;
      arrayOfBenefitIconType[2] = VISION;
      arrayOfBenefitIconType[3] = DISABILITY;
      arrayOfBenefitIconType[4] = LIFE;
      arrayOfBenefitIconType[5] = HEALTH_SAVINGS;
      arrayOfBenefitIconType[6] = FLEX_SPENDING;
      arrayOfBenefitIconType[7] = RETIREMENT;
      arrayOfBenefitIconType[8] = PENSION;
      arrayOfBenefitIconType[9] = LEGAL;
      arrayOfBenefitIconType[10] = CRITICAL_ILLNESS;
      arrayOfBenefitIconType[11] = LONG_TERM_DISABILITY;
      arrayOfBenefitIconType[12] = SHORT_TERM_DISABILITY;
      arrayOfBenefitIconType[13] = OTHER;
      ENUM$VALUES = arrayOfBenefitIconType;
    }

    private BenefitIconType(int arg3)
    {
      int j;
      this.value = j;
    }

    public int getResourceId()
    {
      return this.value;
    }
  }

  static class ViewHolder
  {
    TextView benefitElementName;
    ImageView benefitIcon;
    TextView enrollmentStatus;
    TextView header;
    TextView planName;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.adapters.BenefitOverviewListAdapter
 * JD-Core Version:    0.6.0
 */