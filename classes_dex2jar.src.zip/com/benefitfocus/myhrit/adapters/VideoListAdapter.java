package com.benefitfocus.myhrit.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filter.FilterResults;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.SectionIndexer;
import android.widget.TextView;
import com.benefitfocus.myhrit.MyHritApplication;
import com.benefitfocus.myhrit.data.Videos.VideoElement;
import com.benefitfocus.tasks.BackgroundImageLoaderTask;
import com.benefitfocus.tasks.BackgroundImageLoaderTask.AsyncDrawable;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.DisplayImageOptions.Builder;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.SimpleImageLoadingListener;
import com.nostra13.universalimageloader.core.display.FadeInBitmapDisplayer;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class VideoListAdapter extends BaseAdapter
  implements SectionIndexer, Filterable
{
  private static final String ALPHABET = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  private static final String TAG = VideoListAdapter.class.getSimpleName();
  private AnimateFirstDisplayListener animationLoadListener = new AnimateFirstDisplayListener(null);
  private Context context;
  DisplayImageOptions displayOptions = new DisplayImageOptions.Builder().cacheOnDisc().showStubImage(2130837654).showImageOnFail(2130837654).resetViewBeforeLoading().build();
  private VideoFilter filter = new VideoFilter(null);
  private ImageLoader imageLoader;
  private SparseIntArray index = null;
  private Bitmap placeHolder;
  private String[] sections = null;
  private ArrayList<Videos.VideoElement> videos;

  public VideoListAdapter(Context paramContext, ArrayList<Videos.VideoElement> paramArrayList, String paramString)
  {
    this.context = paramContext;
    this.videos = paramArrayList;
    this.placeHolder = BitmapFactory.decodeResource(paramContext.getResources(), 2130837654);
    this.sections = new String["#ABCDEFGHIJKLMNOPQRSTUVWXYZ".length()];
    this.index = new SparseIntArray("#ABCDEFGHIJKLMNOPQRSTUVWXYZ".length());
    for (int i = 0; ; i++)
    {
      if (i >= "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray().length)
      {
        if (FragmentActivity.class.isAssignableFrom(paramContext.getClass()))
          this.imageLoader = ((MyHritApplication)((FragmentActivity)FragmentActivity.class.cast(paramContext)).getApplication()).getImageLoader();
        generateIndex();
        return;
      }
      this.sections[i] = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ".charAt(i);
    }
  }

  private void generateIndex()
  {
    Object localObject = "";
    int i = 0;
    if (i >= this.videos.size())
      return;
    String str1 = ((Videos.VideoElement)this.videos.get(i)).getCaption();
    if (TextUtils.isEmpty(str1));
    for (String str2 = "#"; ; str2 = str1.substring(0, 1).toUpperCase())
    {
      if (Character.isDigit(str2.charAt(0)))
        str2 = "#";
      if (!str2.equals(localObject))
      {
        int j = Arrays.binarySearch(this.sections, str2);
        SparseIntArray localSparseIntArray = this.index;
        if (j < 0)
          j = 0;
        localSparseIntArray.put(j, i);
      }
      localObject = str2;
      i++;
      break;
    }
  }

  public int getCount()
  {
    return this.videos.size();
  }

  public Filter getFilter()
  {
    return this.filter;
  }

  public Object getItem(int paramInt)
  {
    return this.videos.get(paramInt);
  }

  public long getItemId(int paramInt)
  {
    return 0L;
  }

  public int getPositionForSection(int paramInt)
  {
    return this.index.get(paramInt);
  }

  public int getSectionForPosition(int paramInt)
  {
    Videos.VideoElement localVideoElement = (Videos.VideoElement)this.videos.get(paramInt);
    if (TextUtils.isEmpty(localVideoElement.getCaption()));
    for (String str = "#"; ; str = localVideoElement.getCaption().substring(0, 1).toUpperCase())
    {
      int i = Arrays.binarySearch(this.sections, str);
      if (i < 0)
        i = 0;
      return i;
    }
  }

  public Object[] getSections()
  {
    return this.sections;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Videos.VideoElement localVideoElement1 = (Videos.VideoElement)getItem(paramInt);
    String str1 = "http:" + localVideoElement1.getThumbnail();
    ViewHolder localViewHolder;
    char c1;
    label247: char c2;
    if (paramView == null)
    {
      paramView = LayoutInflater.from(this.context).inflate(2130903065, paramViewGroup, false);
      localViewHolder = new ViewHolder();
      localViewHolder.caption = ((TextView)paramView.findViewById(2131034188));
      localViewHolder.thumbnail = ((ImageView)paramView.findViewById(2131034187));
      localViewHolder.description = ((TextView)paramView.findViewById(2131034189));
      localViewHolder.sectionHeader = ((TextView)paramView.findViewById(2131034186));
      localViewHolder.thumbnail.setAnimation(AnimationUtils.loadAnimation(this.context, 2130968577));
      paramView.setTag(localViewHolder);
      localViewHolder.caption.setText(localVideoElement1.getCaption());
      localViewHolder.description.setText(localVideoElement1.getDescription());
      localViewHolder.videoUrl = ("http:" + localVideoElement1.getUrl());
      localViewHolder.thumbnail.setImageResource(2130837654);
      if (paramInt <= 0)
        break label392;
      Videos.VideoElement localVideoElement2 = (Videos.VideoElement)getItem(paramInt - 1);
      if (TextUtils.isEmpty(localVideoElement1.getCaption()))
        break label365;
      c1 = localVideoElement1.getCaption().toUpperCase().charAt(0);
      if (TextUtils.isEmpty(localVideoElement2.getCaption()))
        break label372;
      c2 = localVideoElement2.getCaption().toUpperCase().charAt(0);
      label272: if (c1 == c2)
        break label379;
      localViewHolder.sectionHeader.setText(String.valueOf(c1));
      localViewHolder.sectionHeader.setVisibility(0);
    }
    label365: label372: label379: 
    do
      while (true)
      {
        localViewHolder.thumbnail.setTag(str1);
        this.imageLoader.displayImage("http:" + localVideoElement1.getThumbnail(), localViewHolder.thumbnail, this.displayOptions, this.animationLoadListener);
        return paramView;
        localViewHolder = (ViewHolder)paramView.getTag();
        break;
        c1 = ' ';
        break label247;
        c2 = ' ';
        break label272;
        localViewHolder.sectionHeader.setVisibility(8);
      }
    while (paramInt != 0);
    label392: TextView localTextView = localViewHolder.sectionHeader;
    if (!TextUtils.isEmpty(localVideoElement1.getCaption()));
    for (String str2 = String.valueOf(localVideoElement1.getCaption().toUpperCase().charAt(0)); ; str2 = " ")
    {
      localTextView.setText(str2);
      localViewHolder.sectionHeader.setVisibility(0);
      break;
    }
  }

  public void loadBitmap(URL paramURL, ImageView paramImageView)
  {
    if (BackgroundImageLoaderTask.cancelPotentialWork(paramURL, paramImageView))
    {
      BackgroundImageLoaderTask localBackgroundImageLoaderTask = new BackgroundImageLoaderTask(paramImageView, AnimationUtils.loadAnimation(this.context, 2130968577));
      paramImageView.setImageDrawable(new BackgroundImageLoaderTask.AsyncDrawable(this.context.getResources(), this.placeHolder, localBackgroundImageLoaderTask));
      localBackgroundImageLoaderTask.execute(new URL[] { paramURL });
      Log.d(TAG, "Loading image for -> " + paramURL.toString());
    }
  }

  public void setVideoData(ArrayList<Videos.VideoElement> paramArrayList)
  {
    this.videos = paramArrayList;
    generateIndex();
  }

  private static class AnimateFirstDisplayListener extends SimpleImageLoadingListener
  {
    public void onLoadingComplete(String paramString, View paramView, Bitmap paramBitmap)
    {
      if (paramBitmap != null)
        FadeInBitmapDisplayer.animate((ImageView)paramView, 500);
    }
  }

  private class VideoFilter extends Filter
  {
    private ArrayList<Videos.VideoElement> originalData = null;

    private VideoFilter()
    {
    }

    @SuppressLint({"DefaultLocale"})
    protected Filter.FilterResults performFiltering(CharSequence paramCharSequence)
    {
      Filter.FilterResults localFilterResults = new Filter.FilterResults();
      this.originalData = new ArrayList();
      Iterator localIterator = VideoListAdapter.this.videos.iterator();
      while (true)
      {
        if (!localIterator.hasNext())
        {
          localFilterResults.values = this.originalData;
          return localFilterResults;
        }
        Videos.VideoElement localVideoElement = (Videos.VideoElement)localIterator.next();
        String str = localVideoElement.getCaption();
        if ((TextUtils.isEmpty(str)) || (TextUtils.isEmpty(paramCharSequence)) || (!str.toLowerCase().contains(paramCharSequence)))
          continue;
        this.originalData.add(localVideoElement);
      }
    }

    protected void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults)
    {
      VideoListAdapter.this.videos = ((ArrayList)paramFilterResults.values);
      VideoListAdapter.this.notifyDataSetChanged();
    }
  }

  public static class ViewHolder
  {
    TextView caption;
    TextView description;
    TextView sectionHeader;
    ImageView thumbnail;
    String videoUrl = "";
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.adapters.VideoListAdapter
 * JD-Core Version:    0.6.0
 */