package com.benefitfocus.myhrit.adapters;

import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.benefitfocus.data.model.transactionhistory.Person;
import java.util.List;

public class CoveredPersonListAdapter extends ArrayAdapter<Person>
{
  private Context context;

  public CoveredPersonListAdapter(Context paramContext, int paramInt1, int paramInt2, List<Person> paramList)
  {
    super(paramContext, paramInt1, paramInt2, paramList);
    this.context = paramContext;
  }

  public long getItemId(int paramInt)
  {
    Person localPerson = (Person)getItem(paramInt);
    if (localPerson != null)
    {
      String str = localPerson.getReferenceId();
      if (str != null)
        return Long.valueOf(str).longValue();
    }
    return -1L;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      paramView = LayoutInflater.from(this.context).inflate(2130903075, paramViewGroup, false);
      localViewHolder = new ViewHolder();
      localViewHolder.coveredPerson = ((TextView)paramView.findViewById(2131034277));
      localViewHolder.subscriberAppend = ((TextView)paramView.findViewById(2131034278));
      paramView.setTag(localViewHolder);
    }
    Person localPerson;
    while (true)
    {
      localPerson = (Person)getItem(paramInt);
      StringBuilder localStringBuilder = new StringBuilder().append(localPerson.getFirstName()).append(" ").append(localPerson.getMiddleName()).append(" ").append(localPerson.getLastName());
      localViewHolder.coveredPerson.setText(localStringBuilder.toString());
      if (!"SUBSCRIBER".equalsIgnoreCase(localPerson.getRelationship()))
        break;
      localViewHolder.subscriberAppend.setVisibility(0);
      localViewHolder.subscriberAppend.setText("(You)");
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
    }
    if (TextUtils.isEmpty(localPerson.getRelationship()))
    {
      localViewHolder.subscriberAppend.setVisibility(4);
      return paramView;
    }
    localViewHolder.subscriberAppend.setText("(" + localPerson.getRelationship() + ")");
    localViewHolder.subscriberAppend.setVisibility(0);
    return paramView;
  }

  static class ViewHolder
  {
    TextView coveredPerson;
    TextView subscriberAppend;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.adapters.CoveredPersonListAdapter
 * JD-Core Version:    0.6.0
 */