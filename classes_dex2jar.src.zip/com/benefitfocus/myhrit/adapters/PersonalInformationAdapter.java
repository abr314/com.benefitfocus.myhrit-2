package com.benefitfocus.myhrit.adapters;

import android.content.Context;
import android.content.res.Resources;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class PersonalInformationAdapter extends ArrayAdapter<Pair<String, String>>
{
  public PersonalInformationAdapter(Context paramContext, int paramInt, List<Pair<String, String>> paramList)
  {
    super(paramContext, paramInt, paramList);
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      paramView = LayoutInflater.from(getContext()).inflate(2130903084, paramViewGroup, false);
      localViewHolder = new ViewHolder();
      localViewHolder.label = ((TextView)paramView.findViewById(2131034313));
      localViewHolder.value = ((TextView)paramView.findViewById(2131034314));
      paramView.setTag(localViewHolder);
      if (paramInt % 2 != 1)
        break label141;
      paramView.setBackgroundColor(getContext().getResources().getColor(2131099684));
    }
    while (true)
    {
      Pair localPair = (Pair)getItem(paramInt);
      localViewHolder.label.setText((CharSequence)localPair.first);
      localViewHolder.value.setText((CharSequence)localPair.second);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label141: paramView.setBackgroundColor(getContext().getResources().getColor(2131099671));
    }
  }

  public static class ViewHolder
  {
    TextView label;
    TextView value;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.adapters.PersonalInformationAdapter
 * JD-Core Version:    0.6.0
 */