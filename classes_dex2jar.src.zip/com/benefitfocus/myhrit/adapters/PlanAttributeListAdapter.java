package com.benefitfocus.myhrit.adapters;

import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.benefitfocus.data.model.ee.PlanAttributeGroup.Attribute;
import java.text.NumberFormat;
import java.util.List;

public class PlanAttributeListAdapter extends ArrayAdapter<PlanAttributeGroup.Attribute>
{
  private static NumberFormat CURRENCY_FORMAT = NumberFormat.getCurrencyInstance();
  private Context context;
  private ViewGroup.LayoutParams layoutParams;

  public PlanAttributeListAdapter(Context paramContext, int paramInt, List<PlanAttributeGroup.Attribute> paramList)
  {
    super(paramContext, paramInt, paramList);
    this.context = paramContext;
  }

  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    ViewHolder localViewHolder;
    if (paramView == null)
    {
      paramView = LayoutInflater.from(this.context).inflate(2130903088, paramViewGroup, false);
      if (this.layoutParams == null)
        this.layoutParams = paramView.getLayoutParams();
      localViewHolder = new ViewHolder();
      localViewHolder.planAttributeName = ((TextView)paramView.findViewById(2131034244));
      localViewHolder.planAttributeValue = ((TextView)paramView.findViewById(2131034322));
      paramView.setTag(localViewHolder);
      PlanAttributeGroup.Attribute localAttribute = (PlanAttributeGroup.Attribute)getItem(paramInt);
      localViewHolder.planAttributeName.setText(localAttribute.getAttributeDisplay());
      localViewHolder.planAttributeValue.setText(CURRENCY_FORMAT.format(Double.parseDouble(localAttribute.getValue())));
      if (paramInt % 2 != 0)
        break label166;
      paramView.setBackgroundColor(getContext().getResources().getColor(2131099671));
    }
    while (true)
    {
      paramView.setLayoutParams(this.layoutParams);
      return paramView;
      localViewHolder = (ViewHolder)paramView.getTag();
      break;
      label166: paramView.setBackgroundColor(getContext().getResources().getColor(2131099684));
    }
  }

  static class ViewHolder
  {
    TextView planAttributeName;
    TextView planAttributeValue;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.adapters.PlanAttributeListAdapter
 * JD-Core Version:    0.6.0
 */