package com.benefitfocus.myhrit.data;

import java.util.ArrayList;

public class Videos
{
  private ArrayList<VideoElement> videos = new ArrayList();

  public ArrayList<VideoElement> getVideos()
  {
    return this.videos;
  }

  public void setVideos(ArrayList<VideoElement> paramArrayList)
  {
    this.videos = paramArrayList;
  }

  public static class VideoElement
  {
    public static final String LIBRARY = "library";
    public static final String VIDEO = "video";
    private String Caption;
    private String Description;
    private String Thumbnail;
    private String Uri;
    private ArrayList<VideoElement> contents = new ArrayList();
    private String type;

    public String getCaption()
    {
      return this.Caption;
    }

    public ArrayList<VideoElement> getContents()
    {
      return this.contents;
    }

    public String getDescription()
    {
      return this.Description;
    }

    public String getThumbnail()
    {
      return this.Thumbnail;
    }

    public String getType()
    {
      return this.type;
    }

    public String getUrl()
    {
      return this.Uri;
    }

    public boolean hasChildren()
    {
      return ("library".equalsIgnoreCase(this.type)) && (!this.contents.isEmpty());
    }

    public void setCaption(String paramString)
    {
      this.Caption = paramString;
    }

    public void setContents(ArrayList<VideoElement> paramArrayList)
    {
      this.contents = paramArrayList;
    }

    public void setDescription(String paramString)
    {
      this.Description = paramString;
    }

    public void setThumbnail(String paramString)
    {
      this.Thumbnail = paramString;
    }

    public void setType(String paramString)
    {
      this.type = paramString;
    }

    public void setUrl(String paramString)
    {
      this.Uri = paramString;
    }

    public String toString()
    {
      return this.Caption;
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.data.Videos
 * JD-Core Version:    0.6.0
 */