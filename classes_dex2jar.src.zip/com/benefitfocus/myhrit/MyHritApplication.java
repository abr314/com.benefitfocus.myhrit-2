package com.benefitfocus.myhrit;

import android.app.Application;
import com.benefitfocus.data.model.transactionhistory.Family;
import com.benefitfocus.data.model.transactionhistory.Person;
import com.benefitfocus.myhrit.data.Videos;
import com.nostra13.universalimageloader.cache.disc.impl.LimitedAgeDiscCache;
import com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator;
import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.DisplayImageOptions.Builder;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration.Builder;
import com.nostra13.universalimageloader.utils.StorageUtils;
import java.io.File;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

public class MyHritApplication extends Application
{
  private String currentToken;
  private Family family;
  private ImageLoader imageLoader;
  private String password;
  private boolean sponsorIdChanged = false;
  private String username;
  private Videos videos;

  public Person getEmployee()
  {
    Iterator localIterator;
    if (this.family != null)
      localIterator = this.family.getPerson().iterator();
    Person localPerson;
    do
    {
      if (!localIterator.hasNext())
        return null;
      localPerson = (Person)localIterator.next();
    }
    while (!localPerson.isEmployee());
    return localPerson;
  }

  public Family getFamily()
  {
    return this.family;
  }

  public ImageLoader getImageLoader()
  {
    if (this.imageLoader == null)
    {
      this.imageLoader = ImageLoader.getInstance();
      File localFile = StorageUtils.getOwnCacheDirectory(this, "HrIntouch/Cache");
      DisplayImageOptions localDisplayImageOptions = new DisplayImageOptions.Builder().cacheOnDisc().showStubImage(2130837654).showImageOnFail(2130837654).build();
      ImageLoaderConfiguration localImageLoaderConfiguration = new ImageLoaderConfiguration.Builder(this).discCacheSize(5242880).defaultDisplayImageOptions(localDisplayImageOptions).discCacheFileNameGenerator(new FileNameGenerator()
      {
        public String generate(String paramString)
        {
          return String.valueOf(Math.abs(paramString.hashCode()) + Calendar.getInstance().getTimeInMillis());
        }
      }).discCache(new LimitedAgeDiscCache(localFile, 43200000L)).threadPoolSize(2).build();
      this.imageLoader.init(localImageLoaderConfiguration);
    }
    return this.imageLoader;
  }

  public String getPassword()
  {
    return this.password;
  }

  public String getToken()
  {
    return this.currentToken;
  }

  public String getUsername()
  {
    return this.username;
  }

  public Videos getVideos()
  {
    return this.videos;
  }

  public boolean isSponsorIdChanged()
  {
    return this.sponsorIdChanged;
  }

  public void setFamilyData(Family paramFamily)
  {
    this.family = paramFamily;
  }

  public void setPassword(String paramString)
  {
    this.password = paramString;
  }

  public void setSponsorIdChanged(boolean paramBoolean)
  {
    this.sponsorIdChanged = paramBoolean;
  }

  public void setToken(String paramString)
  {
    monitorenter;
    try
    {
      this.currentToken = paramString;
      monitorexit;
      return;
    }
    finally
    {
      localObject = finally;
      monitorexit;
    }
    throw localObject;
  }

  public void setUsername(String paramString)
  {
    this.username = paramString;
  }

  public void setVideos(Videos paramVideos)
  {
    this.videos = paramVideos;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.MyHritApplication
 * JD-Core Version:    0.6.0
 */