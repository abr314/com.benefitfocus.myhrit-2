package com.benefitfocus.myhrit.fragments.listeners;

import android.support.v4.app.DialogFragment;

public abstract interface DialogFragmentListener
{
  public abstract void onNegativeButtonClicked(DialogFragment paramDialogFragment);

  public abstract void onNeutralButtonClicked(DialogFragment paramDialogFragment);

  public abstract void onPositiveButtonClicked(DialogFragment paramDialogFragment);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.myhrit.fragments.listeners.DialogFragmentListener
 * JD-Core Version:    0.6.0
 */