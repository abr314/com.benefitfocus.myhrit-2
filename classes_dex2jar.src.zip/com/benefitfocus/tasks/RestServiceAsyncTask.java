package com.benefitfocus.tasks;

import TT;;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import com.google.gson.Gson;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class RestServiceAsyncTask<T> extends AsyncTask<URL, Void, T>
{
  private static final int CONNECT_TIMEOUT = 3000;
  private static final int READ_TIMEOUT = 10000;
  private static String TAG = RestServiceAsyncTask.class.getSimpleName();
  private String body;
  private Class<T> clazz;
  private TaskCompleteListener<T> listener;
  private int maxAttempts = 1;
  private int readTimeout = 10000;
  private HashMap<String, String> requestHeaders = new HashMap();
  private String requestMethod = "GET";
  private boolean requiresAuth = false;

  public RestServiceAsyncTask(TaskCompleteListener<T> paramTaskCompleteListener, Class<T> paramClass)
  {
    this.listener = paramTaskCompleteListener;
    this.clazz = paramClass;
  }

  private RestServiceResponse execServiceCall(URL paramURL)
  {
    RestServiceResponse localRestServiceResponse = new RestServiceResponse();
    HttpURLConnection localHttpURLConnection = null;
    if (paramURL != null);
    try
    {
      long l = Calendar.getInstance().getTimeInMillis();
      localHttpURLConnection = (HttpURLConnection)paramURL.openConnection();
      localHttpURLConnection.setRequestMethod(this.requestMethod);
      localHttpURLConnection.setConnectTimeout(3000);
      localHttpURLConnection.setReadTimeout(this.readTimeout);
      if (!TextUtils.isEmpty(this.requestMethod))
        localHttpURLConnection.setRequestMethod(this.requestMethod);
      Iterator localIterator1 = this.requestHeaders.entrySet().iterator();
      while (true)
      {
        if (!localIterator1.hasNext())
        {
          if (("PUT".equals(this.requestMethod)) || ("POST".equals(this.requestMethod)))
          {
            if (this.requiresAuth)
              localHttpURLConnection.setRequestProperty("Authorization", "Basic " + Base64.encode("user:pass".getBytes(), 0));
            localHttpURLConnection.setDoOutput(true);
            OutputStreamWriter localOutputStreamWriter = new OutputStreamWriter(localHttpURLConnection.getOutputStream());
            localOutputStreamWriter.write(this.body);
            localOutputStreamWriter.flush();
            localOutputStreamWriter.close();
          }
          localRestServiceResponse.setResponseCode(localHttpURLConnection.getResponseCode());
          localRestServiceResponse.setBody(readStream(new BufferedInputStream(localHttpURLConnection.getInputStream())));
          if (localHttpURLConnection.getHeaderFields() != null)
          {
            localIterator2 = localHttpURLConnection.getHeaderFields().entrySet().iterator();
            if (localIterator2.hasNext())
              break;
          }
          String str3 = TAG;
          Object[] arrayOfObject3 = new Object[1];
          arrayOfObject3[0] = Long.valueOf(Calendar.getInstance().getTimeInMillis() - l);
          Log.d(str3, String.format("Service request time in millis: %d.", arrayOfObject3));
          return localRestServiceResponse;
        }
        Map.Entry localEntry1 = (Map.Entry)localIterator1.next();
        localHttpURLConnection.addRequestProperty((String)localEntry1.getKey(), (String)localEntry1.getValue());
      }
    }
    catch (SocketTimeoutException localSocketTimeoutException)
    {
      while (true)
      {
        Iterator localIterator2;
        Log.e(TAG, "Rest service failed Connection timeout for url -> " + paramURL, localSocketTimeoutException);
        return localRestServiceResponse;
        Map.Entry localEntry2 = (Map.Entry)localIterator2.next();
        localStringBuffer = new StringBuffer();
        localIterator3 = ((List)localEntry2.getValue()).iterator();
        if (localIterator3.hasNext())
          break;
        localRestServiceResponse.getResponseHeaders().put((String)localEntry2.getKey(), localStringBuffer.toString());
      }
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
      while (true)
      {
        StringBuffer localStringBuffer;
        Iterator localIterator3;
        String str2 = TAG;
        Object[] arrayOfObject2 = new Object[3];
        arrayOfObject2[0] = paramURL;
        arrayOfObject2[1] = Integer.valueOf(localRestServiceResponse.getResponseCode());
        arrayOfObject2[2] = this.body;
        Log.e(str2, String.format("Rest service failed, url %s response code %d body %s", arrayOfObject2), localFileNotFoundException);
        return localRestServiceResponse;
        localStringBuffer.append((String)localIterator3.next());
        if (!localIterator3.hasNext())
          continue;
        localStringBuffer.append("|");
      }
    }
    catch (IOException localIOException)
    {
      String str1 = TAG;
      Object[] arrayOfObject1 = new Object[2];
      arrayOfObject1[0] = paramURL;
      arrayOfObject1[1] = Integer.valueOf(localRestServiceResponse.getResponseCode());
      Log.e(str1, String.format("Rest service failed, url %s response code %d", arrayOfObject1), localIOException);
      Log.e(TAG, "Server error " + readStream(new BufferedInputStream(localHttpURLConnection.getErrorStream())));
      return localRestServiceResponse;
    }
    finally
    {
      if (localHttpURLConnection != null)
        localHttpURLConnection.disconnect();
    }
    throw localObject;
  }

  private String readStream(InputStream paramInputStream)
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    StringBuffer localStringBuffer = new StringBuffer();
    try
    {
      while (true)
      {
        String str = localBufferedReader.readLine();
        if (str == null)
          return localStringBuffer.toString();
        localStringBuffer.append(str);
      }
    }
    catch (IOException localIOException)
    {
      while (true)
        Log.e(TAG, "Error reading from stream", localIOException);
    }
  }

  protected T doInBackground(URL[] paramArrayOfURL)
  {
    Object localObject1 = null;
    Object localObject2;
    int j;
    if (paramArrayOfURL != null)
    {
      int i = paramArrayOfURL.length;
      localObject1 = null;
      if (i == 1)
      {
        localObject2 = null;
        j = 0;
      }
    }
    while (true)
    {
      if (j >= this.maxAttempts);
      try
      {
        label31: if (RestServiceResponse.class.isAssignableFrom(this.clazz))
        {
          Object localObject4 = this.clazz.cast(localObject2);
          localObject1 = localObject4;
        }
        boolean bool;
        do
        {
          return localObject1;
          localObject2 = execServiceCall(paramArrayOfURL[0]);
          if (((RestServiceResponse)localObject2).getResponseCode() == 200)
            break label31;
          j++;
          break;
          bool = TextUtils.isEmpty(((RestServiceResponse)localObject2).getBody());
          localObject1 = null;
        }
        while (bool);
        if (String.class.isAssignableFrom(this.clazz))
          return this.clazz.cast(((RestServiceResponse)localObject2).getBody());
        Object localObject3 = new Gson().fromJson(((RestServiceResponse)localObject2).getBody(), this.clazz);
        return localObject3;
      }
      catch (Exception localException)
      {
        Log.e(TAG, "Error handling response", localException);
      }
    }
    return (TT)null;
  }

  public String getBody()
  {
    return this.body;
  }

  public int getMaxAttempts()
  {
    return this.maxAttempts;
  }

  public int getReadTimeout()
  {
    return this.readTimeout;
  }

  public HashMap<String, String> getRequestHeaders()
  {
    return this.requestHeaders;
  }

  public String getRequestMethod()
  {
    return this.requestMethod;
  }

  public boolean isRequiresAuth()
  {
    return this.requiresAuth;
  }

  protected void onPostExecute(T paramT)
  {
    super.onPostExecute(paramT);
    this.listener.onTaskComplete(paramT);
  }

  public void setBody(String paramString)
  {
    this.body = paramString;
  }

  public void setMaxAttempts(int paramInt)
  {
    this.maxAttempts = paramInt;
  }

  public void setReadTimeout(int paramInt)
  {
    this.readTimeout = paramInt;
  }

  public void setRequestHeaders(HashMap<String, String> paramHashMap)
  {
    this.requestHeaders = paramHashMap;
  }

  public void setRequestMethod(String paramString)
  {
    this.requestMethod = paramString;
  }

  public void setRequiresAuth(boolean paramBoolean)
  {
    this.requiresAuth = paramBoolean;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.tasks.RestServiceAsyncTask
 * JD-Core Version:    0.6.0
 */