package com.benefitfocus.tasks;

import android.os.AsyncTask;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ReadFromClassPathAsyncTask<T> extends AsyncTask<String, Void, T>
{
  private static final String TAG = ReadFromClassPathAsyncTask.class.getSimpleName();
  private Class<T> clazz;
  private TaskCompleteListener<T> listener;

  public ReadFromClassPathAsyncTask(TaskCompleteListener<T> paramTaskCompleteListener, Class<T> paramClass)
  {
    this.listener = paramTaskCompleteListener;
    this.clazz = paramClass;
  }

  private String readStream(InputStream paramInputStream)
    throws Exception
  {
    BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
    StringBuffer localStringBuffer = new StringBuffer();
    while (true)
    {
      String str = localBufferedReader.readLine();
      if (str == null)
        return localStringBuffer.toString();
      localStringBuffer.append(str);
    }
  }

  // ERROR //
  protected T doInBackground(String[] paramArrayOfString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_0
    //   3: invokevirtual 73	java/lang/Object:getClass	()Ljava/lang/Class;
    //   6: aload_1
    //   7: iconst_0
    //   8: aaload
    //   9: invokevirtual 77	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   12: astore_2
    //   13: aload_0
    //   14: aload_2
    //   15: invokespecial 79	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:readStream	(Ljava/io/InputStream;)Ljava/lang/String;
    //   18: astore 11
    //   20: ldc 81
    //   22: aload_0
    //   23: getfield 31	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:clazz	Ljava/lang/Class;
    //   26: invokevirtual 85	java/lang/Class:isAssignableFrom	(Ljava/lang/Class;)Z
    //   29: ifeq +29 -> 58
    //   32: aload_0
    //   33: getfield 31	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:clazz	Ljava/lang/Class;
    //   36: aload 11
    //   38: invokevirtual 89	java/lang/Class:cast	(Ljava/lang/Object;)Ljava/lang/Object;
    //   41: astore 15
    //   43: aload 15
    //   45: astore 8
    //   47: aload_2
    //   48: ifnull +7 -> 55
    //   51: aload_2
    //   52: invokevirtual 94	java/io/InputStream:close	()V
    //   55: aload 8
    //   57: areturn
    //   58: new 96	com/google/gson/Gson
    //   61: dup
    //   62: invokespecial 97	com/google/gson/Gson:<init>	()V
    //   65: aload 11
    //   67: aload_0
    //   68: getfield 31	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:clazz	Ljava/lang/Class;
    //   71: invokevirtual 101	com/google/gson/Gson:fromJson	(Ljava/lang/String;Ljava/lang/Class;)Ljava/lang/Object;
    //   74: astore 12
    //   76: aload 12
    //   78: astore 8
    //   80: goto -33 -> 47
    //   83: astore 6
    //   85: getstatic 23	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:TAG	Ljava/lang/String;
    //   88: new 103	java/lang/StringBuilder
    //   91: dup
    //   92: ldc 105
    //   94: invokespecial 108	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   97: aload 6
    //   99: invokevirtual 109	java/lang/Exception:toString	()Ljava/lang/String;
    //   102: invokevirtual 112	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   105: invokevirtual 113	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   108: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   111: pop
    //   112: aconst_null
    //   113: astore 8
    //   115: aload_2
    //   116: ifnull -61 -> 55
    //   119: aload_2
    //   120: invokevirtual 94	java/io/InputStream:close	()V
    //   123: aconst_null
    //   124: areturn
    //   125: astore 9
    //   127: getstatic 23	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:TAG	Ljava/lang/String;
    //   130: aload 9
    //   132: invokevirtual 120	java/io/IOException:toString	()Ljava/lang/String;
    //   135: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   138: pop
    //   139: aconst_null
    //   140: areturn
    //   141: astore_3
    //   142: aload_2
    //   143: ifnull +7 -> 150
    //   146: aload_2
    //   147: invokevirtual 94	java/io/InputStream:close	()V
    //   150: aload_3
    //   151: athrow
    //   152: astore 4
    //   154: getstatic 23	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:TAG	Ljava/lang/String;
    //   157: aload 4
    //   159: invokevirtual 120	java/io/IOException:toString	()Ljava/lang/String;
    //   162: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   165: pop
    //   166: goto -16 -> 150
    //   169: astore 13
    //   171: getstatic 23	com/benefitfocus/tasks/ReadFromClassPathAsyncTask:TAG	Ljava/lang/String;
    //   174: aload 13
    //   176: invokevirtual 120	java/io/IOException:toString	()Ljava/lang/String;
    //   179: invokestatic 119	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;)I
    //   182: pop
    //   183: aload 8
    //   185: areturn
    //
    // Exception table:
    //   from	to	target	type
    //   2	43	83	java/lang/Exception
    //   58	76	83	java/lang/Exception
    //   119	123	125	java/io/IOException
    //   2	43	141	finally
    //   58	76	141	finally
    //   85	112	141	finally
    //   146	150	152	java/io/IOException
    //   51	55	169	java/io/IOException
  }

  protected void onPostExecute(T paramT)
  {
    super.onPostExecute(paramT);
    this.listener.onTaskComplete(paramT);
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.tasks.ReadFromClassPathAsyncTask
 * JD-Core Version:    0.6.0
 */