package com.benefitfocus.tasks;

public abstract interface TaskCompleteListener<T>
{
  public abstract void onTaskComplete(T paramT);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.tasks.TaskCompleteListener
 * JD-Core Version:    0.6.0
 */