package com.benefitfocus.tasks;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.support.v4.util.LruCache;
import android.util.Log;
import android.view.animation.Animation;
import android.widget.ImageView;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.net.URLConnection;

public class BackgroundImageLoaderTask extends AsyncTask<URL, Void, Bitmap>
{
  private static final String TAG;
  private static final LruCache<String, Bitmap> imageCache = new LruCache(20);
  private final WeakReference<Animation> animationReference;
  private final WeakReference<ImageView> imageViewReference;
  private URL url;

  static
  {
    TAG = BackgroundImageLoaderTask.class.getSimpleName();
  }

  public BackgroundImageLoaderTask(ImageView paramImageView, Animation paramAnimation)
  {
    this.imageViewReference = new WeakReference(paramImageView);
    this.animationReference = new WeakReference(paramAnimation);
    if ((paramImageView != null) && (paramImageView.getTag() != null));
    try
    {
      this.url = new URL((String)paramImageView.getTag());
      return;
    }
    catch (Exception localException)
    {
      Log.d(TAG, "Invalid URI", localException);
    }
  }

  public static boolean cancelPotentialWork(URL paramURL, ImageView paramImageView)
  {
    BackgroundImageLoaderTask localBackgroundImageLoaderTask = getTask(paramImageView);
    String str1 = TAG;
    Object[] arrayOfObject1 = new Object[1];
    if (localBackgroundImageLoaderTask == null);
    for (String str2 = "Null task"; ; str2 = localBackgroundImageLoaderTask.toString())
    {
      arrayOfObject1[0] = str2;
      Log.d(str1, String.format("Cancel work %s", arrayOfObject1));
      if (localBackgroundImageLoaderTask != null)
      {
        URL localURL = localBackgroundImageLoaderTask.url;
        String str3 = TAG;
        Object[] arrayOfObject2 = new Object[3];
        arrayOfObject2[0] = paramImageView.getTag();
        arrayOfObject2[1] = localURL;
        arrayOfObject2[2] = paramURL;
        Log.d(str3, String.format("ImageView tag ->%s taskURL ->%s new url-> %s", arrayOfObject2));
        if ((localURL == null) || (localURL.toString().equalsIgnoreCase(paramURL.toString())))
          break;
        Log.d(TAG, "Cancelling task with id " + localBackgroundImageLoaderTask.toString());
        localBackgroundImageLoaderTask.cancel(true);
      }
      return true;
    }
    return false;
  }

  private static BackgroundImageLoaderTask getTask(ImageView paramImageView)
  {
    if (paramImageView != null)
    {
      Drawable localDrawable = paramImageView.getDrawable();
      if ((localDrawable instanceof AsyncDrawable))
        return ((AsyncDrawable)localDrawable).getBackGroundWorkerTask();
    }
    return null;
  }

  protected Bitmap doInBackground(URL[] paramArrayOfURL)
  {
    Bitmap localBitmap = null;
    try
    {
      this.url = paramArrayOfURL[0];
      Object localObject = this.imageViewReference.get();
      localBitmap = null;
      if (localObject == null)
      {
        Log.e(TAG, "No image view available");
        return null;
      }
      localBitmap = null;
      if (0 == 0)
      {
        BitmapFactory.Options localOptions = new BitmapFactory.Options();
        localOptions.inPurgeable = true;
        localOptions.inInputShareable = true;
        localOptions.inSampleSize = 4;
        localBitmap = BitmapFactory.decodeStream(paramArrayOfURL[0].openConnection().getInputStream(), null, localOptions);
        String str1 = TAG;
        Object[] arrayOfObject1 = new Object[2];
        arrayOfObject1[0] = Integer.valueOf(localOptions.outWidth);
        arrayOfObject1[1] = Integer.valueOf(localOptions.outHeight);
        Log.d(str1, String.format("Width %s Height %s", arrayOfObject1));
        String str2 = TAG;
        Object[] arrayOfObject2 = new Object[2];
        arrayOfObject2[0] = Integer.valueOf(localBitmap.getScaledWidth(localBitmap.getDensity()));
        arrayOfObject2[1] = Integer.valueOf(localBitmap.getScaledHeight(localBitmap.getDensity()));
        Log.d(str2, String.format("Scaled Width %s Scaled Height %s", arrayOfObject2));
      }
      return localBitmap;
    }
    catch (IOException localIOException)
    {
      while (true)
        Log.e(TAG, "Unable to load image from url " + paramArrayOfURL[0]);
    }
  }

  protected void onPostExecute(Bitmap paramBitmap)
  {
    if (isCancelled())
      paramBitmap = null;
    if ((this.imageViewReference != null) && (paramBitmap != null))
    {
      ImageView localImageView = (ImageView)this.imageViewReference.get();
      if ((this == getTask(localImageView)) && (localImageView != null))
      {
        localImageView.setImageBitmap(paramBitmap);
        if ((this.animationReference != null) && (this.animationReference.get() != null))
          localImageView.setAnimation((Animation)this.animationReference.get());
      }
    }
  }

  public static class AsyncDrawable extends BitmapDrawable
  {
    private final WeakReference<BackgroundImageLoaderTask> bitmapWorkerTaskReference;

    public AsyncDrawable(Resources paramResources, Bitmap paramBitmap, BackgroundImageLoaderTask paramBackgroundImageLoaderTask)
    {
      super(paramBitmap);
      this.bitmapWorkerTaskReference = new WeakReference(paramBackgroundImageLoaderTask);
    }

    public BackgroundImageLoaderTask getBackGroundWorkerTask()
    {
      return (BackgroundImageLoaderTask)this.bitmapWorkerTaskReference.get();
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.tasks.BackgroundImageLoaderTask
 * JD-Core Version:    0.6.0
 */