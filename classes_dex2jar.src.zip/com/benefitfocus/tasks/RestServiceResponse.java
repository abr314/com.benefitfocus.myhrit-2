package com.benefitfocus.tasks;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class RestServiceResponse
{
  private String body;
  private int responseCode;
  private HashMap<String, String> responseHeaders = new HashMap();

  public String getBody()
  {
    return this.body;
  }

  public String getHeader(String paramString)
  {
    return (String)this.responseHeaders.get(paramString);
  }

  public int getResponseCode()
  {
    return this.responseCode;
  }

  public HashMap<String, String> getResponseHeaders()
  {
    return this.responseHeaders;
  }

  public void setBody(String paramString)
  {
    this.body = paramString;
  }

  public void setResponseCode(int paramInt)
  {
    this.responseCode = paramInt;
  }

  public void setResponseHeaders(HashMap<String, String> paramHashMap)
  {
    this.responseHeaders = paramHashMap;
  }

  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder();
    localStringBuilder.append("HEADERS:\n");
    Iterator localIterator = this.responseHeaders.entrySet().iterator();
    while (true)
    {
      if (!localIterator.hasNext())
      {
        localStringBuilder.append("BODY:\n").append(this.body).append("\n");
        localStringBuilder.append("RESPONSE CODE:\n").append(this.responseCode);
        return localStringBuilder.toString();
      }
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      localStringBuilder.append((String)localEntry.getKey()).append(":").append((String)localEntry.getValue()).append("\n");
    }
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.benefitfocus.tasks.RestServiceResponse
 * JD-Core Version:    0.6.0
 */