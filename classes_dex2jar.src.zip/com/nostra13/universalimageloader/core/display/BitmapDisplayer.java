package com.nostra13.universalimageloader.core.display;

import android.graphics.Bitmap;
import android.widget.ImageView;

public abstract interface BitmapDisplayer
{
  public abstract Bitmap display(Bitmap paramBitmap, ImageView paramImageView);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.nostra13.universalimageloader.core.display.BitmapDisplayer
 * JD-Core Version:    0.6.0
 */