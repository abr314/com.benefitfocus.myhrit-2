package com.nostra13.universalimageloader.core.assist;

import com.nostra13.universalimageloader.cache.disc.DiscCacheAware;
import java.io.File;

public final class DiscCacheUtil
{
  public static File findInCache(String paramString, DiscCacheAware paramDiscCacheAware)
  {
    File localFile = paramDiscCacheAware.get(paramString);
    if (localFile.exists())
      return localFile;
    return null;
  }

  public static boolean removeFromCache(String paramString, DiscCacheAware paramDiscCacheAware)
  {
    return paramDiscCacheAware.get(paramString).delete();
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.nostra13.universalimageloader.core.assist.DiscCacheUtil
 * JD-Core Version:    0.6.0
 */