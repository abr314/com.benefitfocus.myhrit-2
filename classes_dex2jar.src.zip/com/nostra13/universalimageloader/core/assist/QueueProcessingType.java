package com.nostra13.universalimageloader.core.assist;

public enum QueueProcessingType
{
  static
  {
    QueueProcessingType[] arrayOfQueueProcessingType = new QueueProcessingType[2];
    arrayOfQueueProcessingType[0] = FIFO;
    arrayOfQueueProcessingType[1] = LIFO;
    $VALUES = arrayOfQueueProcessingType;
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.nostra13.universalimageloader.core.assist.QueueProcessingType
 * JD-Core Version:    0.6.0
 */