package com.nostra13.universalimageloader.core.process;

import android.graphics.Bitmap;

public abstract interface BitmapProcessor
{
  public abstract Bitmap process(Bitmap paramBitmap);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.nostra13.universalimageloader.core.process.BitmapProcessor
 * JD-Core Version:    0.6.0
 */