package com.nostra13.universalimageloader.cache.disc.naming;

public abstract interface FileNameGenerator
{
  public abstract String generate(String paramString);
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     com.nostra13.universalimageloader.cache.disc.naming.FileNameGenerator
 * JD-Core Version:    0.6.0
 */