package android.support.v4.media;

public class TransportStateListener
{
  public void onPlayingChanged(TransportController paramTransportController)
  {
  }

  public void onTransportControlsChanged(TransportController paramTransportController)
  {
  }
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.media.TransportStateListener
 * JD-Core Version:    0.6.0
 */