package android.support.v4.app;

public class ServiceCompat
{
  public static final int START_STICKY = 1;
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.ServiceCompat
 * JD-Core Version:    0.6.0
 */