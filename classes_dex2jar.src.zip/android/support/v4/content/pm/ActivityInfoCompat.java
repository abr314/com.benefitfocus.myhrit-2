package android.support.v4.content.pm;

public class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}

/* Location:           /Users/ab11w/Downloads/dex2jar-0.0.9.15/classes_dex2jar.jar
 * Qualified Name:     android.support.v4.content.pm.ActivityInfoCompat
 * JD-Core Version:    0.6.0
 */